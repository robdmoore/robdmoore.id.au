Interface(MyInterface)
	virtual void someMethod(uint8_t someValue) = 0;
	virtual void someMethod2(uint8_t someOtherValue) = 0;
EndInterface;
