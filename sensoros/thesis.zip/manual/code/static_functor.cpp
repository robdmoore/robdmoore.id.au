// Define class with static method
class MyClass {
public:
	static void func(void);
}
// Initialise VoidStaticFunctor with method pointer
static const VoidStaticFunctor myFunctor(&MyClass::func);
// Call the functor (calls the MyClass::func() method)
myFunctor();
