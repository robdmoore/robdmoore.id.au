/**
 * Example class implementation file
 *
 * @author Robert Moore <rob@mooredesign.com.au>
 * @version 1.0.0
 * @date 2009-08-30
 */

// Include main.h for SensorOS core files
#include <main.h>

const char ExampleClass::HELLO_WORLD_STRING[] = "Hello World!\r\n";

/**
 * Example class constructor
 *
 * @param numTimes The number of times to print the
 * 	hello world message when helloWorld() is called
 */
ExampleClass::ExampleClass(uint8_t numTimes) : numTimes(numTimes) {}

/**
 * Example class destructor
 */
ExampleClass::~ExampleClass() {}

/**
 * Print hello world message numTimes times
 */
void ExampleClass::helloWorld() {
	uint8_t i;
	for(i=0; i<numTimes; ++i) {
		Debug::print(HELLO_WORLD_STRING);
	}
}

