/**
 * List destructor
 *
 * Deletes all the link objects allocated in this class
 */
template<class TClass> List<TClass>::~List()

/**
 * Adds the given item to the end of the list
 *
 * @param obj A reference to a TClass object to
 * 	be added to the list
 */
template<class TClass> void List<TClass>::push_back(TClass* obj)

/**
 * Adds the given item to the start of the list
 *
 * @param obj A reference to a TClass object to
 * 	be added to the list
 */
template<class TClass> void List<TClass>::push_front(TClass* obj)

	/**
 * Inserts the given item to the list after the item
 * 	pointed to by the given iterator
 *
 * @param iter An iterator pointing to an item in the list
 * @param obj A reference to a TClass object to
 * 	be added to the list
 */
template<class TClass> void List<TClass>::insert(List<TClass>::iterator& iter, TClass* obj)

/**
 * Returns the first item in the list
 *
 * @return The first item in the list
 */
template<class TClass> ListLink<TClass>* List<TClass>::begin() const

/**
 * Returns the last item in the list
 *
 * @return The last item in the list
 */
template<class TClass> ListLink<TClass>* List<TClass>::end() const
