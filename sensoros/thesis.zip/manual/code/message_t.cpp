typedef struct {
	uint8_t header[sizeof(message_header_t)];
	uint8_t data[MAX_DATA_BYTES];
	uint8_t footer[sizeof(message_footer_t)];
	uint8_t metadata[sizeof(message_metadata_t)];
} message_t;
