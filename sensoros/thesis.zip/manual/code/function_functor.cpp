// Define function
void func(void);
// Initialise VoidStaticFunctor with function pointer
static const VoidStaticFunctor myFunctor(&func);
// Call the functor (calls the func() function)
myFunctor();
