// mainFunctor is already defined as a const VoidFunctor
// signalRouter is already defined as a reference to the signal router
// 	see code listing *(\ref{code:SignalRouter})*
signalRouter->registerHandler(SIG_SYSTEM_BOOTED, &mainFunctor)
