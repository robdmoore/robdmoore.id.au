Platform
========

dragon12

Description
===========

SensorOS platform for the [Wytec Dragon12 Development
Board](http://www.evbplus.com/dragon12_hc12_68hc12_9s12_hcs12.html)

Author
======

[Robert Moore](mailto:rob@mooredesign.com.au)

Date
====

2009-09-27

Version
=======

1.0.0

Processor
=========

[Freescale 9S12/HCS12](http://www.freescale.com/webapp/sps/site/
overview.jsp?nodeId=06258A25802570256D)

Compilers
=========

IAR Embedded Workbench (EW) and GCC compatible

When compiling with IAR EW, the following files need to be added
to the project:

* sensoros/os/main.cpp
* sensoros/os/network.cpp
* sensoros/os/scheduler.cpp
* sensoros/os/signal_router.cpp
* sensoros/os/signal_router.cpp
* sensoros/platforms/dragon12/can_link.cpp
* sensoros/platforms/dragon12/debug.cpp
* sensoros/platforms/dragon12/platform.cpp
* sensoros/platforms/dragon12/iar.s12
* Any application source files

And "Additional include directories" need to be added (Project >
C/C++ Compiler > Preprocessor) as (assuming the project resides in
a subdirectory of the application's directory (e.g. sensoros/
applications/<application_name>/iar/)):

* $PROJ_DIR$\..\..\..\os
* $PROJ_DIR$\..\..\..\platforms\dragon12
* $PROJ_DIR$\..

Notes
=====

There wasn't any macros defined by IAR EW, so in platform.h
__IAR__ is set if the compiler is not GCC. If the platform is
extended to include any more compilers then the setting of __IAR__
will need to be modified.

If an application wants to use any of the 5 CAN modules then it
should define CAN<X> (where X is 0 - 4, and refers to CAN module
X) as the link id number that the corresponding CAN module should
be. These definitions need to go in application_network_info.h and
should obviously be used as a conditional compilation for this
platform only, e.g.:

	#ifdef PLATFORM_DRAGON12
		#define MSCAN0 1 // Use CAN module 0 as data link 1
		#define MSCAN3 2 // Use CAN module 3 as data link 2
	#endif

Note: you must set the data link ids in ascending, incremental
order or the assignment of the data link ids to the network will fail.

The debug class will print strings to SCI0 at a baud of 19200 with 1
start bit, 8 data bits, 1 stop bit and no parity bits.

License
=======

MIT
---

Copyright (c) 2009 Robert Moore

Permission is hereby granted, free of charge, to any person
obtaining a copy of this software and associated documentation
files (the "Software"), to deal in the Software without
restriction, including without limitation the rights to use,
copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the
Software is furnished to do so, subject to the following
conditions:

The above copyright notice and this permission notice shall be
included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
OTHER DEALINGS IN THE SOFTWARE.