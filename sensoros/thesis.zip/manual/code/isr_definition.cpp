// Interrupt handler typedef: GNU
#ifdef __GNUC__
	#define  interrupt_t void __attribute__((interrupt))
	// Define macro to allow ISR's to be registered
	// http://www.embedded.com/columns/programmingpointers/192503651
	typedef void (*pointer_to_ISR)(void);
	#define SET_ISR(VECTOR, ISR) *reinterpret_cast<pointer_to_ISR *>(VECTOR) = ISR
#endif
// Interrupt Handler typedef: IAR
#ifdef __IAR__
	#define interrupt_t __interrupt void
	// IAR uses a #pragma to define vector addresses, make SET_ISR to nothing
	#define SET_ISR(VECTOR, ISR)
#endif
