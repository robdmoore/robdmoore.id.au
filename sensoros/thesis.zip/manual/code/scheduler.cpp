Scheduler* scheduler = Scheduler::getInstance();
