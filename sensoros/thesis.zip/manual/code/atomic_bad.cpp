{
	Atomic
	// ...
}
EndAtomic;
