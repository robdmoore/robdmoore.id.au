#define Atomic {atomic_t atomicValue = __atomic_start();
#define EndAtomic __atomic_end(atomicValue);}
