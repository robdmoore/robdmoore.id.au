/**
 * Main system function (first function the system loads)
 *
 * @returns The status of the program, should never actually return
 * 	due to infinite scheduler loop
 */
int main() {

	// Platform bootstrap
	Platform::bootstrap();
	// Initialise the scheduler
	Scheduler* scheduler = Scheduler::getInstance();
	// Initialise the platform
	Platform::init();
	// Run any tasks
	while (scheduler->runNextTask());
	// Initialise the signal router
	SignalRouter* signalRouter = SignalRouter::getInstance();
	// Send a software initialisation signal
	// Allows the platform initialisation to post event handlers
	// 	for this signal if they need to be deferred until after
	// 	initialisation
	signalRouter->signal(SIG_SOFTWARE_INIT);
	// Run any tasks
	while (scheduler->runNextTask());
	// Initialise the application
	Application::init();
	// Run any tasks
	while (scheduler->runNextTask());
	// Enable interrupts
	__enable_interrupts();
	// Call the system booted event
	signalRouter->signal(SIG_SYSTEM_BOOTED);
	// Spin in the scheduler loop
	scheduler->taskLoop();
	// Include for compiler, shouldn't ever be reached
	return -1;
}
