// signal_t Type
typedef enum {
	SIG_SOFTWARE_INIT=0,
	SIG_SYSTEM_BOOTED,
	#include <platform_signals.h> // Can define a max of 127 signals
	#include <application_signals.h> // Can define a max of 127 signals
	NUM_SIGNALS // Must be last!
} signal_t;
typedef uint8_t signal_iterator_t; // NUM_SIGNALS can't be more than 256
