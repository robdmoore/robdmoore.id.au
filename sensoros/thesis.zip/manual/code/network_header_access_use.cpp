/**
 * Returns the source address of the message in the given message buffer
 * @return Message source
 */
node_address_t CanLink::getSource(message_t* msg) {

	return MESSAGE_HEADER(msg, mscan_header_t)->source;
}
