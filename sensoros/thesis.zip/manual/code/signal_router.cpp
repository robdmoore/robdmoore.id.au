SignalRouter* signalRouter = SignalRouter::getInstance();
