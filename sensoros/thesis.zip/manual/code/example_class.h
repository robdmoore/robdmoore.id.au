/**
 * Example Class definition file
 *
 * The example class prints out hello world n number
 * 	of times when the helloWorld() method is called.
 * This class illustrates various points from the
 * 	SensorOS coding conventions
 *
 * @author Robert Moore <rob@mooredesign.com.au>
 * @version 1.0.0
 * @date 2009-08-30
 */

#ifndef _EXAMPLE_CLASS_H
#define _EXAMPLE_CLASS_H

class ExampleClass {

	public:
		ExampleClass(uint8_t numTimes);
		~ExampleClass();
		void helloWorld(void);
	private:
		static const char HELLO_WORLD_STRING[15];
		uint8_t numTimes;
};

#endif
