// Define class with instance method
class MyClass {
public:
	MyClass();
	void func(void);
}
// Initialise instance of MyClass
static MyClass myClass();
// Initialise VoidInstanceFunctor with method pointer
static const VoidInstanceFunctor<MyClass> myFunctor(&myClass, &MyClass::func);
// Call the functor (calls the myClass.func() method)
myFunctor();
