class MyClass {
public:
	static void myTask(void);
}
static const VoidStaticFunctor myTaskFunctor(&MyClass::myTask);
...
scheduler->postTask(&myTaskFunctor);
