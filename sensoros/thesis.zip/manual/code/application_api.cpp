/**
 * Initialises the application before interrupts are enabled
 */
void Application::init()
