/**
 * Passes a filled buffer with received data to the network layer
 * Called within an atomic section to preserve integrity of message
 * 	buffer; this method must only perform short computation(s) and then
 * 	return ASAP
 *
 * @param linkLayer A pointer to the link layer that received the data
 * @param msg A pointer to the message buffer with the received data
 * @param length The length of the received payload (for convenience,
 * 	same value can be gotten with linkLayer->getPayloadLength(msg)
 *
 * @return A pointer to a valid message buffer that the link layer
 * 	can use for the next received packet
 */

virtual message_t* upFromDataLink(DataLinkLayer* linkLayer, message_t* msg,
							data_length_t length)
/**
 * Allows release of the buffer pointed to by msg and informs
 * 	network layer of the status of sending of the message in that
 * 	buffer
 *
 * @param msg A pointer to the message buffer that can be freed
 * @param status The status of sending the message in msg:
 * 	SUCCESS if the message was successfully sent
 * 	FAIL if the message failed to send
 * 	ECANCEL if the message was cancelled by a call to DataLinkLayer::cancel()
 */
virtual void sendDone(message_t* msg, error_t status)
