// Define test class (MyClass) and some instances of it
class MyClass {
public:
	MyClass(uint8_t value) : value(value) {};
	uint8_t value;
};
MyClass one(1);
MyClass two(2);
MyClass three(3);
MyClass four(4);
MyClass five(5);
// Create a list, this is dynamic to match the usage in
// 	SignalRouter, but this could also be a static instantiation
List<MyClass>* myList = new List<MyClass>();
// Add one to the back of the list
myList->push_back(&one);
// Get an iterator pointing to the current front of the list
// Uses the constructor of the iterator to assign the iterator
// 	to an item
List<MyClass>::iterator i(myList->begin());
// Add two to the front of the list
myList->push_front(&two);
// Add three to the back of the list
myList->push_back(&three);
// Insert four after the item pointed to by iterator i
myList->insert(i, &four);
// Add five to the front
myList->push_front(&five);
// Iterate through the list with a new iterator, j
// Uses assignment to assign the iterator to an item
List<MyClass>::iterator j;
for (j=myList->begin(); j != myList->end(); ++j) {
	// Dereference the iterator to get the class
	// 	reference, then print out the value in the class
	// 	using the Debug class
	Debug::printf("%d\r\n", (*j).value);
}
// Note: Incrementing of the iterator MUST be preincrement
// 	i.e. ++j instead of j++. Post increment is NOT supported
// 	because it is less efficient (requires object copy)
// Note also: Only != and == are available for the iterator
// 	and can be used to compare the iterator with an item in
// 	the list or another iterator
