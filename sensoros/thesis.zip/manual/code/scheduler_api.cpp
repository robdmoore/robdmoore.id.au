/**
 * Returns the singleton instance of the Scheduler class
 * @return The instance
 */
Scheduler* Scheduler::getInstance()

/**
 * Pushes the given task onto the end of the task queue
 * Contains an atomic section
 * @param task The task to push onto the queue
 * @return The status of the operation (either SUCCESS or EFULL)
 */
error_t Scheduler::pushTask(task_t task)

/**
 * Runs the task at the head of the queue and returns whether or
 * 	not there is a task left on the queue
 * Contains an atomic section
 * 	@return Whether or not there is a task left on the queue
 */
bool Scheduler::runNextTask()

/**
 * Enters an infinite loop that runs the next task on the queue and
 * 	sends the processor into sleep mode when the queue is exhausted
 * Calls Platform::sleep()
 */
void Scheduler::taskLoop()
