class MyClass {
public:
	MyClass();
	void myTask(void);
}
static MyClass myClass();
static const VoidInstanceFunctor<MyClass> myTaskFunctor(&myClass, &MyClass::myTask);
...
scheduler->postTask(&myTaskFunctor);
