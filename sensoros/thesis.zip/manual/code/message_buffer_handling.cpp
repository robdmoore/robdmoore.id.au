class TestNetwork: implements NetworkLayer {
public:
	TestNetwork() {
		// Set all buffers as unused
		used = 0xFF;
	};
	message_t* upFromDataLink(DataLinkLayer* linkLayer, message_t* msg,
						data_length_t length);
	void sendDone(message_t* msg, error_t status) {
		// Free the buffer used by msg
		ptrdiff_t bufferId = (ptrdiff_t)(buffers - msg);
		if (bufferId >=0 && bufferId <= 7) {
			Atomic
				if (bufferId == 0) {
					used |= 0x1;
				} else {
					used |= 0x1 << bufferId;
				}
			EndAtomic;
		}
		// ...
	};
private:
	// Array of message buffers
	message_t buffers[8];
	// Bit mask, a 1 indicates an unused buffer
	uint8_t used;
	/**
	 * Returns a pointer to a free message buffer
	 *
	 * The message buffer returned is reserved atomically
	 * 	so it can't be used elsewhere
	 *
	 * @returns The message buffer pointer, or NULL if no
	 * 	free buffers
	 */
	message_t* getFreeBuffer() {
		message_t* buffer = NULL;
		uint8_t lowestFreeBuffer = 0;
		// Extract lowest set bit
		// http://realtimecollisiondetection.net/blog/?p=78
		uint8_t lowestSetBit = used&-used;
		uint8_t bit = lowestSetBit;
		Atomic
			// If there are any unused buffers
			if (used > 0) {
				// Find log2 of lowestUnused to get the buffer number
				// Takes advantage of the fact that if only one
				// 	bit is set in the integer, if the integer is 4 or less
				// 	the log2 of it is itself shifted right one
				// For an 8-bit number, this loop will enter a maximum of
				//	 two times
				while (bit > 0x4) {
					lowestFreeBuffer += 0x3;
					bit >>= 3;
				}
				lowestFreeBuffer += bit >> 1;
				// After extracting the lowest free buffer, claim it
				// 	and set buffer appropriately
				used &= ~lowestSetBit;
				buffer = &buffers[lowestFreeBuffer];
			}
		EndAtomic;
		return buffer;
	};
};
