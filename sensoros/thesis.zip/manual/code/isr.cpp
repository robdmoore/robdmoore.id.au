#ifdef __IAR__
	#pragma vector=MSCAN4TX_VECTOR
#endif
interrupt_t can4TXISR(void) {
	// Signal a CAN 4 Send event
	SignalRouter::getInstance()->signal(SIG_CAN4_SENT);
	// Call the sendDone method for this link
	can4Link.sendDone();
}
SET_ISR(MSCAN4TX_VECTOR, can4TXISR)
