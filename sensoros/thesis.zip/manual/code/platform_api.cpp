/**
 * Initialises the hardware at a very basic level
 * 	e.g. CPU / memory mode selection
 */
void Platform::bootstrap()

/**
 * Initialise the hardware platform
 * Can post tasks to be run after the method is finished
 * 	if there are order dependant tasks
 */
void Platform::init()

/**
 * Puts the hardware into a low power mode when there are no
 * 	more tasks to run. It should exit this mode either after
 * 	a specified amount of time, or preferably when there is
 * 	an interrupt that requires the platform to perform some
 * 	action, e.g. network activity
 */
void Platform::sleep()
