// All Message Buffers (Used in conjunction with sizeof() in
// 	message_t definition)
typedef union message_header {
	mscan_header_t mscan;
} message_header_t;
typedef union message_footer {
	mscan_footer_t mscan;
} message_footer_t;
typedef union message_metadata {
	mscan_metadata_t mscan;
} message_metadata_t;
