#ifdef PLATFORM_DRAGON12
	// Use CAN module 0 as data link 1
	#define MSCAN0 1
	// Use CAN module 3 as data link 2
	#define MSCAN3 2
#endif
