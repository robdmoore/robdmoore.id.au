// MSCAN Message Buffer
typedef struct {
	node_address_t source;
	node_address_t destination;
} mscan_header_t;
typedef struct {
	data_length_t length;
	priority_t priority;
	timestamp_t timestamp;
} mscan_footer_t;
typedef struct {} mscan_metadata_t;
