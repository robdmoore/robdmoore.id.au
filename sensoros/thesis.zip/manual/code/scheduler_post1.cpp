void myTask(void);
static const VoidStaticFunctor myTaskFunctor(&myTask);
...
scheduler->postTask(&myTaskFunctor);
