#define MESSAGE_HEADER(msg, type) ((type*)((msg)->data-sizeof(type)))
#define MESSAGE_FOOTER(msg, type) ((type*)((msg)->footer))
#define MESSAGE_FOOTER_CONTIGUOUS(msg, type) ((type*)((msg)->footer)-getPayloadLength(msg))
#define MESSAGE_METADATA(msg, type) ((type*)((msg)->metadata))
