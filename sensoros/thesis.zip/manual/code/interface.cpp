#define Interface(name) \
	class name { \
		public: \
			virtual ~name() {};
#define EndInterface }
#define implements public
