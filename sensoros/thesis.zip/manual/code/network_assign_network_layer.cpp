static MyNetworkLayer myNetworkLayer();
...
// network is already defined as a reference to the network
// 	see code listing *(\ref{code:Network})*
network->assignNetworkLayer(&myNetworkLayer)
