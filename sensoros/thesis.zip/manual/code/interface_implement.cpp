class MyClass: implements MyInterface {
public:
	MyClass();
	void someMethod(uint8_t someValue);
	void someMethod2(uint8_t someOtherValue);
}
