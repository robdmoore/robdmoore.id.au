/**
 * Prints a static string
 *
 * Prints the given string to Serial Communications Interface (SCI) 0
 *
 * @param string The string to print
 */
void Debug::print(const char* string)

/**
 * Prints a formatted string
 *
 * Prints the given format string to Serial Communications Interface (SCI) 0
 * Uses the same syntax as the C stdio printf function
 *
 * @param format The format string
 * @param ... Any values referenced in the format string
 */	
void Debug::printf(const char* format, ...)

/**
 * Lights a number of LEDs based on an integer value
 *
 * If the integer given is say 6, then LED 1 and 2 will be lit
 * 	but LED 0 won't be
 *
 * @param ledsValue The value to set the leds to
 */	
void Debug::leds(uint8_t ledsValue)

/**
 * Lights (or unlights) a specific LED
 *
 * @param ledValue Whether to light (true) or unlight
 * 	(false) the LED
 * @param led The LED to modify (0-7)
 */
void Debug::leds(bool ledValue, uint8_t led)

/**
 * Toggles a specific LED on or off
 *
 * @param led The LED to toggle (0-7)
 */
void Debug::toggleLed(uint8_t led)
