// network is already defined as a reference to the network
// 	see code listing *(\ref{code:Network})*
// dataLinkId is predefined (of type link_id_t) as the id
// 	of the data link you want to reference
DataLinkLayer dataLink = network->getLink(dataLinkId);
