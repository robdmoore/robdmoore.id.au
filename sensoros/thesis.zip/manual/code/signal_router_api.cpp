/**
 * Returns the singleton instance of the SignalRouter class
 * @return The instance
 */
SignalRouter* SignalRouter::getInstance()

/**
 * Registers a functor to be called when a particular event occurs
 * Dynamically allocates memory, either explicitly for a list or implicitly
 * 	via List::push_back()
 */
void SignalRouter::registerHandler(signal_t signal, VoidFunctor const* handler)

/**
 * Signals to the signal router that a particular event
 * 	has occurred and any registered event handlers for
 * 	that signal should be notified
 * @param signal The signal that has occurred
 */
void SignalRouter::signal(signal_t signal)

/**
 * SignalRouter destructor: deletes dynamically allocated handler lists
 */
SignalRouter::~SignalRouter()
