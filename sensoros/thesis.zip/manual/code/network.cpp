Network* network = Network::getInstance();
