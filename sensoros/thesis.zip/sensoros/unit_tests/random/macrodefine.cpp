#include <stdio.h>

#define integer(name, value) \
	#define name (value)

int main() {


	integer(test, 3);

	printf("%d", test);

	return 0;
}
