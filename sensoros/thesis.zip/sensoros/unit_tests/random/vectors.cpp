#include <vector>
#include <iostream>

using namespace std;

typedef int (*const signal_handler_t)(void);
typedef vector<void*> intVector;

int test() {
	return 16;
}

int main() {

	signal_handler_t testFn = &test;

	intVector* vectors[3];

	if (vectors[0] == NULL) {
		vectors[0] = new intVector();
	}

	vectors[0]->push_back((void*)testFn);
	vectors[0]->push_back((void*)testFn);

	for (int i = 0; i < vectors[0]->size(); i++) {

		cout << ((signal_handler_t)(*(vectors[0]))[i])() << endl;
	}

}
