/**
 * SensorOS List Definition File
 *
 * Defines a singly-linked list based on the STL list
 * 	interface / functionality
 *
 * @author Robert Moore <rob@mooredesign.com.au>
 * @date 2009-06-01
 * @version 1.0.0
 */

#ifndef _LIST_H
#define _LIST_H

#ifndef NULL
	#define NULL 0
#endif

#if DEBUG
	#include <iostream>
#endif

template <class TClass> class List;
template <class TClass> class ListIterator;

template <class TClass> class ListLink {

	friend class ListIterator<TClass>;
	friend class List<TClass>;

	public:
		ListLink(TClass* data);
		inline void setNext(ListLink<TClass>* next);
		#if DEBUG
			template <class T> friend std::ostream &operator<<(std::ostream &o, const ListLink<T> &l);
		#endif

	private:
		ListLink<TClass>* next;
		TClass* data;
};

template <class TClass> class ListIterator {

	friend class List<TClass>;

	public:
		ListIterator();
		ListIterator(ListLink<TClass>* link);
		inline void operator=(ListLink<TClass>* link);
		ListIterator<TClass>& operator++();
		inline TClass& operator*();
		inline bool operator==(ListIterator<TClass>& iter);
		inline bool operator!=(ListIterator<TClass>& iter);
		inline bool operator==(ListLink<TClass>* link);
		inline bool operator!=(ListLink<TClass>* link);
		#if DEBUG
			template <class T> friend std::ostream &operator<<(std::ostream &o, const ListIterator<T> &l);
		#endif

	private:
		ListLink<TClass>* link;
};

template <class TClass> class List {

	public:
		typedef ListIterator<TClass> iterator;

		List();
		~List();
		void push_back(TClass* obj);
		void push_front(TClass* obj);
		void insert(iterator& iter, TClass* obj);
		inline ListLink<TClass>* begin() const;
		inline ListLink<TClass>* end() const;
		#if DEBUG
			template <class T> friend std::ostream &operator<<(std::ostream &o, const List<T> &l);
		#endif

	private:
		ListLink<TClass>* head;
		ListLink<TClass>* tail;
};

#endif
