/**
 * SensorOS List Definition File
 *
 * Defines a singly-linked list based on the STL list
 * 	interface / functionality
 *
 * @author Robert Moore <rob@mooredesign.com.au>
 * @date 2009-05-31
 * @version 1.0.0
 */

#include "list.h"

/**
 * ListLink
 */

template <class TClass> ListLink<TClass>::ListLink(TClass* data) : next(NULL), data(data) {}

template <class TClass> void ListLink<TClass>::setNext(ListLink<TClass>* next) {
	this->next = next;
}

#if DEBUG
template <class TClass> std::ostream &operator<<(std::ostream &o, const ListLink<TClass> &l) {
	o << "(" << l.next << "," << l.data << ")";
	return o;
}
#endif

/**
 * ListIterator
 */
template <class TClass> ListIterator<TClass>::ListIterator() : link(NULL) {}
template <class TClass> ListIterator<TClass>::ListIterator(ListLink<TClass>* link) : link(link) {}

template <class TClass> void ListIterator<TClass>::operator=(ListLink<TClass>* link) {
	this->link = link;
}

template <class TClass> ListIterator<TClass>& ListIterator<TClass>::operator++() {
	if (link != NULL)
		link = link->next;
	return *this;
}

template <class TClass> TClass& ListIterator<TClass>::operator*() {
	return *(link->data);
}

template <class TClass> bool ListIterator<TClass>::operator==(ListIterator<TClass>& iter) {
	return link == iter.link;
}

template <class TClass> bool ListIterator<TClass>::operator!=(ListIterator<TClass>& iter) {
	return link != iter.link;
}

template <class TClass> bool ListIterator<TClass>::operator==(ListLink<TClass>* link) {
	return this->link == link;
}

template <class TClass> bool ListIterator<TClass>::operator!=(ListLink<TClass>* link) {
	return this->link != link;
}

#if DEBUG
template <class TClass> std::ostream &operator<<(std::ostream &o, const ListIterator<TClass> &l) {
	o << *(l.link);
	return o;
}
#endif

/**
 * List
 */

template<class TClass> List<TClass>::List() : head(NULL), tail(NULL) {}

template<class TClass> List<TClass>::~List() {
	ListIterator<TClass> iter(head);
	ListIterator<TClass> iter2(head);
	while (iter2 != end()) {
		#if DEBUG
			std::cout << "Deleting " << iter << std::endl;
		#endif
		iter2.link=iter.link->next;
		delete iter.link;
		iter = iter2;
	}
}

template<class TClass> void List<TClass>::push_back(TClass* obj) {
	ListLink<TClass>* link = tail;
	ListLink<TClass>* newLink = new ListLink<TClass>(obj);
	if (head == NULL) {
		head = newLink;
	} else {
		link->setNext(newLink);

	}
	tail = newLink;
}

template<class TClass> void List<TClass>::push_front(TClass* obj) {
	ListLink<TClass>* link = head;
	ListLink<TClass>* newLink = new ListLink<TClass>(obj);
	if (head == NULL) {
		tail = newLink;
	} else {
		newLink->setNext(link);
	}
	head = newLink;
}

template<class TClass> void List<TClass>::insert(List<TClass>::iterator& iter, TClass* obj) {

	if (iter == end()) {
		push_back(obj);
	} else {
		ListLink<TClass>* newLink = new ListLink<TClass>(obj);
		newLink->setNext(iter.link->next);
		iter.link->setNext(newLink);
	}
}

template<class TClass> ListLink<TClass>* List<TClass>::begin() const {
	return head;
}

template<class TClass> ListLink<TClass>* List<TClass>::end() const {
	return NULL;
}

#if DEBUG
template <class TClass> std::ostream &operator<<(std::ostream &o, const List<TClass> &l) {

	ListIterator<TClass> i;

	o << "List: " << l.head << " " << l.tail << "; ";

	o << "{";

	for (i = l.begin(); i != l.end(); ++i) {
		o << i << " ";
	}

	o << "}" << std::endl;

	return o;
}
#endif

