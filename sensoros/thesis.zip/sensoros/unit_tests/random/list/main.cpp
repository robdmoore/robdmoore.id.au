/**
 * List Class Development Unit Test
 * Example Result of correct invocation:
 *
$ ./a.exe
0x6a0288,0x6a0298,0x6a02a8,0x6a02b8,0x6a02c8
--
List: 0 0; {}
List: 0x6b02f0 0x6b02f0; {(0,0x6a0288) }
List: 0x6b0300 0x6b02f0; {(0x6b02f0,0x6a0298) (0,0x6a0288) }
List: 0x6b0300 0x6b0310; {(0x6b02f0,0x6a0298) (0x6b0310,0x6a0288) (0,0x6a02a8) }

List: 0x6b0300 0x6b0310; {(0x6b02f0,0x6a0298) (0x6b0320,0x6a0288) (0x6b0310,0x6a
02b8) (0,0x6a02a8) }
List: 0x6b0330 0x6b0310; {(0x6b0300,0x6a02c8) (0x6b02f0,0x6a0298) (0x6b0320,0x6a
0288) (0x6b0310,0x6a02b8) (0,0x6a02a8) }
--
5
2
1
4
3
Deleting (0x6b0300,0x6a02c8)
Deleting (0x6b02f0,0x6a0298)
Deleting (0x6b0320,0x6a0288)
Deleting (0x6b0310,0x6a02b8)
Deleting (0,0x6a02a8)
 *
 */

#define DEBUG 1

#include "list.cpp"

/**
 * 5, 2, 1, 4, 3
 */

class Test {

	public:
		Test(int test) : test(test) {};
		int test;
};

int main() {

	Test* t1 = new Test(1);
	Test* t2 = new Test(2);
	Test* t3 = new Test(3);
	Test* t4 = new Test(4);
	Test* t5 = new Test(5);

	std::cout << t1 << "," << t2 << "," << t3 << "," << t4 << "," << t5 << std::endl << "--" << std::endl;

	List<Test>* l = new List<Test>();
	std::cout << *l;

	l->push_back(t1);
	std::cout << *l;

	List<Test>::iterator i(l->begin());

	l->push_front(t2);
	std::cout << *l;

	l->push_back(t3);
	std::cout << *l;

	l->insert(i, t4);
	std::cout << *l;

	l->push_front(t5);
	std::cout << *l;

	std::cout << "--" << std::endl;


	for (i=l->begin(); i != l->end(); ++i) {
		std::cout << (*i).test << std::endl;
	}

	delete l;

	delete t1;
	delete t2;
	delete t3;
	delete t4;
	delete t5;

	return 0;
}
