/**
 * CanLink Unit Test Application Network Information Header File
 *
 * @author Robert Moore <rob@mooredesign.com.au>
 * @version 1.0.0
 * @date 2009-07-21
 */

#ifndef _APPLICATION_NETWORK_INFO_H
#define _APPLICATION_NETWORK_INFO_H

typedef uint8_t node_address_t;
#define NODE_ADDRESS 1

#define MSCAN0 0 // Compile with Can0 Module enabled and set as link 0

#define LOOP_BACK 1 // Turn on Can loop back mode

#endif
