/**
 * SensorOS Can Link Class Unit Test
 *
 * Expected Result:
 *
 *	
 *
 * Successfully ran the test xxxx-xx-xx xx:xxXX GMT +8
 */

#include <main.h>

int main(void) {

	// Initialise Debug class (this would go in Platform::init())
	Debug::init();
	
	// Configure the network
	Network* network = Network::getInstance();
	// This would go in Platform::init()
	network->assignLink(&can0Link);
	// This would go in Application::init()
	TestNetwork* networkLayer = TestNetwork::getInstance();
	network->assignNetworkLayer(networkLayer);

	// Enable interrupts
	__enable_interrupts();
	
	// Send initial message
	// (this would go in a SIG_SYSTEM_BOOTED signal handler)
	if (networkLayer->send() != SUCCESS) {
		Debug::print("Error\r\n");
	}

	// Loop
	for(;;);

	return 0;
}
