/**
 * CanLink Unit Test Network Layer Header File
 *
 * @author Robert Moore <rob@mooredesign.com.au>
 * @version 1.0.0
 * @date 2009-07-21
 */

#ifndef _TEST_NETWORK_H
#define _TEST_NETWORK_H

class TestNetwork: implements NetworkLayer {
public:
	message_t* upFromDataLink(DataLinkLayer* linkLayer, message_t* msg,
						data_length_t length);
	error_t send();
	void sendDone(message_t* msg, error_t status);
	
	static TestNetwork* getInstance();
private:
	// Singleton instance
	static TestNetwork instance;
	// Used to round robin packet length for testing
	uint8_t length;
	// Array of message buffers
	message_t buffers[8];
	// Bit mask, a 1 indicates an unused buffer
	uint8_t used;
	// count the messages received
	uint16_t messageId;

	TestNetwork();
	message_t* getFreeBuffer();
};

#endif
