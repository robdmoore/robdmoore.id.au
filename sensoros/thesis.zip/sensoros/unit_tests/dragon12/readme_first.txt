Please note that since running most of these unit tests, the folder names of the application and platform the test were run against have changed.

	The platform folder name has been changed from clic2 to dragon12.
	The application folder name has been changed from phase1 to null.

Consequently, in order to be able to use these unit tests, you will need to change the include paths to point to the new locations and re-add the source files from the correct locations.

The IAR_null unit test has the correct include paths as an example.

All unit tests in this folder have passed, except for a strange anomoloy in the IAR_CanLinkUnitTest test that has not been resolved and the IAR_null test, which has not been preoperly tested and debugged yet.

Robert Moore
30/10/2009