/**
 * SensorOS Interrupt Vectors Unit Test Case
 *
 * Expected Result (on COM port):
 *
 *	5
 *	2
 *	1
 *	4
 *	3
 *
 * Successfully ran the test 2009-06-01 02:33PM GMT +8
* Edited and successfully re-run 2009-07-06 17:34PM GMT +8
 */

#include <platform.h>
#include <list.h>

class Test {

	public:
		Test(uint8_t test) : test(test) {};
		uint8_t test;
};

int main(void) {
	
	// Initialise Debug class
	Debug::init();

	// Create test objects
	Test* t1 = new Test(1);
	Test* t2 = new Test(2);
	Test* t3 = new Test(3);
	Test* t4 = new Test(4);
	Test* t5 = new Test(5);

	// Create list
	List<Test>* l = new List<Test>();

	// Add 1 to tail
	l->push_back(t1);

	// Get iterator pointing to 1
	List<Test>::iterator i(l->begin());

	// Add 2 to head
	l->push_front(t2);

	// Add 3 to tail
	l->push_back(t3);

	// Add 4 after 1
	l->insert(i, t4);

	// Add 5 to head
	l->push_front(t5);

	// Iterate list and print to COM
	for (i=l->begin(); i != l->end(); ++i) {
		Debug::printf("%d\r\n", (*i).test);
	}
	
	// Loop forever
	while (1) {}
	
	return 0;
}
