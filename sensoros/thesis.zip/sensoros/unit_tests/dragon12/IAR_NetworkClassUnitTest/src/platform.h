/**
 * Platform.h file for Network Class Unit Test
 * @author Robert Moore <rob@mooredesign.com.au>
 * @date 2009-07-05
 */

 #ifndef _PLATFORM_H
 #define _PLATFORM_H

	// Atomic Section
	#define Atomic {atomic_t atomicValue = __atomic_start();
	#define EndAtomic __atomic_end(atomicValue);}

 	#define NUM_DATA_LINKS (3)

 	#include "inttypes.h"
	#include <hcs12registers.h>
 	#include "debug.h"

	#define NULL (0)

	/**
	 * Atomic Start and End Functions and type typedef
	 */
	
	// Need 16-bit value to store 16-bit D register (see functions below)
	typedef uint16_t atomic_t;
	
	// Declare external protypes for atomic start and end functions
	extern "C" {
		extern atomic_t __atomic_start(void);
		extern void __atomic_end(atomic_t originalCcrValue);
		// Stores SP to given address
		extern uint16_t __get_stack_pointer();
	}

 	typedef uint8_t link_id_t;
 	typedef uint8_t node_address_t;

	typedef struct {
		uint8_t data;
	} packet_t;
	
	#define NODE_ADDRESS 1

 #endif
