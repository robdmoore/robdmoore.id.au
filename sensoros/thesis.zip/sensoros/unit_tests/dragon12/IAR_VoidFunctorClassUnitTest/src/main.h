/**
 * Main.h file for Network Class Unit Test
 * @author Robert Moore <rob@mooredesign.com.au>
 * @date 2009-05-07
 */

 #ifndef _MAIN_H
 #define _MAIN_H

	#include "interface.h"
	#include "platform.h"
	#include "network.h"
	#include "void_functor.h"

 #endif
