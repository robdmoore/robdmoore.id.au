/**
 * Main.h file for Scheduler Class Unit Test
 * @author Robert Moore <rob@mooredesign.com.au>
 * @date 2009-05-07
 */

 #ifndef _MAIN_H
 #define _MAIN_H

	// Atomic Section
	#define Atomic {atomic_t atomicValue = __atomic_start();
	#define EndAtomic __atomic_end(atomicValue);}

	#include "platform.h"
	#include "void_functor.h"
	#include "scheduler.h"

 #endif
