/**
 * Dragon12 Debug Class Unit Test Case
 *
 * Expected result when stepping through below function calls:
 * 	leds(0xF0): Last 4 leds highlighted, first four off
 *	leds(1, 0): First led on
 *	leds(0, 7): Last led off
 *	toggleLed(4): LED 4 off
 *	printf(...): "My debug string (3)" shows up on serial port 0
 *
 *	End Result: Leds: ()(+)(+)()()()()(+)
 *
 * Successfully ran the test 2009-05-07 11:10PM GMT +8
* Edited and successfully re-run 2009-07-05 18:58PM GMT +8
 */

#include <main.h>

int main(void) {

	Debug::init();

	Debug::leds(0xF0);
	Debug::leds(1, 0);
	Debug::leds(0, 7);
	Debug::toggleLed(4);
	
	Debug::printf("My debug string (%d)!\r\n", 3);
}
