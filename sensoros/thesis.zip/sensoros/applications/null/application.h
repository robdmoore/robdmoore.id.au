/**
 * Null Application Class Definition File
 *
 * @author Robert Moore <rob@mooredesign.com.au>
 * @version 1.2.0
 * @date 2009-07-21
 */

#ifndef _APPLICATION_H
#define _APPLICATION_H

class Application {

	public:
		static void init();
		static void main();
};

#endif
