/**
 * Null Application Class Implementation File
 *
 * @author Robert Moore <rob@mooredesign.com.au>
 * @version 1.1.0
 * @date 2009-09-22
 */

#include <main.h>

static const VoidStaticFunctor mainFunctor(&Application::main);

/**
 * Initialises the application before interrupts are enabled
 */
void Application::init() {
	Debug::print("Application::init()\r\n");
	(SignalRouter::getInstance())->registerHandler(SIG_SYSTEM_BOOTED, &mainFunctor);
}

/**
 * Runs the application after the system has finished initialising
 */
void Application::main() {
	Debug::print("Application::main()\r\n");
}

