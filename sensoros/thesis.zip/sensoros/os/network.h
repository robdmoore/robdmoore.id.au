/**
 * SensorOS Network Class Description
 *
 * @author Robert Moore <rob@mooredesign.com.au>
 * @date 2009-07-17
 * @version 1.2.0
 */

#ifndef _NETWORK_H
#define _NETWORK_H

// message_t
typedef struct {
	uint8_t header[sizeof(message_header_t)];
	uint8_t data[MAX_DATA_BYTES];
	uint8_t footer[sizeof(message_footer_t)];
	uint8_t metadata[sizeof(message_metadata_t)];
} message_t;
#define MESSAGE_HEADER(msg, type) ((type*)((msg)->data-sizeof(type)))
#define MESSAGE_FOOTER(msg, type) ((type*)((msg)->footer))
#define MESSAGE_FOOTER_CONTIGUOUS(msg, type) ((type*)((msg)->footer)-getPayloadLength(msg))
#define MESSAGE_METADATA(msg, type) ((type*)((msg)->metadata))

// Network Interfaces
#include <data_link_layer.h>
#include <network_layer.h>

// Class definition
class Network {
	public:
		static Network* getInstance();
		void assignLink(DataLinkLayer* link);
		DataLinkLayer* getLink(link_id_t linkId);
		void assignNetworkLayer(NetworkLayer* networkLayer);
		NetworkLayer* getNetworkLayer();
		link_id_t getNumLinks();
		node_address_t getNodeAddress();
		~Network();

	private:
		node_address_t nodeAddress;
		link_id_t nLinks;
		static Network instance;

		DataLinkLayer* dataLinks[NUM_DATA_LINKS];
		NetworkLayer* networkLayer;

		Network();
};

#endif
