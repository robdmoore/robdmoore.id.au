/**
 * SensorOS Void Functor Definition File
 *
 * @author Robert Moore <rob@mooredesign.com.au>
 * @date 2009-05-07
 * @version 1.0.0
 */

#ifndef _VOID_FUNCTOR_H
#define _VOID_FUNCTOR_H

class VoidFunctor {
	public:
		virtual void operator()(void) const=0;
};
template <class TClass> class VoidInstanceFunctor : public VoidFunctor {

	private:
		void (TClass::*funcPtr)(void);
		TClass* objPtr;
	public:
		VoidInstanceFunctor(TClass* objPtr, void(TClass::*funcPtr)(void))
			: objPtr(objPtr), funcPtr(funcPtr) {};

		void operator()(void) const {
			(*objPtr.*funcPtr)();
		};
};
class VoidStaticFunctor : public VoidFunctor {

	private:
		void (* funcPtr)(void);
	public:
		VoidStaticFunctor(void (* funcPtr)(void)) : funcPtr(funcPtr) {};

		void operator()(void) const {
			(*funcPtr)();
		};
};

#endif
