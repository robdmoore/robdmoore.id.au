/**
 * SensorOS Main Include File
 *
 * Contains atomic section and interface macros as well as
 * 	includes for all the header files needed by the OS.
 *
 * @author Robert Moore <rob@mooredesign.com.au>
 * @date 2009-04-14
 * @version 1.1.0
 */

#ifndef _MAIN_H
#define _MAIN_H

// error_t Definition, copied from TinyOS: tos/types/TinyError.h
typedef enum {
	SUCCESS =  0,
	FAIL,		// Generic failure
	ESIZE,		// Parameter passed in was too big
	ECANCEL,	// Operation cancelled
	EOFF,		// Subsystem is not active
	EBUSY,		// The underlying system is busy; retry later
	EINVAL,		// An invalid parameter was passed
	ERETRY,		// A rare and transient failure: can retry
	ERESERVE,	// Reservation required before usage
	EALREADY,	// The device state you are requesting is already set
	ENOMEM,		// Memory required not available
	ENOACK,		// A packet was not acknowledged
	EFULL,		// Queue or buffer is full
	ELAST		// Last enum value
} error_t;

// Interface Definition
#include <interface.h>

// Atomic Section
#define Atomic {atomic_t atomicValue = __atomic_start();
#define EndAtomic __atomic_end(atomicValue);}

// Void Functor Definitions
#include <void_functor.h>

// signal_t Type
typedef enum {
	SIG_SOFTWARE_INIT=0,
	SIG_SYSTEM_BOOTED,
	#include <platform_signals.h> // Can define a max of 127 signals
	#include <application_signals.h> // Can define a max of 127 signals
	NUM_SIGNALS // Must be last!
} signal_t;

// Platform
#include <platform.h>

// Application (should be included in platform.h, but here just in case)
#include <application.h>

// Scheduler
#include <scheduler.h>

// SignalRouter
typedef uint8_t signal_iterator_t; // NUM_SIGNALS can't be more than 256
#include <signal_router.h>

// Network
#include <network.h>

#endif
