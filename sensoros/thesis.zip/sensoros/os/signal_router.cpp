/**
 * SensorOS Signal Router Class
 *
 * @author Robert Moore <rob@mooredesign.com.au>
 * @date 2009-04-16
 * @version 1.1.0
 */

#include <main.h>

SignalRouter SignalRouter::instance;

/**
 * Returns the singleton instance of the SignalRouter class
 * @return The instance
 */
SignalRouter* SignalRouter::getInstance() {

	return &instance;
}

/**
 * SignalRouter destructor: deletes dynamically allocated handler lists
 */
SignalRouter::~SignalRouter() {

	for (signal_iterator_t i = 0; i<NUM_SIGNALS; i++) {
		if (handlers[i] != NULL) {
			delete handlers[i];
		}
	}

}

/**
 * Signals to the signal router that a particular event
 * 	has occurred and any registered event handlers for
 * 	that signal should be notified
 * @param signal The signal that has occurred
 */
void SignalRouter::signal(signal_t signal) {

	if (handlers[signal] != NULL) {

		HandlerList::iterator iter;

		// Loop through list of event handlers
		for (iter = handlers[signal]->begin(); iter != handlers[signal]->end(); ++iter) {
			// Call the current handler
			(*iter)();
		}
	}

}

/**
 * Registers a functor to be called when a particular event occurs
 * Dynamically allocates memory, either explicitly for a list or implicitly
 * 	via List::push_back()
 */
void SignalRouter::registerHandler(signal_t signal, VoidFunctor const* handler) {

	// If there is no handler list defined for this signal then create one
	if (handlers[signal] == NULL) {
		handlers[signal] = new HandlerList();
	}

	// Add the event handler to the end of the list of handlers
	// 	for this signal
	handlers[signal]->push_back(handler);

}

/**
 * SignalRouter constructor: sets all handler list pointers to NULL
 */
SignalRouter::SignalRouter() {
	
	uint16_t n = sizeof(handlers);
	uint8_t* ptr = (uint8_t*)handlers;
	for (; 0 < n; ++ptr, --n)
		*ptr = 0;
}
