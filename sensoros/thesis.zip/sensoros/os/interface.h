/**
 * SensorOS Interface Definition File
 *
 * Replicates Java Interface semantics in C++
 *
 * @author Robert Moore <rob@mooredesign.com.au>
 * @date 2009-05-07
 * @version 1.0.0
 */

#ifndef _INTERFACE_H
#define _INTERFACE_H

	// Interface
	#define Interface(name) \
		class name { \
			public: \
				virtual ~name() {};
	#define EndInterface }
	#define implements public

#endif
