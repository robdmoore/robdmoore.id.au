/**
 * Dragon12 Debug class implementation file
 *
 * @author Robert Moore <rob@mooredesign.com.au>
 * @version 1.0.0
 * @date 2009-05-07
 */


#include <main.h>

#if DEBUG_OFF

	void Debug::print(const char* string) {}
	void Debug::printf(const char* format, ...) {}
	void Debug::leds(uint8_t ledsValue) {}
	void Debug::leds(bool ledValue, uint8_t led) {}
	void Debug::toggleLed(uint8_t led) {}
	void Debug::init(void) {}

#else

	#include <stdio.h>
	#include <stdarg.h>

	/**
	 * Prints a static string
	 *
	 * Prints the given string to Serial Communications Interface (SCI) 0
	 *
	 * @param string The string to print
	 */
	void Debug::print(const char* string) {
		// Enter atomic section (this is a slow process)
		Atomic
			// Until null terminator
			while (*string) {
				// Wait until the transmit buffer is ready for another character
				while((SCI0SR1 & TDRE) == 0){};
				// Add the next character to the buffer
				SCI0DRL = *string;
				// Increment the string pointer
				string++;	
			}
		// End atomic section
		EndAtomic;
	}

	/**
	 * Prints a formatted string
	 *
	 * Prints the given format string to Serial Communications Interface (SCI) 0
	 * Uses the same syntax as the C stdio printf function
	 *
	 * @param format The format string
	 * @param ... Any values referenced in the format string
	 */	
	void Debug::printf(const char* format, ...) {

		// Create a 100 char array to store the printf'd string
		char debugString[100];
		va_list ap;
		
		// Create the variable list pointer
		// CodeWarrior seems to throw a warning at this line,
		//	saying result of function-call ignored, which
		//	is ridiculous, because it doesn't return anything.
		va_start(ap, format);
		
		// Call the vsprintf function
		vsprintf(debugString, format, ap);
		
		// Kill the variable list pointer
		va_end(ap);
		
		// Call the Debug::print method with the sprintf'd string
		Debug::print(debugString);
	}

	/**
	 * Lights a number of LEDs based on an integer value
	 *
	 * If the integer given is say 6, then LED 1 and 2 will be lit
	 * 	but LED 0 won't be
	 *
	 * @param ledsValue The value to set the leds to
	 */	
	void Debug::leds(uint8_t ledsValue) {
		PORTB = ledsValue;
	}

	/**
	 * Lights (or unlights) a specific LED
	 *
	 * @param ledValue Whether to light (true) or unlight
	 * 	(false) the LED
	 * @param led The LED to modify (0-7)
	 */
	void Debug::leds(bool ledValue, uint8_t led) {
		if (ledValue) {
			PORTB |= (0x01 << led);
		} else {
			PORTB &= ~(0x01 << led);
		}
	}

	/**
	 * Toggles a specific LED on or off
	 *
	 * @param led The LED to toggle (0-7)
	 */
	void Debug::toggleLed(uint8_t led) {
		PORTB ^= (0x01 << led);
	}

	/**
	 * Initialises the Debug class
	 */
	void Debug::init(void) {
		// Setup LEDs
		DDRB  = 0xff;	// Port B is output
		DDRJ  = 0xff;	// Port J is output
		DDRP  = 0xff;	// Port P is output
		PTJ = 0x00;		// Enable LEDs
		PTP = 0x00;		// Enable 7-segment displays
		
		// Setup SCI Serial Port
		SCI0BDH = 0; // Set baud rate to 19200
		SCI0BDL = 13;
		SCI0CR1 = 0; // 1 start bit, 8 data bits, 1 stop bit, no parity bits
		SCI0CR2 = 0x0C; // All interrupts disabled, transmitter and receiver enabled
	}

#endif
