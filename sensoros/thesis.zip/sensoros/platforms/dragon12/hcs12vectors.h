/**
 * HCS12 Interrupt Vectors Include File
 *
 * Defines interrupt vector locations and a helper define for
 * 	marking interrupt handler routines (INTERRUPT)
 *
 * History:
 *  Created by Dr. Han-Way Huang 2004-07-01
 *  Modified by Navid Mohaghegh 2006-12-13 to add MC9S12DP256 interrupts
 *  Modified by Robert Moore 2009-03-17 to make compatible with TinyOS
 *  Modified by Robert Moore 2009-04-16 to make compatible with SensorOS
 *
 * @author Dr. Han-Way Huang
 * @author Navid Mohaghegh
 * @author Robert Moore <rob@mooredesign.com.au>
 * @date 2009-15-05
 * @version 1.4.0
 */

#ifndef _H_hcs12vectors_h
#define _H_hcs12vectors_h

// Define vector base address
#ifndef VECTOR_BASE
	#define VECTOR_BASE 0xFF80
#endif

// Interrupt handler typedef: GNU
#ifdef __GNUC__
	#define  interrupt_t void __attribute__((interrupt))
	// Define macro to allow ISR's to be registered
	// http://www.embedded.com/columns/programmingpointers/192503651
	typedef void (*pointer_to_ISR)(void);
	#define SET_ISR(VECTOR, ISR) *reinterpret_cast<pointer_to_ISR *>(VECTOR) = ISR
#endif
// Interrupt Handler typedef: IAR
#ifdef __IAR__
	#define interrupt_t __interrupt void
	// IAR uses a #pragma to define vector addresses, make SET_ISR to nothing
	#define SET_ISR(VECTOR, ISR)
#endif

// Define macro to help define the interrupt vector locations (below)
#define VECTOR_ADDR(offset)      (VECTOR_BASE + offset*2)

// Interrupt vector locations
#define	INT80_VECTOR		VECTOR_ADDR(0)	//INT80 reserved for future use
#define	INT82_VECTOR		VECTOR_ADDR(1)	//INT82 reserved for future use
#define	INT84_VECTOR		VECTOR_ADDR(2)	//INT84 reserved for future use
#define	INT86_VECTOR		VECTOR_ADDR(3)	//INT86 reserved for future use
#define	INT88_VECTOR		VECTOR_ADDR(4)	//INT88 reserved for future use
#define	INT8A_VECTOR		VECTOR_ADDR(5)	//INT8A reserved for future use
#define	PWMES_VECTOR		VECTOR_ADDR(6)	//PWM Emergency Shutdown
#define	PORTP_VECTOR		VECTOR_ADDR(7)	//Port P Interrupt
#define	MSCAN4TX_VECTOR		VECTOR_ADDR(8)	//MSCAN 4 transmit
#define	MSCAN4RX_VECTOR		VECTOR_ADDR(9)	//MSCAN 4 receive
#define	MSCAN4ERRS_VECTOR	VECTOR_ADDR(10)	//MSCAN 4 errors
#define	MSCAN4WAKE_VECTOR	VECTOR_ADDR(11)	//MSCAN 4 wake-up
#define	MSCAN3TX_VECTOR		VECTOR_ADDR(12)	//MSCAN 3 transmit
#define	MSCAN3RX_VECTOR		VECTOR_ADDR(13)	//MSCAN 3 receive
#define	MSCAN3ERRS_VECTOR	VECTOR_ADDR(14)	//MSCAN 3 errors
#define	MSCAN3WAKE_VECTOR	VECTOR_ADDR(15)	//MSCAN 3 wake-up
#define	MSCAN2TX_VECTOR		VECTOR_ADDR(16)	//MSCAN 2 transmit
#define	MSCAN2RX_VECTOR		VECTOR_ADDR(17)	//MSCAN 2 receive
#define	MSCAN2ERRS_VECTOR	VECTOR_ADDR(18)	//MSCAN 2 errors
#define	MSCAN2WAKE_VECTOR	VECTOR_ADDR(19)	//MSCAN 2 wake-up
#define	MSCAN1TX_VECTOR		VECTOR_ADDR(20)	//MSCAN 1 transmit
#define	MSCAN1RX_VECTOR		VECTOR_ADDR(21)	//MSCAN 1 receive
#define	MSCAN1ERRS_VECTOR	VECTOR_ADDR(22)	//MSCAN 1 errors
#define	MSCAN1WAKE_VECTOR	VECTOR_ADDR(23)	//MSCAN 1 wake-up
#define	MSCAN0TX_VECTOR		VECTOR_ADDR(24)	//MSCAN 0 transmit
#define	MSCAN0RX_VECTOR		VECTOR_ADDR(25)	//MSCAN 0 receive
#define	MSCAN0ERRS_VECTOR	VECTOR_ADDR(26)	//MSCAN 0 errors
#define	MSCAN0WAKE_VECTOR	VECTOR_ADDR(27)	//MSCAN 0 wake-up
#define	FLASH_VECTOR		VECTOR_ADDR(28)	//FLASH
#define	EEPROM_VECTOR		VECTOR_ADDR(29)	//EEPROM
#define	SPI2_VECTOR			VECTOR_ADDR(30)	//SPI2
#define	SPI1_VECTOR			VECTOR_ADDR(31)	//SPI1
#define	IIC_VECTOR			VECTOR_ADDR(32)	//IIC Bus
#define	DLC_VECTOR			VECTOR_ADDR(33)	//DLC
#define	SCME_VECTOR			VECTOR_ADDR(34)	//SCME
#define	CRG_VECTOR			VECTOR_ADDR(35)	//CRG lock
#define	PACCBOVF_VECTOR		VECTOR_ADDR(36)	//Pulse Accumulator B Overflow
#define	MODDWNCTR_VECTOR	VECTOR_ADDR(37)	//Modulus Down Counter underflow
#define	PORTH_VECTOR		VECTOR_ADDR(38)	//Port H
#define	PORTJ_VECTOR		VECTOR_ADDR(39)	//Port J
#define	ATOD1_VECTOR		VECTOR_ADDR(40)	//ATD1
#define	ATOD0_VECTOR		VECTOR_ADDR(41)	//ATD0
#define	SCI1_VECTOR			VECTOR_ADDR(42)	//SCI1
#define	SCI0_VECTOR			VECTOR_ADDR(43)	//SCI0
#define	SPI0_VECTOR			VECTOR_ADDR(44)	//SPI0
#define	PACCEDGE_VECTOR		VECTOR_ADDR(45)	//Pulse Accumulator input edge
#define	PACCAOVF_VECTOR		VECTOR_ADDR(46)	//Pulse accumulator A overflow
#define	TIMEROVF_VECTOR		VECTOR_ADDR(47)	//Timer overflow
#define	TIMERCH7_VECTOR		VECTOR_ADDR(48)	//Timer channel 7
#define	TIMERCH6_VECTOR		VECTOR_ADDR(49)	//Timer channel 6
#define	TIMERCH5_VECTOR		VECTOR_ADDR(50)	//Timer channel 5
#define	TIMERCH4_VECTOR		VECTOR_ADDR(51)	//Timer channel 4
#define	TIMERCH3_VECTOR		VECTOR_ADDR(52)	//Timer channel 3
#define	TIMERCH2_VECTOR		VECTOR_ADDR(53)	//Timer channel 2
#define	TIMERCH1_VECTOR		VECTOR_ADDR(54)	//Timer channel 1
#define	TIMERCH0_VECTOR		VECTOR_ADDR(55)	//Timer channel 0
#define	RTI_VECTOR			VECTOR_ADDR(56)	//Real Time Interrupt
#define	IRQ_VECTOR			VECTOR_ADDR(57)	//IRQ
#define	XIRQ_VECTOR			VECTOR_ADDR(58)	//XIRQ
#define	SWI_VECTOR			VECTOR_ADDR(59)	//SWI
#define	TRAP_VECTOR			VECTOR_ADDR(60)	//Unimplemented instruction trap
#define	COPFAIL_VECTOR		VECTOR_ADDR(61)	//COP failure reset
#define	COPMONFAIL_VECTOR	VECTOR_ADDR(62)	//Clock Monitor fail reset
#define	RESET_VECTOR		VECTOR_ADDR(63)	//Reset
// End interrupt vector locations

#endif

