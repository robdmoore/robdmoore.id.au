/**
 * Dragon12 Debug class definition file
 *
 * Uses char instead of uint8_t or int8_t to avoid compilation
 * 	problems. Doesn't matter in terms of portability because it's
 *	a processor-specific class.
 *
 * @author Robert Moore <rob@mooredesign.com.au>
 * @version 1.0.0
 * @date 2009-05-07
 */

#ifndef _DEBUG_H
#define _DEBUG_H

class Debug {

	public:
		static void print(const char* string);
		static void printf(const char* format, ...); // Note max of 100 character result
		static void leds(uint8_t ledsValue);
		static void leds(bool ledValue, uint8_t led);
		static void toggleLed(uint8_t led);
		static void init(void);
};


#endif
