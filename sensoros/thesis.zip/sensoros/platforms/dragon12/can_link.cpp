/**
 * CAN Link Class Implementation File for HCS12
 * 	with static declarations that can be enabled
 * 	using #define of CAN<X> where X is 0 - 5
 * 	and containing the link id.
 *
 * References:
 * 	Freescale Semiconductor Inc. 2005, Using MSCAN on the HCS12 Family (AN3034)
 * 	Motorola Inc. 2001, MSCAN Block Guide V02.15 (S12MSCANV2/D)
 *
 * @author Robert Moore <rob@mooredesign.com.au>
 * @version 1.1.0
 * @date 2009-07-18
 */

#include <main.h>

// Define the starting address for each CAN register set
// The const means the pointers are constant, the volatile means the values
// are volatile
// This should make it easier for the compiler to optimise out the use
// of these constants as opposed to directly referencing the register addresses
static volatile uint8_t* const CAN_START_ADDRESS[] = {&CAN0CTL0, &CAN1CTL0,
											&CAN2CTL0, &CAN3CTL0, &CAN4CTL0};

// Define MSCAN buffer type (abstraction of the bufferspace in MSCAN block
// 	memory)
typedef struct {
	uint8_t id3;
	uint8_t id2;
	uint8_t id1;
	uint8_t id0;
	uint8_t data[8];
	uint8_t length;
	uint8_t priority;
	uint16_t timestamp;
} mscan_buffer_t;

// Define the register offsets for each register
#define CTL0	0x00 // control register 0
#define CTL1	0x01 // control register 1
#define BTR0	0x02 // bus timing register 0
#define BTR1	0x03 // bus timing register 1
#define RFLG	0x04 // receiver flags
#define RIER	0x05 // receiver interrupt enables
#define TFLG	0x06 // transmit flags
#define TIER	0x07 // transmit interrupt enables
#define TARQ	0x08 // transmit message abort control
#define TAAK	0x09 // transmit message abort status
#define TBSEL	0x0a // transmit buffer select
#define IDAC	0x0b // identfier acceptance control
#define RXERR	0x0e // receive error counter
#define TXERR	0x0f // transmit error counter
#define IDAR0	0x10 // identifier acceptance register 0
#define IDAR1	0x11 // identifier acceptance register 1
#define IDAR2	0x12 // identifier acceptance register 2
#define IDAR3	0x13 // identifier acceptance register 3
#define IDMR0	0x14 // identifier mask register 0
#define IDMR1	0x15 // identifier mask register 1
#define IDMR2	0x16 // identifier mask register 2
#define IDMR3	0x17 // identifier mask register 3
#define IDAR4	0x18 // identifier acceptance register 4
#define IDAR5	0x19 // identifier acceptance register 5
#define IDAR6	0x1a // identifier acceptance register 6
#define IDAR7	0x1b // identifier acceptance register 7
#define IDMR4	0x1c // identifier mask register 4
#define IDMR5	0x1d // identifier mask register 5
#define IDMR6	0x1e // identifier mask register 6
#define IDMR7	0x1f // identifier mask register 7
#define RXFG	0x20 // rx foreground buffer (0x20 through 0x2f)
#define TXFG	0x30 // tx foreground buffer (0x30 through 0x3f)

// Define method to
#define CANREG(reg) (*(CAN_START_ADDRESS[this->canId]+reg))

/**
 * Constructor of the CanLink class
 * @param linkId The id of this DataLinkLayer
 * @param canId The id of the CAN module to use
 */
CanLink::CanLink(link_id_t linkId, uint8_t canId) : linkId(linkId), canId(canId) {
	// Initialise receiveBufferPointer
	recvBufferPtr = &initialRecvBuffer;
	// Initialise sendPointers
	sendPointer[0] = NULL;
	sendPointer[1] = NULL;
	sendPointer[2] = NULL;
	// Initialise the CAN link
	init();
}

/**
 * Gives a packet to send across the link
 *
 * @param destination The destination to send to, NULL if not applicable
 * 	or if broadcasting
 * @param msg A pointer to a message buffer containing the packet in the
 * 	data field
 * @param length The length of the packet to be sent
 * @param priority The local priority of the message, smaller is greater
 * 	set to NULL if not applicable
 *
 * @returns The success of the sending operation
 * 	SUCCESS If queuing the message for sending was successful
 *	ESIZE If length is greater than the value returned from
 * 		maxPayloadLength()
 * 	EFULL If the send queue is full
 * 	EINVAL If length is 0
 * 	FAIL If there was some other error sending
 */
error_t CanLink::downFromNetwork(node_address_t destination, message_t* msg,
								 data_length_t length, priority_t priority)
{
	
	error_t status = FAIL;
	uint8_t selectedBuffer;
	mscan_buffer_t* buffer = (mscan_buffer_t*)&CANREG(TXFG);
	
	// Check if there are any empty buffers
	if (!CANREG(TFLG)) {
		status = EFULL;
	// Check the length of the packet doesn't overflow
	// the amount that CAN can send
	} else if (length > 8) {
		status = ESIZE;
	} else if (length == 0) {
		status = EINVAL;
	} else {
		// Fill in the buffer inside an atomic section
		Atomic
			// Select the lowest empty buffer
			CANREG(TBSEL) = CANREG(TFLG);
			selectedBuffer = CANREG(TBSEL);
			// Load source id into IDR register
			buffer->id1 = NODE_ADDRESS;
			// Load destination id into IDR register
			buffer->id3 = destination;
			// Use CAN 2.0B (SRR=1, IDE=1)
			buffer->id2 = 0x18;
			// Set it as data packet (RTR = 1)
			buffer->id0 = 0x1;
			// Load data
			uint8_t n = (uint8_t)length;
			uint8_t* ptr = buffer->data;
			uint8_t* packet = msg->data;
			for (; 0 < n; ++ptr, --n, ++packet)
					*ptr = *packet;
			// Load data length
			buffer->length = length;
			// Load priority
			buffer->priority = priority;
			// Store buffer pointer
			sendPointer[selectedBuffer] = msg;
			// Send message
			CANREG(TFLG) = selectedBuffer;
			// Enable send interrupt
			CANREG(TIER) |= selectedBuffer;
		EndAtomic;
		// Return SUCCESS
		status = SUCCESS;
	}
	return status;
}

/**
 * Requests that the message pending sending in the given
 * 	message buffer not be sent
 *
 * @param msg Pointer to the message buffer with the message to cancel
 * 	the sending of
 *
 * @returns The status of the cancel attempt:
 * 	SUCCESS if the message was still pending
 * 	FAIL if the message had already been sent
 * 	EINVAL if the message buffer wasn't recognised
 */
error_t CanLink::cancel(message_t* msg) {
	error_t status = EINVAL;
	Atomic
		// Check to see if the message has been sent
		uint8_t buffer = getBuffer(msg);
		// Ensure the msg pointer was valid
		if (buffer < 0xFF) {
			uint8_t bit = 0x1;
			if (buffer > 0) bit <<= buffer;
			// Check if the message has already been sent
			if ((CANREG(TFLG) & bit) > 0) {
				status = FAIL;
			} else {
				// Submit an abort request
				CANREG(TARQ) |= bit;
				// Set status to SUCCESS (even though it's possible
				// 	it won't be cancelled, the sendDone event will rectify that
				//	though)
				status = SUCCESS;
			}
		}
	EndAtomic;
	return status;
}

/**
 * Called when the sending of a message is completed
 */
void CanLink::sendDone() {
	bool flagSet = FALSE;
	// Check all 3 buffers to see if sending was successful
	for (uint8_t buffer = 0; buffer < 3; ++buffer) {
		uint8_t bit = 0x1;
		if (buffer > 0) bit <<= buffer;
		// If there was a message being sent on this buffer
		//	and the buffer is now empty
		if (sendPointer[buffer] != NULL && (CANREG(TFLG) & bit) > 0) {
			error_t status = SUCCESS;
			// Check if there was a successful abort request
			if ((CANREG(TAAK) & bit) > 0) {
				status = ECANCEL;
			}
			// Signal sendDone to network layer for this message
			Network::getInstance()->getNetworkLayer()->sendDone(
												sendPointer[buffer], status);
			// Set the send pointer to NULL
			sendPointer[buffer] = NULL;
			// Disable the interrupt
			CANREG(TIER) &= ~bit;
			flagSet = TRUE;
		}
	}
	// If this ISR was called but no message was pending, clear all
	// 	three interrupts
	if (!flagSet) CANREG(TIER) = 0x0;
}

/**
 * Returns the buffer id of the send buffer corresponding to the
 * 	given message buffer pointer
 *
 * @param msg The message buffer pointer to use in the search
 *
 * @returns The buffer id, 0x0 -> 0x3, or 0xff if not found
 */
uint8_t CanLink::getBuffer(message_t* msg) {
	uint8_t buffer = 0xFF;
	// Check all 3 buffers to see if sending was successful
	for (uint8_t i = 0; i < 3; ++i) {
		if (sendPointer[i] == msg) {
			buffer = i;
			break;
		}
	}
	return buffer;
}

/**
 * Called when the physical layer attached to this link has received a frame
 * Gets the frame and passes the packet inside the frame to the network layer
 */
void CanLink::upFromPhysical() {

	mscan_buffer_t* buffer = (mscan_buffer_t*)&CANREG(RXFG);
	mscan_header_t* header = MESSAGE_HEADER(recvBufferPtr, mscan_header_t);
	mscan_footer_t* footer = MESSAGE_FOOTER(recvBufferPtr, mscan_footer_t);

	// Get id
	header->source = buffer->id1;
	header->destination = buffer->id3;

	// Get length
	footer->length = buffer->length & 0x0F;

	// Get data
	for(uint8_t i = 0; i < footer->length; ++i)
		recvBufferPtr->data[i] = buffer->data[i];

	// Get timestamp
	footer->timestamp = buffer->timestamp;

	// Release the foreground receive buffer / handshake the interrupt
	CANREG(RFLG) = RXF;

	// Pass up to network layer
	recvBufferPtr = Network::getInstance()->getNetworkLayer()->upFromDataLink(
										this, recvBufferPtr, footer->length);

}

/**
 * Returns the link id of the current link
 * @return The link id
 */
link_id_t CanLink::getLinkId() {

	return linkId;
}

/**
 * Returns the MTU of the CAN link
 * @return MTU of CAN Link
 */
data_length_t CanLink::maxPayloadLength() {

	// MTU is 8 bytes
	return 8;
}

/**
 * Returns the length of the payload in the given message buffer
 * @return Payload length
 */
data_length_t CanLink::getPayloadLength(message_t* msg) {

	return MESSAGE_FOOTER(msg, mscan_footer_t)->length;
}

/**
 * Returns the timestamp of the message in the given message buffer
 * @return Message timestamp
 */
timestamp_t CanLink::getTimestamp(message_t* msg) {

	return MESSAGE_FOOTER(msg, mscan_footer_t)->timestamp;
}

/**
 * Returns the source address of the message in the given message buffer
 * @return Message source
 */
node_address_t CanLink::getSource(message_t* msg) {

	return MESSAGE_HEADER(msg, mscan_header_t)->source;
}

/**
 * Returns the source address of the message in the given message buffer
 * @return Message source
 */
node_address_t CanLink::getDestination(message_t* msg) {

	return MESSAGE_HEADER(msg, mscan_header_t)->destination;
}

/**
 * Initialise the CAN link
 */
void CanLink::init() {

	// Atomic section
	Atomic

		// Enter init mode
		while ((CANREG(CTL1) & INITAK) == 0)
			CANREG(CTL0) = INITRQ;

		// In init mode the following registers can be set:
		// 	CANCTL1, CANBTR0, CANBTR1, CANIDAC, CANIDAR0-7, CANIDMR0-7

		// Enable CAN module
		CANREG(CTL1) |= CANE;

		// Turn off listen mode
		CANREG(CTL1) &= ~LISTEN;

		// Turn on loop-back mode if LOOP_BACK is true
		#if LOOP_BACK
			CANREG(CTL1) |= LOOPB;
		#endif

		// Use low-pass filter for wake-up interrupt trigger
		CANREG(CTL1) |= WUPM;

		// Set id acceptance filters
		CANREG(IDAC) = 0x20; // Eight 8-bit filters
		CANREG(IDAR0) = NODE_ADDRESS; // Look for packets addressed to this node
		CANREG(IDMR0) = 0x0;
		CANREG(IDAR1) = 0x0; // Look for broadcasted packets
		CANREG(IDMR1) = 0x0;
		// Ignore the other filters
		CANREG(IDMR2) = 0xFF;
		CANREG(IDMR3) = 0xFF;
		CANREG(IDMR4) = 0xFF;
		CANREG(IDMR5) = 0xFF;
		CANREG(IDMR6) = 0xFF;
		CANREG(IDMR7) = 0xFF;

		// Set default bit timing so CAN Standard Compliant Bit Timing is used
		CANREG(BTR0) = 0xC1;
		CANREG(BTR1) = 0xF7;
		
		// Signal init mode for this CAN module to the SignalRouter
		// 	this way, application-specific things such as bit timing can
		// 	be overwritten
		SignalRouter::getInstance()->signal(static_cast<signal_t>
											(SIG_CAN0_INIT+this->canId));

		// Leave init mode (set INITRQ to 0)
		CANREG(CTL0) = 0x0;
		
	EndAtomic;
	
	// Wait for sync
	//while ((CANREG(CTL0) & SYNCH) == 0) {}
	while ((CAN0CTL0 & SYNCH) == 0) {}
	
	// Enable wake up on WAIT mode
	CANREG(CTL0) |= WUPE;
	// Enable receive and wake up enable interrupts
	CANREG(RIER) = WUPIE | RXFIE;

	// In Normal mode the following registers can be set:
	// 	CANCTL0, CANRFLG, CANRIER, CANTFLG, CANTIER

}

/**
 * ISRs and static instances of the can links
 */
#ifdef MSCAN0
	extern CanLink can0Link(MSCAN0,0);
	#ifdef __IAR__
		#pragma vector=MSCAN0RX_VECTOR
	#endif
	interrupt_t can0RXISR(void) {
		// Signal a CAN 0 Receive event
		SignalRouter::getInstance()->signal(SIG_CAN0_RECV);
		// Call the upFromPhysical method for this link
		can0Link.upFromPhysical();
	}
	SET_ISR(MSCAN0RX_VECTOR, can0RXISR)
	#ifdef __IAR__
		#pragma vector=MSCAN0TX_VECTOR
	#endif
	interrupt_t can0TXISR(void) {
		// Signal a CAN 0 Send event
		SignalRouter::getInstance()->signal(SIG_CAN0_SENT);
		// Call the sendDone method for this link
		can0Link.sendDone();
	}
	SET_ISR(MSCAN0TX_VECTOR, can0TXISR)
#endif
#ifdef MSCAN1
	extern CanLink can1Link(MSCAN1,1);
	#ifdef __IAR__
		#pragma vector=MSCAN1RX_VECTOR
	#endif
	interrupt_t can1RXISR(void) {
		// Signal a CAN 1 Receive event
		SignalRouter::getInstance()->signal(SIG_CAN1_RECV);
		// Call the upFromPhysical method for this link
		can1Link.upFromPhysical();
	}
	SET_ISR(MSCAN1RX_VECTOR, can1RXISR)
	#ifdef __IAR__
		#pragma vector=MSCAN1TX_VECTOR
	#endif
	interrupt_t can1TXISR(void) {
		// Signal a CAN 1 Send event
		SignalRouter::getInstance()->signal(SIG_CAN1_SENT);
		// Call the sendDone method for this link
		can1Link.sendDone();
	}
	SET_ISR(MSCAN1TX_VECTOR, can1TXISR)
#endif
#ifdef MSCAN2
	extern CanLink can2Link(MSCAN2,2);
	#ifdef __IAR__
		#pragma vector=MSCAN2RX_VECTOR
	#endif
	interrupt_t can2RXISR(void) {
		// Signal a CAN 2 Receive event
		SignalRouter::getInstance()->signal(SIG_CAN2_RECV);
		// Call the upFromPhysical method for this link
		can2Link.upFromPhysical();
	}
	SET_ISR(MSCAN2RX_VECTOR, can2RXISR)
	#ifdef __IAR__
		#pragma vector=MSCAN2TX_VECTOR
	#endif
	interrupt_t can2TXISR(void) {
		// Signal a CAN 2 Send event
		SignalRouter::getInstance()->signal(SIG_CAN2_SENT);
		// Call the sendDone method for this link
		can2Link.sendDone();
	}
	SET_ISR(MSCAN2TX_VECTOR, can2TXISR)
#endif
#ifdef MSCAN3
	extern CanLink can3Link(MSCAN3,3);
	#ifdef __IAR__
		#pragma vector=MSCAN3RX_VECTOR
	#endif
	interrupt_t can3RXISR(void) {
		// Signal a CAN 3 Receive event
		SignalRouter::getInstance()->signal(SIG_CAN3_RECV);
		// Call the upFromPhysical method for this link
		can3Link.upFromPhysical();
	}
	SET_ISR(MSCAN3RX_VECTOR, can3RXISR)
	#ifdef __IAR__
		#pragma vector=MSCAN3TX_VECTOR
	#endif
	interrupt_t can3TXISR(void) {
		// Signal a CAN 3 Send event
		SignalRouter::getInstance()->signal(SIG_CAN3_SENT);
		// Call the sendDone method for this link
		can3Link.sendDone();
	}
	SET_ISR(MSCAN3TX_VECTOR, can3TXISR)
#endif
#ifdef MSCAN4
	extern CanLink can4Link(MSCAN4,4);
	#ifdef __IAR__
		#pragma vector=MSCAN4RX_VECTOR
	#endif
	interrupt_t can4RXISR(void) {
		// Signal a CAN 4 Receive event
		SignalRouter::getInstance()->signal(SIG_CAN4_RECV);
		// Call the upFromPhysical method for this link
		can4Link.upFromPhysical();
	}
	SET_ISR(MSCAN4RX_VECTOR, can4RXISR)
	#ifdef __IAR__
		#pragma vector=MSCAN4TX_VECTOR
	#endif
	interrupt_t can4TXISR(void) {
		// Signal a CAN 4 Send event
		SignalRouter::getInstance()->signal(SIG_CAN4_SENT);
		// Call the sendDone method for this link
		can4Link.sendDone();
	}
	SET_ISR(MSCAN4TX_VECTOR, can4TXISR)
#endif
