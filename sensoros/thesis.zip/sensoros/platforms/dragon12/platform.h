/**
 * Dragon12 Platform Include File
 *
 * Defines enable / disable interrupts routines, atomic start
 * 	and end routines, integer typedefs, hardware / vector
 * 	addresses, the signal_t type and the Platform class.
 *
 * @author Robert Moore <rob@mooredesign.com.au>
 * @version 1.2.0
 * @date 2009-04-14
 */

#ifndef _PLATFORM_H
#define _PLATFORM_H

/**
 * Platform define
 * Can be used to conditionally include application and platform-specific code
 * Should be used with caution, this sort of code should be minimised where possible
 */
#define PLATFORM_DRAGON12

/**
 * Compiler Defines
 * Can be used to ensure code is compiler independant
 * At this point in time, this platform is supported for GNU C compiler and IAR
 * 	Embedded Workbench, since IAR doesn't have any compiler macros to distinguish
 * 	it, __IAR__ is created below if the compiler isn't GNU C. If other compilers
 * 	are supported in the future this will need to be modified
 */
#ifndef __GNUC__
	#define __IAR__
#endif

// Set extended language for IAR
#ifdef __IAR__
	#pragma language=extended
#endif

/**
 * Platform Constants
 */
enum {
	NULL = 0,
	FALSE = 0,
	TRUE = 1,
	NUM_DATA_LINKS = 5, // Max number of data link layer links
	MAX_DATA_BYTES = 8 // Max number of data bytes in network packets
};

/**
 * Platform Types
 */
#include "inttypes.h"
typedef uint8_t link_id_t; // Based on MAX_DATA_LINKS
typedef uint8_t data_length_t; // Based on MAX_DATA_BYTES
typedef uint8_t priority_t; // For networking
typedef uint16_t timestamp_t; // For networking

// size_t definition
#if !defined(_SIZE_T) && !defined(_SIZET)
	#define _SIZE_T
	#define _SIZET
	typedef unsigned int size_t;
#endif

/**
 * Includes
 */
// Debug class
#include "debug.h"
// Register Constants
#include "hcs12registers.h"
// Vector Constants
#include "hcs12vectors.h"
	
/**
 * Application Network Information
 */
#include <application_network_info.h>

/**
 * Networking
 */
// MSCAN Message Buffer
typedef struct {
	node_address_t source;
	node_address_t destination;
} mscan_header_t;
typedef struct {
	data_length_t length;
	priority_t priority;
	timestamp_t timestamp;
} mscan_footer_t;
typedef struct {} mscan_metadata_t;
// All Message Buffers (Used in conjunction with sizeof() in
// 	message_t definition)
typedef union message_header {
	mscan_header_t mscan;
} message_header_t;
typedef union message_footer {
	mscan_footer_t mscan;
} message_footer_t;
typedef union message_metadata {
	mscan_metadata_t mscan;
} message_metadata_t;
// Network Class
#include <network.h>
// CAN Link Layer Class
#include "can_link.h"


/**
 * Disables interrupts
 */
#define __disable_interrupts() asm("sei")

/**
 * Enables interrupts
 */
#define __enable_interrupts() asm("cli")
	
/**
 * Atomic Start and End Functions and type typedef
 */

// Need 16-bit value to store 16-bit D register (see functions below)
typedef uint16_t atomic_t;

// Declare external protypes for atomic start and end functions
// Extern "C" required for IAR
extern "C" {
	atomic_t __atomic_start(void);
	void __atomic_end(atomic_t originalCcrValue);
	uint16_t __get_stack_pointer();
}

/**
 * Platform class definition
 */
class Platform {

	public:
		static void bootstrap();
		static void init();
		static void sleep();
};

#endif
