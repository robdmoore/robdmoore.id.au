Curtin University Department of Electrical and Computer Engineering Honours Thesis Latex Template
========================================================

Purpose: This Latex template ensures that you have a lot less to worry about in terms of your thesis layout because my template in combination with Latex's layout engine will take care of most of the formatting for you. The end result will be a very professional looking thesis that is miles more attractive than something generated from Word, and with less stress over things like page numbers and diagram layout.

Author: Robert Moore <rob@mooredesign.com.au>
Date: 30/10/2009
Version 1.0

Instructions
------------

1. Edit the fields between the comments in Thesis.tex
2. Add any references that you want to use to ref/references.bib as mentioned in that file
3. Add any thesis specific rules that need to go in the preamble to tex/thesis_specific_setup.tex
4. Add top level section headings to tex/content.tex and create appropriate .tex files in the tex/ directory to be included for each section (this is to make the thesis manageable rather than having thousands of lines of Latex code in one file).
5. Add the appendices to tex/appendix.tex using \section for the heading of each appendix (\subsection and \subsubsection can be used for sub sectioning)
6. To create the pdf run the following 4 commands from this directory (in this order, sometimes you will only need the first command (once, or possibly twice) if the references don't change, this assumes you have Latex (or Miktex if you are a Windows user) installed and in the command path):
	pdflatex Thesis.tex
	bibtex Thesis
	pdflatex Thesis.tex
	pdflatex Thesis.tex

Elements
--------

Level 1 heading (with label):
\section{Heading 1}
\ref{sec:LABEL}

Level 2 heading (with label):
\subsection{Heading 2}
\ref{sec:LEVEL1LABEL:LABEL}

Level 3 heading (with label):
\subsection{Heading 3}
\ref{sec:LEVEL1LABEL:LABEL}

Level 4 heading (use with caution, consider your structure if you need this):
\paragraph{Heading 4}

Bulletted list (same as itemize, but changes the spacing to work better with the double line spacing):
\begin{ul}
	\item Item 1
	\item Item 2
\end{ul}

Numbered list (same as enumerate, but changes the spacing to work better with the double line spacing):
\begin{ol}
	\item Item 1
	\item Item 2
\end{ol}

Figure (assuming a png graphic in an img folder, adds an entry to table of figures):
\begin{figure}[t]
  \label {fig:FIGURELABEL}
  \begin{center}
	\includegraphics[width=14cm]{img/IMAGENAME.png}
  \end{center}
  \caption{CAPTION}
\end{figure}

Table (adds an entry to list of tables):
\begin{table}[t]
	\label{table:LABEL}
	\begin{center}
		% Table code: using tabular, tabular*, tabularx, supertabular etc.
		\caption{CAPTION}
	\end{center}
\end{table}

Referencing a section, appendix, figure or table:
\ref{LABELNAME}
I recommend putting sec: before section labels, app: before appendix labels, table: before table labels and fig: before figure labels, it makes referencing so much less confusing. Also, for section labels (as shown above) I recommend having the top level title as sec:LABEL and all sub sections or sub sub sections under that as sec:LABEL:SUBSECTIONLABEL.

Inline Code Snippet (you might need to change the language, tex/setup.tex sets up C++ as the default language)
% To change the language do: \lstset{language=LANGUAGE}, see http://en.wikibooks.org/wiki/LaTeX/Packages/Listings for list of languages, or create your own like I did in my thesis_specific_setup.tex
\lstinline{INLINE Code}

Block code snippet
\begin{singlespace}
\begin{lstlisting}
	...
\end{lstlisting}
\end{singlespace}

Included file code snippet (assumes code folder)
\begin{singlespace}
\lstinputlisting{code/SOURCE_FILE.EXTENSION}
\begin{singlespace}

Notes
-----------

1. Use Subversion to manage the code; you won't regret it.
2. When you are ready to finalise the thesis you might need to tweak the layout a bit:

	If a line is orphaned before a page break, in particular if it's before a list you can add the following before it to force a line break:
		\needspace{5\baselineskip} % Ensure the first line of this paragraph doesn't appear along at the end of a page
	If there is an overfull box more than about 5pt (look at the log file), you can add optional hyphenation in the middle of words using \-, or you can rewrite the sentence. This won't work for \lstinline{}, for that I just broke the inline code into two \lstinline{}'s next to each other without a space and it broke it up properly. Underfull boxes are a bit more tricky, look on Google.
