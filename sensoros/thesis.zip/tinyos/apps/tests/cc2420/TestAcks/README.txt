README for TestAcks
Author/Contact: tinyos-help@millennium.berkeley.edu

Description:

Compile and install this application to two motes, both using ID 1

Expectations:
Led0 Toggles on a dropped ack
Led1 Toggles on a received ack
Led2 Toggles when a message is received

In short, Leds 1&2 should be toggling the majority of the time, until the other receiver
stops receiving packets by turning off or moving out of range.

Tools:

None.

Known bugs/limitations:

None.

$Id: README.txt,v 1.3 2008/07/26 02:32:44 klueska Exp $
