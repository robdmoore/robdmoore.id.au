/* autoconf.h.  Generated from autoconf.h.in by configure.  */
/* autoconf.h.in.  Generated from configure.ac by autoheader.  */

/* Name of package */
#define PACKAGE "cmotesdk"

/* Define to the address where bug reports for this package should be sent. */
#define PACKAGE_BUGREPORT ""

/* Define to the full name of this package. */
#define PACKAGE_NAME "cmotesdk"

/* Define to the full name and version of this package. */
#define PACKAGE_STRING "cmotesdk 1.0"

/* Define to the one symbol short name of this package. */
#define PACKAGE_TARNAME "cmotesdk"

/* Define to the version of this package. */
#define PACKAGE_VERSION "1.0"

/* Version number of package */
#define VERSION "1.0"
