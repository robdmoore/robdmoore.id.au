/**
 * HCS12 Inttypes definition file
 *
 * @author Robert Moore <rob@mooredesign.com.au>
 * @date 2009-11-09
 * @version 1.3.0
 */

#ifndef _INTTYPES_H
#define _INTTYPES_H

typedef unsigned char uint8_t;
typedef unsigned short uint16_t;
typedef unsigned long uint32_t;
typedef unsigned long long uint64_t;
typedef signed char int8_t;
typedef signed short int16_t;
typedef signed long int32_t;
typedef signed long long int64_t;
// Define ptrdiff_t if it hasn't already been defined by GCC
#ifndef _PTRDIFF_T
	#define _PTRDIFF_T
	typedef int16_t ptrdiff_t;
#endif

#endif
