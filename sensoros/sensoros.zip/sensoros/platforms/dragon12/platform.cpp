/**
 * Dragon12 Platform Implementation File
 *
 * @author Robert Moore <rob@mooredesign.com.au>
 * @version 1.1.0
 * @date 2009-09-22
 */

#include <main.h>

/**
 * Initialises the hardware at a very basic level
 * 	e.g. CPU / memory mode selection
 */
void Platform::bootstrap() {
	// Set up HCS12 for CLIC2
	MODE = 0x0A0; // Expanded narrow mode
	PEAR = 0x04; // Switch on clock and R/W signal
	MISC = 0x0F; // Disable first half of Flash EEPROM
}

/**
 * Initialise the hardware platform
 * Can post tasks to be run after the method is finished
 * 	if there are order dependant tasks
 */
void Platform::init() {

	#if !DEBUG_OFF
		Debug::init();
	#endif
	Network* network = Network::getInstance();
	#ifdef CAN0
		network->assignLink(&can0Link);
	#endif
	#ifdef CAN1
		network->assignLink(&can1Link);
	#endif
	#ifdef CAN2
		network->assignLink(&can2Link);
	#endif
	#ifdef CAN3
		network->assignLink(&can3Link);
	#endif
	#ifdef CAN4
		network->assignLink(&can4Link);
	#endif
}

/**
 * Puts the hardware into a low power mode when there are no
 * 	more tasks to run. It should exit this mode either after
 * 	a specified amount of time, or preferably when there is
 * 	an interrupt that requires the platform to perform some
 * 	action, e.g. network activity
 */
void Platform::sleep() {

	// @todo
}

#ifdef __GNUC__

/**
 * Saves the condition code register (CCR) and disables interrupts
 *
 * @return The status register contents
 */
atomic_t __atomic_start(void) {
	atomic_t ccrValue;
	// Rescue the CCR value into ccrValue via register a
	//  and disable interrupts (sei) atomically
	// Note: Have to use register d here or it won't compile
	//  for some reason
	asm volatile("tpa\nsei" : "=d"(ccrValue));
	// Reset the compilers' memory/register storage assumptions
	asm volatile("" ::: "memory");
	// Return the CCR value
	return ccrValue;
}

/**
 * Restores the CCR to it's original state (before __atomic_start)
 *
 * @param originalCcrValue The CCR value when __atomic_start was called
 */
void __atomic_end(atomic_t originalCcrValue) {
	// Reset the compilers' memory/register storage assumptions
	asm volatile("" ::: "memory");
	// Put the value from originalCcrValue into the CCR via register a
	// Note: Have to use register d here or it won't compile
	//  for some reason
	asm volatile("tap" :: "d"(originalCcrValue));
}

#endif
