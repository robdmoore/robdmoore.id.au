/**
 * HCS12 Register Constants Include File
 *
 * Defines address definitions to access registers and bits of registers
 *
 * History:
 *  Created by Dr. Han-Way Huang 2004-07-01
 *  Modified by Navid Mohaghegh 2006-12-13 to add MC9S12DP256 registers
 *  Modified by Robert Moore 2009-03-17 to make compatible with TinyOS
 *  Modified by Robert Moore 2009-04-27 to 2009-09-22 to make compatible with SensorOS
 *
 * @author Dr. Han-Way Huang
 * @author Navid Mohaghegh
 * @author Robert Moore <rob@mooredesign.com.au>
 * @version 3.1.0
 * @date 2009-09-22
 */

#ifndef _H_hcs12registers_h
#define _H_hcs12registers_h

// Register bits
#include "hcs12bits.h"

// Base Address of registers
#define REGISTER_BASE  0x0000

// GNU C Definitions
#ifdef __GNUC__

// Definitions to make it easier to define the registers
#define _IO8(offset)	*(volatile uint8_t*)(REGISTER_BASE + offset)
#define _IO16(offset)   *(volatile uint16_t*)(REGISTER_BASE + offset)

// Register address definitions
#define PORTA		_IO8(0x00)		//port a = address lines a8 - a15
#define PORTB		_IO8(0x01)		//port b = address lines a0 - a7
#define DDRA		_IO8(0x02)		//port a direction register
#define DDRB		_IO8(0x03)		//port a direction register

#define PORTE		_IO8(0x08)		//port e = mode,irqandcontrolsignals
#define DDRE		_IO8(0x09)		//port e direction register
#define PEAR		_IO8(0x0A)		//port e assignments
#define MODE		_IO8(0x0B)		//mode register
#define PUCR		_IO8(0x0C)		//port pull-up control register
#define RDRIV		_IO8(0x0D)		//port reduced drive control register
#define EBICTL		_IO8(0x0E)		//stretch control

#define INITRM		_IO8(0x10)		//ram location register
#define INITRG		_IO8(0x11)		//register location register
#define INITEE		_IO8(0x12)		//eeprom location register
#define MISC		_IO8(0x13)		//miscellaneous mapping control
#define MTST0		_IO8(0x14)		//reserved
#define ITCR		_IO8(0x15)		//interrupt test control register
#define ITEST		_IO8(0x16)		//interrupt test register
#define MTST1		_IO8(0x17)		//reserved

#define PARTIDH		_IO8(0x1a)		//part id high
#define PARTIDL		_IO8(0x1b)		//part id low
#define MEMSIZ0		_IO8(0x1c)		//memory size
#define MEMSIZ1		_IO8(0x1d)		//memory size
#define INTCR		_IO8(0x1e)		//interrupt control register
#define HPRIO		_IO8(0x1f)		//high priority reg

#define BKPCT0		_IO8(0x28)		//break control register
#define BKPCT1		_IO8(0x29)		//break control register
#define BKP0X		_IO8(0x2a)		//break 0 index register
#define BKP0H		_IO8(0x2b)		//break 0 pointer high
#define BKP0L		_IO8(0x2c)		//break 0 pointer low
#define BKP1X		_IO8(0x2d)		//break 1 index register
#define BKP1H		_IO8(0x2e)		//break 1 pointer high
#define BKP1L		_IO8(0x2f)		//break 1 pointer low
#define PPAGE		_IO8(0x30)		//program page register

#define PORTK		_IO8(0x32)		//port k data
#define DDRK		_IO8(0x33)		//port k direction
#define SYNR		_IO8(0x34)		//synthesizer / multiplier register
#define REFDV		_IO8(0x35)		//reference divider register
#define CTFLG		_IO8(0x36)		//reserved
#define CRGFLG		_IO8(0x37)		//pll flags register
#define CRGINT		_IO8(0x38)		//pll interrupt register
#define CLKSEL		_IO8(0x39)		//clock select register
#define PLLCTL		_IO8(0x3a)		//pll control register
#define RTICTL		_IO8(0x3b)		//real time interrupt control
#define COPCTL		_IO8(0x3c)		//watchdog control
#define FORBYP		_IO8(0x3d)		//crg force and bypass test register
#define CTCTL		_IO8(0x3e)		//crg test control register
#define ARMCOP		_IO8(0x3f)		//cop reset register

#define TIOS		_IO8(0x40)		//timer input/output select
#define CFORC		_IO8(0x41)		//timer compare force
#define OC7M		_IO8(0x42)		//timer output compare 7 mask
#define OC7D		_IO8(0x43)		//timer output compare 7 data
#define TCNT		_IO16(0x44)		//timer counter register hi

#define TSCR1		_IO8(0x46)		//timer system control register
#define TSCR		_IO8(0x46)		//timer system control register
#define TTOV		_IO8(0x47)		//reserved
#define TCTL1		_IO8(0x48)		//timer control register 1
#define TCTL2		_IO8(0x49)		//timer control register 2
#define TCTL3		_IO8(0x4a)		//timer control register 3
#define TCTL4		_IO8(0x4b)		//timer control register 4
#define TIE			_IO8(0x4c)		//timer interrupt mask 1
#define TMSK1		_IO8(0x4c)		////timer interrupt mask 1
#define TSCR2		_IO8(0x4d)		//timer interrupt mask 2
#define TMSK2		_IO8(0x4d)		//timer interrupt mask 2
#define TFLG1		_IO8(0x4e)		//timer flags 1
#define TFLG2		_IO8(0x4f)		//timer flags 2
#define TC0			_IO16(0x50)		//timer capture/compare register 0
#define TC1			_IO16(0x52)		//timer capture/compare register 1
#define TC2			_IO16(0x54)		//timer capture/compare register 2
#define TC3			_IO16(0x56)		//timer capture/compare register 3
#define TC4			_IO16(0x58)		//timer capture/compare register 4
#define TC5			_IO16(0x5a)		//timer capture/compare register 5
#define TC6			_IO16(0x5c)		//timer capture/compare register 6
#define TC7			_IO16(0x5e)		//timer capture/compare register 7
#define TACTL		_IO8(0x60)		//pulse accumulator controls
#define PACTL		_IO8(0x60)		//pulse accumulator controls
#define PAFLG		_IO8(0x61)		//pulse accumulator flags
#define PACNT		_IO16(0x62)		//pulse accumulator counter 3
#define PACN3		_IO8(0x62)		//pulse accumulator counter 3
#define PACN2		_IO8(0x63)		//pulse accumulator counter 2
#define PACN1		_IO8(0x64)		//pulse accumulator counter 1
#define PACN0		_IO8(0x65)		//pulse accumulator counter 0
#define MCCTL		_IO8(0x66)		//modulus down conunter control
#define MCFLG		_IO8(0x67)		//down counter flags
#define ICPAR		_IO8(0x68)		//input pulse accumulator control
#define DLYCT		_IO8(0x69)		//delay count to down counter
#define ICOVW		_IO8(0x6a)		//input control overwrite register
#define ICSYS		_IO8(0x6b)		//input control system control

#define TIMTST		_IO8(0x6d)		//timer test register

#define PBCTL		_IO8(0x70)		//pulse accumulator b control
#define PBFLG		_IO8(0x71)		//pulse accumulator b flags
#define PA3H		_IO8(0x72)		//pulse accumulator holding register 3
#define PA2H		_IO8(0x73)		//pulse accumulator holding register 2
#define PA1H		_IO8(0x74)		//pulse accumulator holding register 1
#define PA0H		_IO8(0x75)		//pulse accumulator holding register 0
#define MCCNT		_IO8(0x76)		//modulus down counter register
#define MCCNTL		_IO8(0x77)		//low byte
#define TC0H		_IO16(0x78)		//capture 0 holding register
#define TC1H		_IO16(0x7a)		//capture 1 holding register
#define TC2H		_IO16(0x7c)		//capture 2 holding register
#define TC3H		_IO16(0x7e)		//capture 3 holding register

#define ATD0CTL0	_IO8(0x80)		//adc control 0 (reserved)
#define ATD0CTL1	_IO8(0x81)		//adc control 1 (reserved)
#define ATD0CTL2	_IO8(0x82)		//adc control 2
#define ATD0CTL3	_IO8(0x83)		//adc control 3
#define ATD0CTL4	_IO8(0x84)		//adc control 4
#define ATD0CTL5	_IO8(0x85)		//adc control 5
#define ATD0STAT0	_IO8(0x86)		//adc status register 0
#define ATD0STAT	_IO16(0x86)		//adc status register 0
#define ATD0TEST0	_IO8(0x88)		//adc test (reserved)
#define ATD0TEST1	_IO8(0x89)		//adc test (reserved)

#define ATD0STAT1	_IO8(0x8b)		//adc status register 1
#define ATD0DIEN	_IO8(0x8d)		//adc input enable register

#define PORTAD0		_IO8(0x8f)		//port adc = input only
#define ATD0DR0		_IO16(0x90)		//adc result 0 register
#define ATD0DR1		_IO16(0x92)		//adc result 1 register
#define ATD0DR2		_IO16(0x94)		//adc result 2 register
#define ATD0DR3		_IO16(0x96)		//adc result 3 register
#define ATD0DR4		_IO16(0x98)		//adc result 4 register
#define ATD0DR5		_IO16(0x9a)		//adc result 5 register
#define ATD0DR6		_IO16(0x9c)		//adc result 6 register
#define ATD0DR7		_IO16(0x9e)		//adc result 7 register

#define PWME		_IO8(0xa0)		//pwm enable
#define PWMPOL		_IO8(0xa1)		//pwm polarity
#define PWMCLK		_IO8(0xa2)		//pwm clock select register
#define PWMPRCLK	_IO8(0xa3)		//pwm prescale clock select register
#define PWMCAE		_IO8(0xa4)		//pwm center align select register
#define PWMCTL		_IO8(0xa5)		//pwm control register
#define PWMTST		_IO8(0xa6)		//reserved
#define PWMPRSC		_IO8(0xa7)		//reserved
#define PWMSCLA		_IO8(0xa8)		//pwm scale a
#define PWMSCLB		_IO8(0xa9)		//pwm scale b
#define PWMSCNTA	_IO8(0xaa)		//reserved
#define PWMSCNTB	_IO8(0xab)		//reserved
#define PWMCNT0		_IO8(0xac)		//pwm channel 0 counter
#define PWMCNT1		_IO8(0xad)		//pwm channel 1 counter
#define PWMCNT2		_IO8(0xae)		//pwm channel 2 counter
#define PWMCNT3		_IO8(0xaf)		//pwm channel 3 counter
#define PWMCNT4		_IO8(0xb0)		//pwm channel 4 counter
#define PWMCNT5		_IO8(0xb1)		//pwm channel 5 counter
#define PWMCNT6		_IO8(0xb2)		//pwm channel 6 counter
#define PWMCNT7		_IO8(0xb3)		//pwm channel 7 counter
#define PWMPER0		_IO8(0xb4)		//pwm channel 0 period
#define PWMPER1		_IO8(0xb5)		//pwm channel 1 period
#define PWMPER2		_IO8(0xb6)		//pwm channel 2 period
#define PWMPER3		_IO8(0xb7)		//pwm channel 3 period
#define PWMPER4		_IO8(0xb8)		//pwm channel 4 period
#define PWMPER5		_IO8(0xb9)		//pwm channel 5 period
#define PWMPER6		_IO8(0xba)		//pwm channel 6 period
#define PWMPER7		_IO8(0xbb)		//pwm channel 7 period
#define PWMDTY0		_IO8(0xbc)		//pwm channel 0 duty cycle
#define PWMDTY1		_IO8(0xbd)		//pwm channel 1 duty cycle
#define PWMDTY2		_IO8(0xbe)		//pwm channel 2 duty cycle
#define PWMDTY3		_IO8(0xbf)		//pwm channel 3 duty cycle
#define PWMDTY4		_IO8(0xc0)		//pwm channel 0 duty cycle
#define PWMDTY5		_IO8(0xc1)		//pwm channel 1 duty cycle
#define PWMDTY6		_IO8(0xc2)		//pwm channel 2 duty cycle
#define PWMDTY7		_IO8(0xc3)		//pwm channel 3 duty cycle
#define PWMSDN		_IO8(0xc4)		//pwm shutdown register

#define SCI0BDH		_IO8(0xc8)		//sci 0 baud reg hi byte
#define SCI0BDL		_IO8(0xc9)		//sci 0 baud reg lo byte
#define SCI0CR1		_IO8(0xca)		//sci 0 control1 reg
#define SCI0CR2		_IO8(0xcb)		//sci 0 control2 reg
#define SCI0SR1		_IO8(0xcc)		//sci 0 status reg 1
#define SCI0SR2		_IO8(0xcd)		//sci 0 status reg 2
#define SCI0DRH		_IO8(0xce)		//sci 0 data reg hi
#define SCI0DRL		_IO8(0xcf)		//sci 0 data reg lo
#define SCI1BDH		_IO8(0xd0)		//sci 1 baud reg hi byte
#define SCI1BDL		_IO8(0xd1)		//sci 1 baud reg lo byte
#define SCI1CR1		_IO8(0xd2)		//sci 1 control1 reg
#define SCI1CR2		_IO8(0xd3)		//sci 1 control2 reg
#define SCI1SR1		_IO8(0xd4)		//sci 1 status reg 1
#define SCI1SR2		_IO8(0xd5)		//sci 1 status reg 2
#define SCI1DRH		_IO8(0xd6)		//sci 1 data reg hi
#define SCI1DRL		_IO8(0xd7)		//sci 1 data reg lo
#define SPI0CR1		_IO8(0xd8)		//spi 0 control1 reg
#define SPI0CR2		_IO8(0xd9)		//spi 0 control2 reg
#define SPI0BR		_IO8(0xda)		//spi 0 baud reg
#define SPI0SR		_IO8(0xdb)		//spi 0 status reg hi

#define SPI0DR		_IO8(0xdd)		//spi 0 data reg

#define IBAD		_IO8(0xe0)		//i2c bus address register
#define IBFD		_IO8(0xe1)		//i2c bus frequency divider
#define IBCR		_IO8(0xe2)		//i2c bus control register
#define IBSR		_IO8(0xe3)		//i2c bus status register
#define IBDR		_IO8(0xe4)		//i2c bus message data register

#define DLCBCR1		_IO8(0xe8)		//bdlc control regsiter 1
#define DLCBSVR		_IO8(0xe9)		//bdlc state vector register
#define DLCBCR2		_IO8(0xea)		//bdlc control register 2
#define DLCBDR		_IO8(0xeb)		//bdlc data register
#define DLCBARD		_IO8(0xec)		//bdlc analog delay register
#define DLCBRSR		_IO8(0xed)		//bdlc rate select register
#define DLCSCR		_IO8(0xee)		//bdlc control register
#define DLCBSTAT	_IO8(0xef)		//bdlc status register
#define SPI1CR1		_IO8(0xf0)		//spi 1 control1 reg
#define SPI1CR2		_IO8(0xf1)		//spi 1 control2 reg
#define SPI1BR		_IO8(0xf2)		//spi 1 baud reg
#define SPI1SR		_IO8(0xf3)		//spi 1 status reg hi

#define SPI1DR		_IO8(0xf5)		//spi 1 data reg

#define SPI2CR1		_IO8(0xf8)		//spi 2 control1 reg
#define SPI2CR2		_IO8(0xf9)		//spi 2 control2 reg
#define SPI2BR		_IO8(0xfa)		//spi 2 baud reg
#define SPI2SR		_IO8(0xfb)		//spi 2 status reg hi

#define SPI2DR		_IO8(0xfd)		//spi 2 data reg

#define FCLKDIV		_IO8(0x100)		//flash clock divider
#define FSEC		_IO8(0x101)		//flash security register
#define FCNFG		_IO8(0x103)		//flash configuration register
#define FPROT		_IO8(0x104)		//flash protection register
#define FSTAT		_IO8(0x105)		//flash status register
#define FCMD		_IO8(0x106)		//flash command register
#define FADDR		_IO16(0x108)	//flash address
#define FDATA		_IO16(0x10a)	//flash data
#define ECLKDIV		_IO8(0x110)		//eeprom clock divider

#define ECNFG		_IO8(0x113)		//eeprom configuration register
#define EPROT		_IO8(0x114)		//eeprom protection register
#define ESTAT		_IO8(0x115)		//eeprom status register
#define ECMD		_IO8(0x116)		//eeprom command register
#define EADDR		_IO8(0x118)		//eeprom address
#define EDATA		_IO8(0x11a)		//eeprom data

#define ATD1CTL0	_IO8(0x120)		//adc1 control 0 (reserved)
#define ATD1CTL1	_IO8(0x121)		//adc1 control 1 (reserved)
#define ATD1CTL2	_IO8(0x122)		//adc1 control 2
#define ATD1CTL3	_IO8(0x123)		//adc1 control 3
#define ATD1CTL4	_IO8(0x124)		//adc1 control 4
#define ATD1CTL5	_IO8(0x125)		//adc1 control 5
#define ATD1STAT0	_IO8(0x126)		//adc1 status register 0

#define ATD1TEST0	_IO8(0x128)		//adc1 test (reserved)
#define ATD1TEST1	_IO8(0x129)		//adc1 test (reserved)
#define ATD1STAT1	_IO8(0x12b)		//adc1 status register 1
#define ATD1DIEN	_IO8(0x12d)		//adc1 input enable register

#define PORTAD1		_IO8(0x12f)		//port adc1 = input only
#define ATD1DR0		_IO16(0x130)	//adc1 result 0 register
#define ATD1DR1		_IO16(0x132)	//adc1 result 1 register
#define ATD1DR2		_IO16(0x134)	//adc1 result 2 register
#define ATD1DR3		_IO16(0x136)	//adc1 result 3 register
#define ATD1DR4		_IO16(0x138)	//adc1 result 4 register
#define ATD1DR5		_IO16(0x13a)	//adc1 result 5 register
#define ATD1DR6		_IO16(0x13c)	//adc1 result 6 register
#define ATD1DR7		_IO16(0x13e)	//adc1 result 7 register

#define CAN0CTL0	_IO8(0x140)		//can0 control register 0
#define CAN0CTL1	_IO8(0x141)		//can0 control register 1
#define CAN0BTR0	_IO8(0x142)		//can0 bus timing register 0
#define CAN0BTR1	_IO8(0x143)		//can0 bus timing register 1
#define CAN0RFLG	_IO8(0x144)		//can0 receiver flags
#define CAN0RIER	_IO8(0x145)		//can0 receiver interrupt enables
#define CAN0TFLG	_IO8(0x146)		//can0 transmit flags
#define CAN0TIER	_IO8(0x147)		//can0 transmit interrupt enables
#define CAN0TARQ	_IO8(0x148)		//can0 transmit message abort control
#define CAN0TAAK	_IO8(0x149)		//can0 transmit message abort status
#define CAN0TBSEL	_IO8(0x14a)		//can0 transmit buffer select
#define CAN0IDAC	_IO8(0x14b)		//can0 identifier acceptance control

#define CAN0RXERR	_IO8(0x14e)		//can0 receive error counter
#define CAN0TXERR	_IO8(0x14f)		//can0 transmit error counter
#define CAN0IDAR0	_IO8(0x150)		//can0 identifier acceptance register 0
#define CAN0IDAR1	_IO8(0x151)		//can0 identifier acceptance register 1
#define CAN0IDAR2	_IO8(0x152)		//can0 identifier acceptance register 2
#define CAN0IDAR3	_IO8(0x153)		//can0 identifier acceptance register 3
#define CAN0IDMR0	_IO8(0x154)		//can0 identifier mask register 0
#define CAN0IDMR1	_IO8(0x155)		//can0 identifier mask register 1
#define CAN0IDMR2	_IO8(0x156)		//can0 identifier mask register 2
#define CAN0IDMR3	_IO8(0x157)		//can0 identifier mask register 3
#define CAN0IDAR4	_IO8(0x158)		//can0 identifier acceptance register 4
#define CAN0IDAR5	_IO8(0x159)		//can0 identifier acceptance register 5
#define CAN0IDAR6	_IO8(0x15a)		//can0 identifier acceptance register 6
#define CAN0IDAR7	_IO8(0x15b)		//can0 identifier acceptance register 7
#define CAN0IDMR4	_IO8(0x15c)		//can0 identifier mask register 4
#define CAN0IDMR5	_IO8(0x15d)		//can0 identifier mask register 5
#define CAN0IDMR6	_IO8(0x15e)		//can0 identifier mask register 6
#define CAN0IDMR7	_IO8(0x15f)		//can0 identifier mask register 7
#define CAN0RXLG	_IO8(0x160)		//can0 rx foreground buffer thru +$16f
#define CAN0TXFG	_IO8(0x170)		//can0 tx foreground buffer thru +$17f

#define CAN1CTL0	_IO8(0x180)		//can1 control register 0
#define CAN1CTL1	_IO8(0x181)		//can1 control register 1
#define CAN1BTR0	_IO8(0x182)		//can1 bus timing register 0
#define CAN1BTR1	_IO8(0x183)		//can1 bus timing register 1
#define CAN1RFLG	_IO8(0x184)		//can1 receiver flags
#define CAN1RIER	_IO8(0x185)		//can1 receiver interrupt enables
#define CAN1TFLG	_IO8(0x186)		//can1 transmit flags
#define CAN1TIER	_IO8(0x187)		//can1 transmit interrupt enables
#define CAN1TARQ	_IO8(0x188)		//can1 transmit message abort control
#define CAN1TAAK	_IO8(0x189)		//can1 transmit message abort status
#define CAN1TBSEL	_IO8(0x18a)		//can1 transmit buffer select
#define CAN1IDAC	_IO8(0x18b)		//can1 identifier acceptance control

#define CAN1RXERR	_IO8(0x18e)		//can1 receive error counter
#define CAN1TXERR	_IO8(0x18f)		//can1 transmit error counter
#define CAN1IDAR0	_IO8(0x190)		//can1 identifier acceptance register 0
#define CAN1IDAR1	_IO8(0x191)		//can1 identifier acceptance register 1
#define CAN1IDAR2	_IO8(0x192)		//can1 identifier acceptance register 2
#define CAN1IDAR3	_IO8(0x193)		//can1 identifier acceptance register 3
#define CAN1IDMR0	_IO8(0x194)		//can1 identifier mask register 0
#define CAN1IDMR1	_IO8(0x195)		//can1 identifier mask register 1
#define CAN1IDMR2	_IO8(0x196)		//can1 identifier mask register 2
#define CAN1IDMR3	_IO8(0x197)		//can1 identifier mask register 3
#define CAN1IDAR4	_IO8(0x198)		//can1 identifier acceptance register 4
#define CAN1IDAR5	_IO8(0x199)		//can1 identifier acceptance register 5
#define CAN1IDAR6	_IO8(0x19a)		//can1 identifier acceptance register 6
#define CAN1IDAR7	_IO8(0x19b)		//can1 identifier acceptance register 7
#define CAN1IDMR4	_IO8(0x19c)		//can1 identifier mask register 4
#define CAN1IDMR5	_IO8(0x19d)		//can1 identifier mask register 5
#define CAN1IDMR6	_IO8(0x19e)		//can1 identifier mask register 6
#define CAN1IDMR7	_IO8(0x19f)		//can1 identifier mask register 7
#define CAN1RXFG	_IO8(0x1a0)		//can1 rx foreground buffer thru +$1af
#define CAN1TXFG	_IO8(0x1b0)		//can1 tx foreground buffer thru +$1bf

#define CAN2CTL0	_IO8(0x1c0)		//can2 control register 0
#define CAN2CTL1	_IO8(0x1c1)		//can2 control register 1
#define CAN2BTR0	_IO8(0x1c2)		//can2 bus timing register 0
#define CAN2BTR1	_IO8(0x1c3)		//can2 bus timing register 1
#define CAN2RFLG	_IO8(0x1c4)		//can2 receiver flags
#define CAN2RIER	_IO8(0x1c5)		//can2 receiver interrupt enables
#define CAN2TFLG	_IO8(0x1c6)		//can2 transmit flags
#define CAN2TIER	_IO8(0x1c7)		//can2 transmit interrupt enables
#define CAN2TARQ	_IO8(0x1c8)		//can2 transmit message abort control
#define CAN2TAAK	_IO8(0x1c9)		//can2 transmit message abort status
#define CAN2TBSEL	_IO8(0x1ca)		//can2 transmit buffer select
#define CAN2IDAC	_IO8(0x1cb)		//can2 identifier acceptance control

#define CAN2RXERR	_IO8(0x1ce)		//can2 receive error counter
#define CAN2TXERR	_IO8(0x1cf)		//can2 transmit error counter
#define CAN2IDAR0	_IO8(0x1d0)		//can2 identifier acceptance register 0
#define CAN2IDAR1	_IO8(0x1d1)		//can2 identifier acceptance register 1
#define CAN2IDAR2	_IO8(0x1d2)		//can2 identifier acceptance register 2
#define CAN2IDAR3	_IO8(0x1d3)		//can2 identifier acceptance register 3
#define CAN2IDMR0	_IO8(0x1d4)		//can2 identifier mask register 0
#define CAN2IDMR1	_IO8(0x1d5)		//can2 identifier mask register 1
#define CAN2IDMR2	_IO8(0x1d6)		//can2 identifier mask register 2
#define CAN2IDMR3	_IO8(0x1d7)		//can2 identifier mask register 3
#define CAN2IDAR4	_IO8(0x1d8)		//can2 identifier acceptance register 4
#define CAN2IDAR5	_IO8(0x1d9)		//can2 identifier acceptance register 5
#define CAN2IDAR6	_IO8(0x1da)		//can2 identifier acceptance register 6
#define CAN2IDAR7	_IO8(0x1db)		//can2 identifier acceptance register 7
#define CAN2IDMR4	_IO8(0x1dc)		//can2 identifier mask register 4
#define CAN2IDMR5	_IO8(0x1dd)		//can2 identifier mask register 5
#define CAN2IDMR6	_IO8(0x1de)		//can2 identifier mask register 6
#define CAN2IDMR7	_IO8(0x1df)		//can2 identifier mask register 7
#define CAN2RXFG	_IO8(0x1e0)		//can2 rx foreground buffer thru +$1ef
#define CAN2TXFG	_IO8(0x1f0)		//can2 tx foreground buffer thru +$1ff

#define CAN3CTL0	_IO8(0x200)		//can3 control register 0
#define CAN3CTL1	_IO8(0x201)		//can3 control register 1
#define CAN3BTR0	_IO8(0x202)		//can3 bus timing register 0
#define CAN3BTR1	_IO8(0x203)		//can3 bus timing register 1
#define CAN3RFLG	_IO8(0x204)		//can3 receiver flags
#define CAN3RIER	_IO8(0x205)		//can3 receiver interrupt enables
#define CAN3TFLG	_IO8(0x206)		//can3 transmit flags
#define CAN3TIER	_IO8(0x207)		//can3 transmit interrupt enables
#define CAN3TARQ	_IO8(0x208)		//can3 transmit message abort control
#define CAN3TAAK	_IO8(0x209)		//can3 transmit message abort status
#define CAN3TBSEL	_IO8(0x20a)		//can3 transmit buffer select
#define CAN3IDAC	_IO8(0x20b)		//can3 identifier acceptance control

#define CAN3RXERR	_IO8(0x20e)		//can3 receive error counter
#define CAN3TXERR	_IO8(0x20f)		//can3 transmit error counter
#define CAN3IDAR0	_IO8(0x210)		//can3 identifier acceptance register 0
#define CAN3IDAR1	_IO8(0x211)		//can3 identifier acceptance register 1
#define CAN3IDAR2	_IO8(0x212)		//can3 identifier acceptance register 2
#define CAN3IDAR3	_IO8(0x213)		//can3 identifier acceptance register 3
#define CAN3IDMR0	_IO8(0x214)		//can3 identifier mask register 0
#define CAN3IDMR1	_IO8(0x215)		//can3 identifier mask register 1
#define CAN3IDMR2	_IO8(0x216)		//can3 identifier mask register 2
#define CAN3IDMR3	_IO8(0x217)		//can3 identifier mask register 3
#define CAN3IDAR4	_IO8(0x218)		//can3 identifier acceptance register 4
#define CAN3IDAR5	_IO8(0x219)		//can3 identifier acceptance register 5
#define CAN3IDAR6	_IO8(0x21a)		//can3 identifier acceptance register 6
#define CAN3IDAR7	_IO8(0x21b)		//can3 identifier acceptance register 7
#define CAN3IDMR4	_IO8(0x21c)		//can3 identifier mask register 4
#define CAN3IDMR5	_IO8(0x21d)		//can3 identifier mask register 5
#define CAN3IDMR6	_IO8(0x21e)		//can3 identifier mask register 6
#define CAN3IDMR7	_IO8(0x21f)		//can3 identifier mask register 7
#define CAN3RXFG	_IO8(0x220)		//can3 rx foreground buffer thru +$22f
#define CAN3TXFG	_IO8(0x230)		//can3 tx foreground buffer thru +$23f

#define PTT			_IO8(0x240)		//portt data register
#define PTIT		_IO8(0x241)		//portt input register
#define DDRT		_IO8(0x242)		//portt direction register
#define RDRT		_IO8(0x243)		//portt reduced drive register
#define PERT		_IO8(0x244)		//portt pull device enable
#define PPST		_IO8(0x245)		//portt pull polarity select

#define PTS			_IO8(0x248)		//ports data register
#define PTIS		_IO8(0x249)		//ports input register
#define DDRS		_IO8(0x24a)		//ports direction register
#define RDRS		_IO8(0x24b)		//ports reduced drive register
#define PERS		_IO8(0x24c)		//ports pull device enable
#define PPSS		_IO8(0x24d)		//ports pull polarity select
#define WOMS		_IO8(0x24e)		//ports wired or mode register

#define PTM			_IO8(0x250)		//portm data register
#define PTIM		_IO8(0x251)		//portm input register
#define DDRM		_IO8(0x252)		//portm direction register
#define RDRM		_IO8(0x253)		//portm reduced drive register
#define PERM		_IO8(0x254)		//portm pull device enable
#define PPSM		_IO8(0x255)		//portm pull polarity select
#define WOMM		_IO8(0x256)		//portm wired or mode register
#define MODRR		_IO8(0x257)		//portm module routing register
#define PTP			_IO8(0x258)		//portp data register
#define PTIP		_IO8(0x259)		//portp input register
#define DDRP		_IO8(0x25a)		//portp direction register
#define RDRP		_IO8(0x25b)		//portp reduced drive register
#define PERP		_IO8(0x25c)		//portp pull device enable
#define PPSP		_IO8(0x25d)		//portp pull polarity select
#define PIEP		_IO8(0x25e)		//portp interrupt enable register
#define PIFP		_IO8(0x25f)		//portp interrupt flag register
#define PTH			_IO8(0x260)		//porth data register
#define PTIH		_IO8(0x261)		//porth input register
#define DDRH		_IO8(0x262)		//porth direction register
#define RDRH		_IO8(0x263)		//porth reduced drive register
#define PERH		_IO8(0x264)		//porth pull device enable
#define PPSH		_IO8(0x265)		//porth pull polarity select
#define PIEH		_IO8(0x266)		//porth interrupt enable register
#define PIFH		_IO8(0x267)		//porth interrupt flag register
#define PTJ			_IO8(0x268)		//portp data register
#define PTIJ		_IO8(0x269)		//portp input register
#define DDRJ		_IO8(0x26a)		//portp direction register
#define RDRJ		_IO8(0x26b)		//portp reduced drive register
#define PERJ		_IO8(0x26c)		//portp pull device enable
#define PPSJ		_IO8(0x26d)		//portp pull polarity select
#define PIEJ		_IO8(0x26e)		//portp interrupt enable register
#define PIFJ		_IO8(0x26f)		//portp interrupt flag register

#define CAN4CTL0	_IO8(0x280)		//can4 control register 0
#define CAN4CTL1	_IO8(0x281)		//can4 control register 1
#define CAN4BTR0	_IO8(0x282)		//can4 bus timing register 0
#define CAN4BTR1	_IO8(0x283)		//can4 bus timing register 1
#define CAN4RFLG	_IO8(0x284)		//can4 receiver flags
#define CAN4RIER	_IO8(0x285)		//can4 receiver interrupt enables
#define CAN4TFLG	_IO8(0x286)		//can4 transmit flags
#define CAN4TIER	_IO8(0x287)		//can4 transmit interrupt enables
#define CAN4TARQ	_IO8(0x288)		//can4 transmit message abort control
#define CAN4TAAK	_IO8(0x289)		//can4 transmit message abort status
#define CAN4TBSEL	_IO8(0x28a)		//can4 transmit buffer select
#define CAN4IDAC	_IO8(0x28b)		//can4 identifier acceptance control

#define CAN4RXERR	_IO8(0x28e)		//can4 receive error counter
#define CAN4TXERR	_IO8(0x28f)		//can4 transmit error counter
#define CAN4IDAR0	_IO8(0x290)		//can4 identifier acceptance register 0
#define CAN4IDAR1	_IO8(0x291)		//can4 identifier acceptance register 1
#define CAN4IDAR2	_IO8(0x292)		//can4 identifier acceptance register 2
#define CAN4IDAR3	_IO8(0x293)		//can4 identifier acceptance register 3
#define CAN4IDMR0	_IO8(0x294)		//can4 identifier mask register 0
#define CAN4IDMR1	_IO8(0x295)		//can4 identifier mask register 1
#define CAN4IDMR2	_IO8(0x296)		//can4 identifier mask register 2
#define CAN4IDMR3	_IO8(0x297)		//can4 identifier mask register 3
#define CAN4IDAR4	_IO8(0x298)		//can4 identifier acceptance register 4
#define CAN4IDAR5	_IO8(0x299)		//can4 identifier acceptance register 5
#define CAN4IDAR6	_IO8(0x29a)		//can4 identifier acceptance register 6
#define CAN4IDAR7	_IO8(0x29b)		//can4 identifier acceptance register 7
#define CAN4IDMR4	_IO8(0x29c)		//can4 identifier mask register 4
#define CAN4IDMR5	_IO8(0x29d)		//can4 identifier mask register 5
#define CAN4IDMR6	_IO8(0x29e)		//can4 identifier mask register 6
#define CAN4IDMR7	_IO8(0x29f)		//can4 identifier mask register 7
#define CAN4RXFG	_IO8(0x2a0)		//can4 rx foreground buffer thru +$2af
#define CAN4TXFG	_IO8(0x2b0)		//can4 tx foreground buffer thru +$2bf


#endif
#ifdef __IAR__
// IAR definitions

__no_init volatile uint8_t PORTA @ (REGISTER_BASE + 0x00);		//port a = address lines a8 - a15
__no_init volatile uint8_t PORTB @ (REGISTER_BASE + 0x01);		//port b = address lines a0 - a7
__no_init volatile uint8_t DDRA @ (REGISTER_BASE + 0x02);		//port a direction register
__no_init volatile uint8_t DDRB @ (REGISTER_BASE + 0x03);		//port a direction register

__no_init volatile uint8_t PORTE @ (REGISTER_BASE + 0x08);		//port e = mode,irqandcontrolsignals
__no_init volatile uint8_t DDRE @ (REGISTER_BASE + 0x09);		//port e direction register
__no_init volatile uint8_t PEAR @ (REGISTER_BASE + 0x0A);		//port e assignments
__no_init volatile uint8_t MODE @ (REGISTER_BASE + 0x0B);		//mode register
__no_init volatile uint8_t PUCR @ (REGISTER_BASE + 0x0C);		//port pull-up control register
__no_init volatile uint8_t RDRIV @ (REGISTER_BASE + 0x0D);		//port reduced drive control register
__no_init volatile uint8_t EBICTL @ (REGISTER_BASE + 0x0E);		//stretch control

__no_init volatile uint8_t INITRM @ (REGISTER_BASE + 0x10);		//ram location register
__no_init volatile uint8_t INITRG @ (REGISTER_BASE + 0x11);		//register location register
__no_init volatile uint8_t INITEE @ (REGISTER_BASE + 0x12);		//eeprom location register
__no_init volatile uint8_t MISC @ (REGISTER_BASE + 0x13);		//miscellaneous mapping control
__no_init volatile uint8_t MTST0 @ (REGISTER_BASE + 0x14);		//reserved
__no_init volatile uint8_t ITCR @ (REGISTER_BASE + 0x15);		//interrupt test control register
__no_init volatile uint8_t ITEST @ (REGISTER_BASE + 0x16);		//interrupt test register
__no_init volatile uint8_t MTST1 @ (REGISTER_BASE + 0x17);		//reserved

__no_init volatile uint8_t PARTIDH @ (REGISTER_BASE + 0x1a);	//part id high
__no_init volatile uint8_t PARTIDL @ (REGISTER_BASE + 0x1b);	//part id low
__no_init volatile uint8_t MEMSIZ0 @ (REGISTER_BASE + 0x1c);	//memory size
__no_init volatile uint8_t MEMSIZ1 @ (REGISTER_BASE + 0x1d);	//memory size
__no_init volatile uint8_t INTCR @ (REGISTER_BASE + 0x1e);		//interrupt control register
__no_init volatile uint8_t HPRIO @ (REGISTER_BASE + 0x1f);		//high priority reg

__no_init volatile uint8_t BKPCT0 @ (REGISTER_BASE + 0x28);		//break control register
__no_init volatile uint8_t BKPCT1 @ (REGISTER_BASE + 0x29);		//break control register
__no_init volatile uint8_t BKP0X @ (REGISTER_BASE + 0x2a);		//break 0 index register
__no_init volatile uint8_t BKP0H @ (REGISTER_BASE + 0x2b);		//break 0 pointer high
__no_init volatile uint8_t BKP0L @ (REGISTER_BASE + 0x2c);		//break 0 pointer low
__no_init volatile uint8_t BKP1X @ (REGISTER_BASE + 0x2d);		//break 1 index register
__no_init volatile uint8_t BKP1H @ (REGISTER_BASE + 0x2e);		//break 1 pointer high
__no_init volatile uint8_t BKP1L @ (REGISTER_BASE + 0x2f);		//break 1 pointer low
__no_init volatile uint8_t PPAGE @ (REGISTER_BASE + 0x30);		//program page register

__no_init volatile uint8_t PORTK @ (REGISTER_BASE + 0x32);		//port k data
__no_init volatile uint8_t DDRK @ (REGISTER_BASE + 0x33);		//port k direction
__no_init volatile uint8_t SYNR @ (REGISTER_BASE + 0x34);		//synthesizer / multiplier register
__no_init volatile uint8_t REFDV @ (REGISTER_BASE + 0x35);		//reference divider register
__no_init volatile uint8_t CTFLG @ (REGISTER_BASE + 0x36);		//reserved
__no_init volatile uint8_t CRGFLG @ (REGISTER_BASE + 0x37);		//pll flags register
__no_init volatile uint8_t CRGINT @ (REGISTER_BASE + 0x38);		//pll interrupt register
__no_init volatile uint8_t CLKSEL @ (REGISTER_BASE + 0x39);		//clock select register
__no_init volatile uint8_t PLLCTL @ (REGISTER_BASE + 0x3a);		//pll control register
__no_init volatile uint8_t RTICTL @ (REGISTER_BASE + 0x3b);		//real time interrupt control
__no_init volatile uint8_t COPCTL @ (REGISTER_BASE + 0x3c);		//watchdog control
__no_init volatile uint8_t FORBYP @ (REGISTER_BASE + 0x3d);		//crg force and bypass test register
__no_init volatile uint8_t CTCTL @ (REGISTER_BASE + 0x3e);		//crg test control register
__no_init volatile uint8_t ARMCOP @ (REGISTER_BASE + 0x3f);		//cop reset register

__no_init volatile uint8_t TIOS @ (REGISTER_BASE + 0x40);		//timer input/output select
__no_init volatile uint8_t CFORC @ (REGISTER_BASE + 0x41);		//timer compare force
__no_init volatile uint8_t OC7M @ (REGISTER_BASE + 0x42);		//timer output compare 7 mask
__no_init volatile uint8_t OC7D @ (REGISTER_BASE + 0x43);		//timer output compare 7 data
__no_init volatile uint16_t TCNT @ (REGISTER_BASE + 0x44);		//timer counter register hi

__no_init volatile uint8_t TSCR1 @ (REGISTER_BASE + 0x46);		//timer system control register
__no_init volatile uint8_t TSCR @ (REGISTER_BASE + 0x46);		//timer system control register - Added by Navid
__no_init volatile uint8_t TTOV @ (REGISTER_BASE + 0x47);		//reserved
__no_init volatile uint8_t TCTL1 @ (REGISTER_BASE + 0x48);		//timer control register 1
__no_init volatile uint8_t TCTL2 @ (REGISTER_BASE + 0x49);		//timer control register 2
__no_init volatile uint8_t TCTL3 @ (REGISTER_BASE + 0x4a);		//timer control register 3
__no_init volatile uint8_t TCTL4 @ (REGISTER_BASE + 0x4b);		//timer control register 4
__no_init volatile uint8_t TIE @ (REGISTER_BASE + 0x4c);		//timer interrupt mask 1
__no_init volatile uint8_t TMSK1 @ (REGISTER_BASE + 0x4c);		////timer interrupt mask 1 - added by Navid
__no_init volatile uint8_t TSCR2 @ (REGISTER_BASE + 0x4d);		//timer interrupt mask 2
__no_init volatile uint8_t TMSK2 @ (REGISTER_BASE + 0x4d);		//timer interrupt mask 2 - added by Navid
__no_init volatile uint8_t TFLG1 @ (REGISTER_BASE + 0x4e);		//timer flags 1
__no_init volatile uint8_t TFLG2 @ (REGISTER_BASE + 0x4f);		//timer flags 2
__no_init volatile uint16_t TC0 @ (REGISTER_BASE + 0x50);		//timer capture/compare register 0
__no_init volatile uint16_t TC1 @ (REGISTER_BASE + 0x52);		//timer capture/compare register 1
__no_init volatile uint16_t TC2 @ (REGISTER_BASE + 0x54);		//timer capture/compare register 2
__no_init volatile uint16_t TC3 @ (REGISTER_BASE + 0x56);		//timer capture/compare register 3
__no_init volatile uint16_t TC4 @ (REGISTER_BASE + 0x58);		//timer capture/compare register 4
__no_init volatile uint16_t TC5 @ (REGISTER_BASE + 0x5a);		//timer capture/compare register 5
__no_init volatile uint16_t TC6 @ (REGISTER_BASE + 0x5c);		//timer capture/compare register 6
__no_init volatile uint16_t TC7 @ (REGISTER_BASE + 0x5e);		//timer capture/compare register 7
__no_init volatile uint8_t TACTL @ (REGISTER_BASE + 0x60);		//pulse accumulator controls
__no_init volatile uint8_t PACTL @ (REGISTER_BASE + 0x60);		//pulse accumulator controls - added by Navid
__no_init volatile uint8_t PAFLG @ (REGISTER_BASE + 0x61);		//pulse accumulator flags
__no_init volatile uint16_t PACNT @ (REGISTER_BASE + 0x62);		//pulse accumulator counter 3 --added by Navid
__no_init volatile uint8_t PACN3 @ (REGISTER_BASE + 0x62);		//pulse accumulator counter 3
__no_init volatile uint8_t PACN2 @ (REGISTER_BASE + 0x63);		//pulse accumulator counter 2
__no_init volatile uint8_t PACN1 @ (REGISTER_BASE + 0x64);		//pulse accumulator counter 1
__no_init volatile uint8_t PACN0 @ (REGISTER_BASE + 0x65);		//pulse accumulator counter 0
__no_init volatile uint8_t MCCTL @ (REGISTER_BASE + 0x66);		//modulus down conunter control
__no_init volatile uint8_t MCFLG @ (REGISTER_BASE + 0x67);		//down counter flags
__no_init volatile uint8_t ICPAR @ (REGISTER_BASE + 0x68);		//input pulse accumulator control
__no_init volatile uint8_t DLYCT @ (REGISTER_BASE + 0x69);		//delay count to down counter
__no_init volatile uint8_t ICOVW @ (REGISTER_BASE + 0x6a);		//input control overwrite register
__no_init volatile uint8_t ICSYS @ (REGISTER_BASE + 0x6b);		//input control system control

__no_init volatile uint8_t TIMTST @ (REGISTER_BASE + 0x6d);		//timer test register

__no_init volatile uint8_t PBCTL @ (REGISTER_BASE + 0x70);		//pulse accumulator b control
__no_init volatile uint8_t PBFLG @ (REGISTER_BASE + 0x71);		//pulse accumulator b flags
__no_init volatile uint8_t PA3H @ (REGISTER_BASE + 0x72);		//pulse accumulator holding register 3
__no_init volatile uint8_t PA2H @ (REGISTER_BASE + 0x73);		//pulse accumulator holding register 2
__no_init volatile uint8_t PA1H @ (REGISTER_BASE + 0x74);		//pulse accumulator holding register 1
__no_init volatile uint8_t PA0H @ (REGISTER_BASE + 0x75);		//pulse accumulator holding register 0
__no_init volatile uint8_t MCCNT @ (REGISTER_BASE + 0x76);		//modulus down counter register
__no_init volatile uint8_t MCCNTL @ (REGISTER_BASE + 0x77);		//low byte
__no_init volatile uint16_t TC0H @ (REGISTER_BASE + 0x78);		//capture 0 holding register
__no_init volatile uint16_t TC1H @ (REGISTER_BASE + 0x7a);		//capture 1 holding register
__no_init volatile uint16_t TC2H @ (REGISTER_BASE + 0x7c);		//capture 2 holding register
__no_init volatile uint16_t TC3H @ (REGISTER_BASE + 0x7e);		//capture 3 holding register

__no_init volatile uint8_t ATD0CTL0 @ (REGISTER_BASE + 0x80);	//adc control 0 (reserved)
__no_init volatile uint8_t ATD0CTL1 @ (REGISTER_BASE + 0x81);	//adc control 1 (reserved)
__no_init volatile uint8_t ATD0CTL2 @ (REGISTER_BASE + 0x82);	//adc control 2
__no_init volatile uint8_t ATD0CTL3 @ (REGISTER_BASE + 0x83);	//adc control 3
__no_init volatile uint8_t ATD0CTL4 @ (REGISTER_BASE + 0x84);	//adc control 4
__no_init volatile uint8_t ATD0CTL5 @ (REGISTER_BASE + 0x85);	//adc control 5
__no_init volatile uint8_t ATD0STAT0 @ (REGISTER_BASE + 0x86);	//adc status register 0
__no_init volatile uint16_t ATD0STAT @ (REGISTER_BASE + 0x86);	//adc status register 0 - added by Navid
__no_init volatile uint8_t ATD0TEST0 @ (REGISTER_BASE + 0x88);	//adc test (reserved)
__no_init volatile uint8_t ATD0TEST1 @ (REGISTER_BASE + 0x89);	//adc test (reserved)

__no_init volatile uint8_t ATD0STAT1 @ (REGISTER_BASE + 0x8b);	//adc status register 1
__no_init volatile uint8_t ATD0DIEN @ (REGISTER_BASE + 0x8d);	//adc input enable mask

__no_init volatile uint8_t PORTAD0 @ (REGISTER_BASE + 0x8f);	//port adc = input only
__no_init volatile uint16_t ATD0DR0 @ (REGISTER_BASE + 0x90);	//adc result 0 register
__no_init volatile uint16_t ATD0DR1 @ (REGISTER_BASE + 0x92);	//adc result 1 register
__no_init volatile uint16_t ATD0DR2 @ (REGISTER_BASE + 0x94);	//adc result 2 register
__no_init volatile uint16_t ATD0DR3 @ (REGISTER_BASE + 0x96);	//adc result 3 register
__no_init volatile uint16_t ATD0DR4 @ (REGISTER_BASE + 0x98);	//adc result 4 register
__no_init volatile uint16_t ATD0DR5 @ (REGISTER_BASE + 0x9a);	//adc result 5 register
__no_init volatile uint16_t ATD0DR6 @ (REGISTER_BASE + 0x9c);	//adc result 6 register
__no_init volatile uint16_t ATD0DR7 @ (REGISTER_BASE + 0x9e);	//adc result 7 register

__no_init volatile uint8_t PWME @ (REGISTER_BASE + 0xa0);		//pwm enable
__no_init volatile uint8_t PWMPOL @ (REGISTER_BASE + 0xa1);		//pwm polarity
__no_init volatile uint8_t PWMCLK @ (REGISTER_BASE + 0xa2);		//pwm clock select register
__no_init volatile uint8_t PWMPRCLK @ (REGISTER_BASE + 0xa3);	//pwm prescale clock select register
__no_init volatile uint8_t PWMCAE @ (REGISTER_BASE + 0xa4);		//pwm center align select register
__no_init volatile uint8_t PWMCTL @ (REGISTER_BASE + 0xa5);		//pwm control register
__no_init volatile uint8_t PWMTST @ (REGISTER_BASE + 0xa6);		//reserved
__no_init volatile uint8_t PWMPRSC @ (REGISTER_BASE + 0xa7);	//reserved
__no_init volatile uint8_t PWMSCLA @ (REGISTER_BASE + 0xa8);	//pwm scale a
__no_init volatile uint8_t PWMSCLB @ (REGISTER_BASE + 0xa9);	//pwm scale b
__no_init volatile uint8_t PWMSCNTA @ (REGISTER_BASE + 0xaa);	//reserved
__no_init volatile uint8_t PWMSCNTB @ (REGISTER_BASE + 0xab);	//reserved
__no_init volatile uint8_t PWMCNT0 @ (REGISTER_BASE + 0xac);	//pwm channel 0 counter
__no_init volatile uint8_t PWMCNT1 @ (REGISTER_BASE + 0xad);	//pwm channel 1 counter
__no_init volatile uint8_t PWMCNT2 @ (REGISTER_BASE + 0xae);	//pwm channel 2 counter
__no_init volatile uint8_t PWMCNT3 @ (REGISTER_BASE + 0xaf);	//pwm channel 3 counter
__no_init volatile uint8_t PWMCNT4 @ (REGISTER_BASE + 0xb0);	//pwm channel 4 counter
__no_init volatile uint8_t PWMCNT5 @ (REGISTER_BASE + 0xb1);	//pwm channel 5 counter
__no_init volatile uint8_t PWMCNT6 @ (REGISTER_BASE + 0xb2);	//pwm channel 6 counter
__no_init volatile uint8_t PWMCNT7 @ (REGISTER_BASE + 0xb3);	//pwm channel 7 counter
__no_init volatile uint8_t PWMPER0 @ (REGISTER_BASE + 0xb4);	//pwm channel 0 period
__no_init volatile uint8_t PWMPER1 @ (REGISTER_BASE + 0xb5);	//pwm channel 1 period
__no_init volatile uint8_t PWMPER2 @ (REGISTER_BASE + 0xb6);	//pwm channel 2 period
__no_init volatile uint8_t PWMPER3 @ (REGISTER_BASE + 0xb7);	//pwm channel 3 period
__no_init volatile uint8_t PWMPER4 @ (REGISTER_BASE + 0xb8);	//pwm channel 4 period
__no_init volatile uint8_t PWMPER5 @ (REGISTER_BASE + 0xb9);	//pwm channel 5 period
__no_init volatile uint8_t PWMPER6 @ (REGISTER_BASE + 0xba);	//pwm channel 6 period
__no_init volatile uint8_t PWMPER7 @ (REGISTER_BASE + 0xbb);	//pwm channel 7 period
__no_init volatile uint8_t PWMDTY0 @ (REGISTER_BASE + 0xbc);	//pwm channel 0 duty cycle
__no_init volatile uint8_t PWMDTY1 @ (REGISTER_BASE + 0xbd);	//pwm channel 1 duty cycle
__no_init volatile uint8_t PWMDTY2 @ (REGISTER_BASE + 0xbe);	//pwm channel 2 duty cycle
__no_init volatile uint8_t PWMDTY3 @ (REGISTER_BASE + 0xbf);	//pwm channel 3 duty cycle
__no_init volatile uint8_t PWMDTY4 @ (REGISTER_BASE + 0xc0);	//pwm channel 0 duty cycle
__no_init volatile uint8_t PWMDTY5 @ (REGISTER_BASE + 0xc1);	//pwm channel 1 duty cycle
__no_init volatile uint8_t PWMDTY6 @ (REGISTER_BASE + 0xc2);	//pwm channel 2 duty cycle
__no_init volatile uint8_t PWMDTY7 @ (REGISTER_BASE + 0xc3);	//pwm channel 3 duty cycle
__no_init volatile uint8_t PWMSDN @ (REGISTER_BASE + 0xc4);		//pwm shutdown register

__no_init volatile uint8_t SCI0BDH @ (REGISTER_BASE + 0xc8);	//sci 0 baud reg hi byte
__no_init volatile uint8_t SCI0BDL @ (REGISTER_BASE + 0xc9);	//sci 0 baud reg lo byte
__no_init volatile uint8_t SCI0CR1 @ (REGISTER_BASE + 0xca);	//sci 0 control1 reg
__no_init volatile uint8_t SCI0CR2 @ (REGISTER_BASE + 0xcb);	//sci 0 control2 reg
__no_init volatile uint8_t SCI0SR1 @ (REGISTER_BASE + 0xcc);	//sci 0 status reg 1
__no_init volatile uint8_t SCI0SR2 @ (REGISTER_BASE + 0xcd);	//sci 0 status reg 2
__no_init volatile uint8_t SCI0DRH @ (REGISTER_BASE + 0xce);	//sci 0 data reg hi
__no_init volatile uint8_t SCI0DRL @ (REGISTER_BASE + 0xcf);	//sci 0 data reg lo
__no_init volatile uint8_t SCI1BDH @ (REGISTER_BASE + 0xd0);	//sci 1 baud reg hi byte
__no_init volatile uint8_t SCI1BDL @ (REGISTER_BASE + 0xd1);	//sci 1 baud reg lo byte
__no_init volatile uint8_t SCI1CR1 @ (REGISTER_BASE + 0xd2);	//sci 1 control1 reg
__no_init volatile uint8_t SCI1CR2 @ (REGISTER_BASE + 0xd3);	//sci 1 control2 reg
__no_init volatile uint8_t SCI1SR1 @ (REGISTER_BASE + 0xd4);	//sci 1 status reg 1
__no_init volatile uint8_t SCI1SR2 @ (REGISTER_BASE + 0xd5);	//sci 1 status reg 2
__no_init volatile uint8_t SCI1DRH @ (REGISTER_BASE + 0xd6);	//sci 1 data reg hi
__no_init volatile uint8_t SCI1DRL @ (REGISTER_BASE + 0xd7);	//sci 1 data reg lo
__no_init volatile uint8_t SPI0CR1 @ (REGISTER_BASE + 0xd8);	//spi 0 control1 reg
__no_init volatile uint8_t SPI0CR2 @ (REGISTER_BASE + 0xd9);	//spi 0 control2 reg
__no_init volatile uint8_t SPI0BR @ (REGISTER_BASE + 0xda);		//spi 0 baud reg
__no_init volatile uint8_t SPI0SR @ (REGISTER_BASE + 0xdb);		//spi 0 status reg hi

__no_init volatile uint8_t SPI0DR @ (REGISTER_BASE + 0xdd);		//spi 0 data reg

__no_init volatile uint8_t IBAD @ (REGISTER_BASE + 0xe0);		//i2c bus address register
__no_init volatile uint8_t IBFD @ (REGISTER_BASE + 0xe1);		//i2c bus frequency divider
__no_init volatile uint8_t IBCR @ (REGISTER_BASE + 0xe2);		//i2c bus control register
__no_init volatile uint8_t IBSR @ (REGISTER_BASE + 0xe3);		//i2c bus status register
__no_init volatile uint8_t IBDR @ (REGISTER_BASE + 0xe4);		//i2c bus message data register

__no_init volatile uint8_t DLCBCR1 @ (REGISTER_BASE + 0xe8);	//bdlc control regsiter 1
__no_init volatile uint8_t DLCBSVR @ (REGISTER_BASE + 0xe9);	//bdlc state vector register
__no_init volatile uint8_t DLCBCR2 @ (REGISTER_BASE + 0xea);	//bdlc control register 2
__no_init volatile uint8_t DLCBDR @ (REGISTER_BASE + 0xeb);		//bdlc data register
__no_init volatile uint8_t DLCBARD @ (REGISTER_BASE + 0xec);	//bdlc analog delay register
__no_init volatile uint8_t DLCBRSR @ (REGISTER_BASE + 0xed);	//bdlc rate select register
__no_init volatile uint8_t DLCSCR @ (REGISTER_BASE + 0xee);		//bdlc control register
__no_init volatile uint8_t DLCBSTAT @ (REGISTER_BASE + 0xef);	//bdlc status register
__no_init volatile uint8_t SPI1CR1 @ (REGISTER_BASE + 0xf0);	//spi 1 control1 reg
__no_init volatile uint8_t SPI1CR2 @ (REGISTER_BASE + 0xf1);	//spi 1 control2 reg
__no_init volatile uint8_t SPI1BR @ (REGISTER_BASE + 0xf2);		//spi 1 baud reg
__no_init volatile uint8_t SPI1SR @ (REGISTER_BASE + 0xf3);		//spi 1 status reg hi

__no_init volatile uint8_t SPI1DR @ (REGISTER_BASE + 0xf5);		//spi 1 data reg

__no_init volatile uint8_t SPI2CR1 @ (REGISTER_BASE + 0xf8);	//spi 2 control1 reg
__no_init volatile uint8_t SPI2CR2 @ (REGISTER_BASE + 0xf9);	//spi 2 control2 reg
__no_init volatile uint8_t SPI2BR @ (REGISTER_BASE + 0xfa);		//spi 2 baud reg
__no_init volatile uint8_t SPI2SR @ (REGISTER_BASE + 0xfb);		//spi 2 status reg hi

__no_init volatile uint8_t SPI2DR @ (REGISTER_BASE + 0xfd);		//spi 2 data reg

__no_init volatile uint8_t FCLKDIV @ (REGISTER_BASE + 0x100);	//flash clock divider
__no_init volatile uint8_t FSEC @ (REGISTER_BASE + 0x101);		//flash security register
__no_init volatile uint8_t FCNFG @ (REGISTER_BASE + 0x103);		//flash configuration register
__no_init volatile uint8_t FPROT @ (REGISTER_BASE + 0x104);		//flash protection register
__no_init volatile uint8_t FSTAT @ (REGISTER_BASE + 0x105);		//flash status register
__no_init volatile uint8_t FCMD @ (REGISTER_BASE + 0x106);		//flash command register
__no_init volatile uint16_t FADDR @ (REGISTER_BASE + 0x108);	//flash address
__no_init volatile uint16_t FDATA @ (REGISTER_BASE + 0x10a);	//flash data
__no_init volatile uint8_t ECLKDIV @ (REGISTER_BASE + 0x110);	//eeprom clock divider

__no_init volatile uint8_t ECNFG @ (REGISTER_BASE + 0x113);		//eeprom configuration register
__no_init volatile uint8_t EPROT @ (REGISTER_BASE + 0x114);		//eeprom protection register
__no_init volatile uint8_t ESTAT @ (REGISTER_BASE + 0x115);		//eeprom status register
__no_init volatile uint8_t ECMD @ (REGISTER_BASE + 0x116);		//eeprom command register
__no_init volatile uint8_t EADDR @ (REGISTER_BASE + 0x118);		//eeprom address
__no_init volatile uint8_t EDATA @ (REGISTER_BASE + 0x11a);		//eeprom data

__no_init volatile uint8_t ATD1CTL0 @ (REGISTER_BASE + 0x120);	//adc1 control 0 (reserved)
__no_init volatile uint8_t ATD1CTL1 @ (REGISTER_BASE + 0x121);	//adc1 control 1 (reserved)
__no_init volatile uint8_t ATD1CTL2 @ (REGISTER_BASE + 0x122);	//adc1 control 2
__no_init volatile uint8_t ATD1CTL3 @ (REGISTER_BASE + 0x123);	//adc1 control 3
__no_init volatile uint8_t ATD1CTL4 @ (REGISTER_BASE + 0x124);	//adc1 control 4
__no_init volatile uint8_t ATD1CTL5 @ (REGISTER_BASE + 0x125);	//adc1 control 5
__no_init volatile uint8_t ATD1STAT0 @ (REGISTER_BASE + 0x126);	//adc1 status register 0

__no_init volatile uint8_t ATD1TEST0 @ (REGISTER_BASE + 0x128);	//adc1 test (reserved)
__no_init volatile uint8_t ATD1TEST1 @ (REGISTER_BASE + 0x129);	//adc1 test (reserved)
__no_init volatile uint8_t ATD1STAT1 @ (REGISTER_BASE + 0x12b);	//adc1 status register 1
__no_init volatile uint8_t ATD1DIEN @ (REGISTER_BASE + 0x12d);	//adc1 input enable register

__no_init volatile uint8_t PORTAD1 @ (REGISTER_BASE + 0x12f);	//port adc1 = input only
__no_init volatile uint16_t ATD1DR0 @ (REGISTER_BASE + 0x130);	//adc1 result 0 register
__no_init volatile uint16_t ATD1DR1 @ (REGISTER_BASE + 0x132);	//adc1 result 1 register
__no_init volatile uint16_t ATD1DR2 @ (REGISTER_BASE + 0x134);	//adc1 result 2 register
__no_init volatile uint16_t ATD1DR3 @ (REGISTER_BASE + 0x136);	//adc1 result 3 register
__no_init volatile uint16_t ATD1DR4 @ (REGISTER_BASE + 0x138);	//adc1 result 4 register
__no_init volatile uint16_t ATD1DR5 @ (REGISTER_BASE + 0x13a);	//adc1 result 5 register
__no_init volatile uint16_t ATD1DR6 @ (REGISTER_BASE + 0x13c);	//adc1 result 6 register
__no_init volatile uint16_t ATD1DR7 @ (REGISTER_BASE + 0x13e);	//adc1 result 7 register

__no_init volatile uint8_t CAN0CTL0 @ (REGISTER_BASE + 0x140);	//can0 control register 0
__no_init volatile uint8_t CAN0CTL1 @ (REGISTER_BASE + 0x141);	//can0 control register 1
__no_init volatile uint8_t CAN0BTR0 @ (REGISTER_BASE + 0x142);	//can0 bus timing register 0
__no_init volatile uint8_t CAN0BTR1 @ (REGISTER_BASE + 0x143);	//can0 bus timing register 1
__no_init volatile uint8_t CAN0RFLG @ (REGISTER_BASE + 0x144);	//can0 receiver flags
__no_init volatile uint8_t CAN0RIER @ (REGISTER_BASE + 0x145);	//can0 receiver interrupt enables
__no_init volatile uint8_t CAN0TFLG @ (REGISTER_BASE + 0x146);	//can0 transmit flags
__no_init volatile uint8_t CAN0TIER @ (REGISTER_BASE + 0x147);	//can0 transmit interrupt enables
__no_init volatile uint8_t CAN0TARQ @ (REGISTER_BASE + 0x148);	//can0 transmit message abort control
__no_init volatile uint8_t CAN0TAAK @ (REGISTER_BASE + 0x149);	//can0 transmit message abort status
__no_init volatile uint8_t CAN0TBSEL @ (REGISTER_BASE + 0x14a);	//can0 transmit buffer select
__no_init volatile uint8_t CAN0IDAC @ (REGISTER_BASE + 0x14b);	//can0 identifier acceptance control

__no_init volatile uint8_t CAN0RXERR @ (REGISTER_BASE + 0x14e);	//can0 receive error counter
__no_init volatile uint8_t CAN0TXERR @ (REGISTER_BASE + 0x14f);	//can0 transmit error counter
__no_init volatile uint8_t CAN0IDAR0 @ (REGISTER_BASE + 0x150);	//can0 identifier acceptance register 0
__no_init volatile uint8_t CAN0IDAR1 @ (REGISTER_BASE + 0x151);	//can0 identifier acceptance register 1
__no_init volatile uint8_t CAN0IDAR2 @ (REGISTER_BASE + 0x152);	//can0 identifier acceptance register 2
__no_init volatile uint8_t CAN0IDAR3 @ (REGISTER_BASE + 0x153);	//can0 identifier acceptance register 3
__no_init volatile uint8_t CAN0IDMR0 @ (REGISTER_BASE + 0x154);	//can0 identifier mask register 0
__no_init volatile uint8_t CAN0IDMR1 @ (REGISTER_BASE + 0x155);	//can0 identifier mask register 1
__no_init volatile uint8_t CAN0IDMR2 @ (REGISTER_BASE + 0x156);	//can0 identifier mask register 2
__no_init volatile uint8_t CAN0IDMR3 @ (REGISTER_BASE + 0x157);	//can0 identifier mask register 3
__no_init volatile uint8_t CAN0IDAR4 @ (REGISTER_BASE + 0x158);	//can0 identifier acceptance register 4
__no_init volatile uint8_t CAN0IDAR5 @ (REGISTER_BASE + 0x159);	//can0 identifier acceptance register 5
__no_init volatile uint8_t CAN0IDAR6 @ (REGISTER_BASE + 0x15a);	//can0 identifier acceptance register 6
__no_init volatile uint8_t CAN0IDAR7 @ (REGISTER_BASE + 0x15b);	//can0 identifier acceptance register 7
__no_init volatile uint8_t CAN0IDMR4 @ (REGISTER_BASE + 0x15c);	//can0 identifier mask register 4
__no_init volatile uint8_t CAN0IDMR5 @ (REGISTER_BASE + 0x15d);	//can0 identifier mask register 5
__no_init volatile uint8_t CAN0IDMR6 @ (REGISTER_BASE + 0x15e);	//can0 identifier mask register 6
__no_init volatile uint8_t CAN0IDMR7 @ (REGISTER_BASE + 0x15f);	//can0 identifier mask register 7
__no_init volatile uint8_t CAN0RXLG @ (REGISTER_BASE + 0x160);	//can0 rx foreground buffer thru +$16f
__no_init volatile uint8_t CAN0TXFG @ (REGISTER_BASE + 0x170);	//can0 tx foreground buffer thru +$17f

__no_init volatile uint8_t CAN1CTL0 @ (REGISTER_BASE + 0x180);	//can1 control register 0
__no_init volatile uint8_t CAN1CTL1 @ (REGISTER_BASE + 0x181);	//can1 control register 1
__no_init volatile uint8_t CAN1BTR0 @ (REGISTER_BASE + 0x182);	//can1 bus timing register 0
__no_init volatile uint8_t CAN1BTR1 @ (REGISTER_BASE + 0x183);	//can1 bus timing register 1
__no_init volatile uint8_t CAN1RFLG @ (REGISTER_BASE + 0x184);	//can1 receiver flags
__no_init volatile uint8_t CAN1RIER @ (REGISTER_BASE + 0x185);	//can1 receiver interrupt enables
__no_init volatile uint8_t CAN1TFLG @ (REGISTER_BASE + 0x186);	//can1 transmit flags
__no_init volatile uint8_t CAN1TIER @ (REGISTER_BASE + 0x187);	//can1 transmit interrupt enables
__no_init volatile uint8_t CAN1TARQ @ (REGISTER_BASE + 0x188);	//can1 transmit message abort control
__no_init volatile uint8_t CAN1TAAK @ (REGISTER_BASE + 0x189);	//can1 transmit message abort status
__no_init volatile uint8_t CAN1TBSEL @ (REGISTER_BASE + 0x18a);	//can1 transmit buffer select
__no_init volatile uint8_t CAN1IDAC @ (REGISTER_BASE + 0x18b);	//can1 identifier acceptance control

__no_init volatile uint8_t CAN1RXERR @ (REGISTER_BASE + 0x18e);	//can1 receive error counter
__no_init volatile uint8_t CAN1TXERR @ (REGISTER_BASE + 0x18f);	//can1 transmit error counter
__no_init volatile uint8_t CAN1IDAR0 @ (REGISTER_BASE + 0x190);	//can1 identifier acceptance register 0
__no_init volatile uint8_t CAN1IDAR1 @ (REGISTER_BASE + 0x191);	//can1 identifier acceptance register 1
__no_init volatile uint8_t CAN1IDAR2 @ (REGISTER_BASE + 0x192);	//can1 identifier acceptance register 2
__no_init volatile uint8_t CAN1IDAR3 @ (REGISTER_BASE + 0x193);	//can1 identifier acceptance register 3
__no_init volatile uint8_t CAN1IDMR0 @ (REGISTER_BASE + 0x194);	//can1 identifier mask register 0
__no_init volatile uint8_t CAN1IDMR1 @ (REGISTER_BASE + 0x195);	//can1 identifier mask register 1
__no_init volatile uint8_t CAN1IDMR2 @ (REGISTER_BASE + 0x196);	//can1 identifier mask register 2
__no_init volatile uint8_t CAN1IDMR3 @ (REGISTER_BASE + 0x197);	//can1 identifier mask register 3
__no_init volatile uint8_t CAN1IDAR4 @ (REGISTER_BASE + 0x198);	//can1 identifier acceptance register 4
__no_init volatile uint8_t CAN1IDAR5 @ (REGISTER_BASE + 0x199);	//can1 identifier acceptance register 5
__no_init volatile uint8_t CAN1IDAR6 @ (REGISTER_BASE + 0x19a);	//can1 identifier acceptance register 6
__no_init volatile uint8_t CAN1IDAR7 @ (REGISTER_BASE + 0x19b);	//can1 identifier acceptance register 7
__no_init volatile uint8_t CAN1IDMR4 @ (REGISTER_BASE + 0x19c);	//can1 identifier mask register 4
__no_init volatile uint8_t CAN1IDMR5 @ (REGISTER_BASE + 0x19d);	//can1 identifier mask register 5
__no_init volatile uint8_t CAN1IDMR6 @ (REGISTER_BASE + 0x19e);	//can1 identifier mask register 6
__no_init volatile uint8_t CAN1IDMR7 @ (REGISTER_BASE + 0x19f);	//can1 identifier mask register 7
__no_init volatile uint8_t CAN1RXFG @ (REGISTER_BASE + 0x1a0);	//can1 rx foreground buffer thru +$1af
__no_init volatile uint8_t CAN1TXFG @ (REGISTER_BASE + 0x1b0);	//can1 tx foreground buffer thru +$1bf

__no_init volatile uint8_t CAN2CTL0 @ (REGISTER_BASE + 0x1c0);	//can2 control register 0
__no_init volatile uint8_t CAN2CTL1 @ (REGISTER_BASE + 0x1c1);	//can2 control register 1
__no_init volatile uint8_t CAN2BTR0 @ (REGISTER_BASE + 0x1c2);	//can2 bus timing register 0
__no_init volatile uint8_t CAN2BTR1 @ (REGISTER_BASE + 0x1c3);	//can2 bus timing register 1
__no_init volatile uint8_t CAN2RFLG @ (REGISTER_BASE + 0x1c4);	//can2 receiver flags
__no_init volatile uint8_t CAN2RIER @ (REGISTER_BASE + 0x1c5);	//can2 receiver interrupt enables
__no_init volatile uint8_t CAN2TFLG @ (REGISTER_BASE + 0x1c6);	//can2 transmit flags
__no_init volatile uint8_t CAN2TIER @ (REGISTER_BASE + 0x1c7);	//can2 transmit interrupt enables
__no_init volatile uint8_t CAN2TARQ @ (REGISTER_BASE + 0x1c8);	//can2 transmit message abort control
__no_init volatile uint8_t CAN2TAAK @ (REGISTER_BASE + 0x1c9);	//can2 transmit message abort status
__no_init volatile uint8_t CAN2TBSEL @ (REGISTER_BASE + 0x1ca);	//can2 transmit buffer select
__no_init volatile uint8_t CAN2IDAC @ (REGISTER_BASE + 0x1cb);	//can2 identifier acceptance control

__no_init volatile uint8_t CAN2RXERR @ (REGISTER_BASE + 0x1ce);	//can2 receive error counter
__no_init volatile uint8_t CAN2TXERR @ (REGISTER_BASE + 0x1cf);	//can2 transmit error counter
__no_init volatile uint8_t CAN2IDAR0 @ (REGISTER_BASE + 0x1d0);	//can2 identifier acceptance register 0
__no_init volatile uint8_t CAN2IDAR1 @ (REGISTER_BASE + 0x1d1);	//can2 identifier acceptance register 1
__no_init volatile uint8_t CAN2IDAR2 @ (REGISTER_BASE + 0x1d2);	//can2 identifier acceptance register 2
__no_init volatile uint8_t CAN2IDAR3 @ (REGISTER_BASE + 0x1d3);	//can2 identifier acceptance register 3
__no_init volatile uint8_t CAN2IDMR0 @ (REGISTER_BASE + 0x1d4);	//can2 identifier mask register 0
__no_init volatile uint8_t CAN2IDMR1 @ (REGISTER_BASE + 0x1d5);	//can2 identifier mask register 1
__no_init volatile uint8_t CAN2IDMR2 @ (REGISTER_BASE + 0x1d6);	//can2 identifier mask register 2
__no_init volatile uint8_t CAN2IDMR3 @ (REGISTER_BASE + 0x1d7);	//can2 identifier mask register 3
__no_init volatile uint8_t CAN2IDAR4 @ (REGISTER_BASE + 0x1d8);	//can2 identifier acceptance register 4
__no_init volatile uint8_t CAN2IDAR5 @ (REGISTER_BASE + 0x1d9);	//can2 identifier acceptance register 5
__no_init volatile uint8_t CAN2IDAR6 @ (REGISTER_BASE + 0x1da);	//can2 identifier acceptance register 6
__no_init volatile uint8_t CAN2IDAR7 @ (REGISTER_BASE + 0x1db);	//can2 identifier acceptance register 7
__no_init volatile uint8_t CAN2IDMR4 @ (REGISTER_BASE + 0x1dc);	//can2 identifier mask register 4
__no_init volatile uint8_t CAN2IDMR5 @ (REGISTER_BASE + 0x1dd);	//can2 identifier mask register 5
__no_init volatile uint8_t CAN2IDMR6 @ (REGISTER_BASE + 0x1de);	//can2 identifier mask register 6
__no_init volatile uint8_t CAN2IDMR7 @ (REGISTER_BASE + 0x1df);	//can2 identifier mask register 7
__no_init volatile uint8_t CAN2RXFG @ (REGISTER_BASE + 0x1e0);	//can2 rx foreground buffer thru +$1ef
__no_init volatile uint8_t CAN2TXFG @ (REGISTER_BASE + 0x1f0);	//can2 tx foreground buffer thru +$1ff

__no_init volatile uint8_t CAN3CTL0 @ (REGISTER_BASE + 0x200);	//can3 control register 0
__no_init volatile uint8_t CAN3CTL1 @ (REGISTER_BASE + 0x201);	//can3 control register 1
__no_init volatile uint8_t CAN3BTR0 @ (REGISTER_BASE + 0x202);	//can3 bus timing register 0
__no_init volatile uint8_t CAN3BTR1 @ (REGISTER_BASE + 0x203);	//can3 bus timing register 1
__no_init volatile uint8_t CAN3RFLG @ (REGISTER_BASE + 0x204);	//can3 receiver flags
__no_init volatile uint8_t CAN3RIER @ (REGISTER_BASE + 0x205);	//can3 receiver interrupt enables
__no_init volatile uint8_t CAN3TFLG @ (REGISTER_BASE + 0x206);	//can3 transmit flags
__no_init volatile uint8_t CAN3TIER @ (REGISTER_BASE + 0x207);	//can3 transmit interrupt enables
__no_init volatile uint8_t CAN3TARQ @ (REGISTER_BASE + 0x208);	//can3 transmit message abort control
__no_init volatile uint8_t CAN3TAAK @ (REGISTER_BASE + 0x209);	//can3 transmit message abort status
__no_init volatile uint8_t CAN3TBSEL @ (REGISTER_BASE + 0x20a);	//can3 transmit buffer select
__no_init volatile uint8_t CAN3IDAC @ (REGISTER_BASE + 0x20b);	//can3 identifier acceptance control

__no_init volatile uint8_t CAN3RXERR @ (REGISTER_BASE + 0x20e);	//can3 receive error counter
__no_init volatile uint8_t CAN3TXERR @ (REGISTER_BASE + 0x20f);	//can3 transmit error counter
__no_init volatile uint8_t CAN3IDAR0 @ (REGISTER_BASE + 0x210);	//can3 identifier acceptance register 0
__no_init volatile uint8_t CAN3IDAR1 @ (REGISTER_BASE + 0x211);	//can3 identifier acceptance register 1
__no_init volatile uint8_t CAN3IDAR2 @ (REGISTER_BASE + 0x212);	//can3 identifier acceptance register 2
__no_init volatile uint8_t CAN3IDAR3 @ (REGISTER_BASE + 0x213);	//can3 identifier acceptance register 3
__no_init volatile uint8_t CAN3IDMR0 @ (REGISTER_BASE + 0x214);	//can3 identifier mask register 0
__no_init volatile uint8_t CAN3IDMR1 @ (REGISTER_BASE + 0x215);	//can3 identifier mask register 1
__no_init volatile uint8_t CAN3IDMR2 @ (REGISTER_BASE + 0x216);	//can3 identifier mask register 2
__no_init volatile uint8_t CAN3IDMR3 @ (REGISTER_BASE + 0x217);	//can3 identifier mask register 3
__no_init volatile uint8_t CAN3IDAR4 @ (REGISTER_BASE + 0x218);	//can3 identifier acceptance register 4
__no_init volatile uint8_t CAN3IDAR5 @ (REGISTER_BASE + 0x219);	//can3 identifier acceptance register 5
__no_init volatile uint8_t CAN3IDAR6 @ (REGISTER_BASE + 0x21a);	//can3 identifier acceptance register 6
__no_init volatile uint8_t CAN3IDAR7 @ (REGISTER_BASE + 0x21b);	//can3 identifier acceptance register 7
__no_init volatile uint8_t CAN3IDMR4 @ (REGISTER_BASE + 0x21c);	//can3 identifier mask register 4
__no_init volatile uint8_t CAN3IDMR5 @ (REGISTER_BASE + 0x21d);	//can3 identifier mask register 5
__no_init volatile uint8_t CAN3IDMR6 @ (REGISTER_BASE + 0x21e);	//can3 identifier mask register 6
__no_init volatile uint8_t CAN3IDMR7 @ (REGISTER_BASE + 0x21f);	//can3 identifier mask register 7
__no_init volatile uint8_t CAN3RXFG @ (REGISTER_BASE + 0x220);	//can3 rx foreground buffer thru +$22f
__no_init volatile uint8_t CAN3TXFG @ (REGISTER_BASE + 0x230);	//can3 tx foreground buffer thru +$23f

__no_init volatile uint8_t PTT @ (REGISTER_BASE + 0x240);		//portt data register
__no_init volatile uint8_t PTIT @ (REGISTER_BASE + 0x241);		//portt input register
__no_init volatile uint8_t DDRT @ (REGISTER_BASE + 0x242);		//portt direction register
__no_init volatile uint8_t RDRT @ (REGISTER_BASE + 0x243);		//portt reduced drive register
__no_init volatile uint8_t PERT @ (REGISTER_BASE + 0x244);		//portt pull device enable
__no_init volatile uint8_t PPST @ (REGISTER_BASE + 0x245);		//portt pull polarity select

__no_init volatile uint8_t PTS @ (REGISTER_BASE + 0x248);		//ports data register
__no_init volatile uint8_t PTIS @ (REGISTER_BASE + 0x249);		//ports input register
__no_init volatile uint8_t DDRS @ (REGISTER_BASE + 0x24a);		//ports direction register
__no_init volatile uint8_t RDRS @ (REGISTER_BASE + 0x24b);		//ports reduced drive register
__no_init volatile uint8_t PERS @ (REGISTER_BASE + 0x24c);		//ports pull device enable
__no_init volatile uint8_t PPSS @ (REGISTER_BASE + 0x24d);		//ports pull polarity select
__no_init volatile uint8_t WOMS @ (REGISTER_BASE + 0x24e);		//ports wired or mode register

__no_init volatile uint8_t PTM @ (REGISTER_BASE + 0x250);		//portm data register
__no_init volatile uint8_t PTIM @ (REGISTER_BASE + 0x251);		//portm input register
__no_init volatile uint8_t DDRM @ (REGISTER_BASE + 0x252);		//portm direction register
__no_init volatile uint8_t RDRM @ (REGISTER_BASE + 0x253);		//portm reduced drive register
__no_init volatile uint8_t PERM @ (REGISTER_BASE + 0x254);		//portm pull device enable
__no_init volatile uint8_t PPSM @ (REGISTER_BASE + 0x255);		//portm pull polarity select
__no_init volatile uint8_t WOMM @ (REGISTER_BASE + 0x256);		//portm wired or mode register
__no_init volatile uint8_t MODRR @ (REGISTER_BASE + 0x257);		//portm module routing register
__no_init volatile uint8_t PTP @ (REGISTER_BASE + 0x258);		//portp data register
__no_init volatile uint8_t PTIP @ (REGISTER_BASE + 0x259);		//portp input register
__no_init volatile uint8_t DDRP @ (REGISTER_BASE + 0x25a);		//portp direction register
__no_init volatile uint8_t RDRP @ (REGISTER_BASE + 0x25b);		//portp reduced drive register
__no_init volatile uint8_t PERP @ (REGISTER_BASE + 0x25c);		//portp pull device enable
__no_init volatile uint8_t PPSP @ (REGISTER_BASE + 0x25d);		//portp pull polarity select
__no_init volatile uint8_t PIEP @ (REGISTER_BASE + 0x25e);		//portp interrupt enable register
__no_init volatile uint8_t PIFP @ (REGISTER_BASE + 0x25f);		//portp interrupt flag register
__no_init volatile uint8_t PTH @ (REGISTER_BASE + 0x260);		//porth data register
__no_init volatile uint8_t PTIH @ (REGISTER_BASE + 0x261);		//porth input register
__no_init volatile uint8_t DDRH @ (REGISTER_BASE + 0x262);		//porth direction register
__no_init volatile uint8_t RDRH @ (REGISTER_BASE + 0x263);		//porth reduced drive register
__no_init volatile uint8_t PERH @ (REGISTER_BASE + 0x264);		//porth pull device enable
__no_init volatile uint8_t PPSH @ (REGISTER_BASE + 0x265);		//porth pull polarity select
__no_init volatile uint8_t PIEH @ (REGISTER_BASE + 0x266);		//porth interrupt enable register
__no_init volatile uint8_t PIFH @ (REGISTER_BASE + 0x267);		//porth interrupt flag register
__no_init volatile uint8_t PTJ @ (REGISTER_BASE + 0x268);		//portp data register
__no_init volatile uint8_t PTIJ @ (REGISTER_BASE + 0x269);		//portp input register
__no_init volatile uint8_t DDRJ @ (REGISTER_BASE + 0x26a);		//portp direction register
__no_init volatile uint8_t RDRJ @ (REGISTER_BASE + 0x26b);		//portp reduced drive register
__no_init volatile uint8_t PERJ @ (REGISTER_BASE + 0x26c);		//portp pull device enable
__no_init volatile uint8_t PPSJ @ (REGISTER_BASE + 0x26d);		//portp pull polarity select
__no_init volatile uint8_t PIEJ @ (REGISTER_BASE + 0x26e);		//portp interrupt enable register
__no_init volatile uint8_t PIFJ @ (REGISTER_BASE + 0x26f);		//portp interrupt flag register

__no_init volatile uint8_t CAN4CTL0 @ (REGISTER_BASE + 0x280);	//can4 control register 0
__no_init volatile uint8_t CAN4CTL1 @ (REGISTER_BASE + 0x281);	//can4 control register 1
__no_init volatile uint8_t CAN4BTR0 @ (REGISTER_BASE + 0x282);	//can4 bus timing register 0
__no_init volatile uint8_t CAN4BTR1 @ (REGISTER_BASE + 0x283);	//can4 bus timing register 1
__no_init volatile uint8_t CAN4RFLG @ (REGISTER_BASE + 0x284);	//can4 receiver flags
__no_init volatile uint8_t CAN4RIER @ (REGISTER_BASE + 0x285);	//can4 receiver interrupt enables
__no_init volatile uint8_t CAN4TFLG @ (REGISTER_BASE + 0x286);	//can4 transmit flags
__no_init volatile uint8_t CAN4TIER @ (REGISTER_BASE + 0x287);	//can4 transmit interrupt enables
__no_init volatile uint8_t CAN4TARQ @ (REGISTER_BASE + 0x288);	//can4 transmit message abort control
__no_init volatile uint8_t CAN4TAAK @ (REGISTER_BASE + 0x289);	//can4 transmit message abort status
__no_init volatile uint8_t CAN4TBSEL @ (REGISTER_BASE + 0x28a);	//can4 transmit buffer select
__no_init volatile uint8_t CAN4IDAC @ (REGISTER_BASE + 0x28b);	//can4 identifier acceptance control

__no_init volatile uint8_t CAN4RXERR @ (REGISTER_BASE + 0x28e);	//can4 receive error counter
__no_init volatile uint8_t CAN4TXERR @ (REGISTER_BASE + 0x28f);	//can4 transmit error counter
__no_init volatile uint8_t CAN4IDAR0 @ (REGISTER_BASE + 0x290);	//can4 identifier acceptance register 0
__no_init volatile uint8_t CAN4IDAR1 @ (REGISTER_BASE + 0x291);	//can4 identifier acceptance register 1
__no_init volatile uint8_t CAN4IDAR2 @ (REGISTER_BASE + 0x292);	//can4 identifier acceptance register 2
__no_init volatile uint8_t CAN4IDAR3 @ (REGISTER_BASE + 0x293);	//can4 identifier acceptance register 3
__no_init volatile uint8_t CAN4IDMR0 @ (REGISTER_BASE + 0x294);	//can4 identifier mask register 0
__no_init volatile uint8_t CAN4IDMR1 @ (REGISTER_BASE + 0x295);	//can4 identifier mask register 1
__no_init volatile uint8_t CAN4IDMR2 @ (REGISTER_BASE + 0x296);	//can4 identifier mask register 2
__no_init volatile uint8_t CAN4IDMR3 @ (REGISTER_BASE + 0x297);	//can4 identifier mask register 3
__no_init volatile uint8_t CAN4IDAR4 @ (REGISTER_BASE + 0x298);	//can4 identifier acceptance register 4
__no_init volatile uint8_t CAN4IDAR5 @ (REGISTER_BASE + 0x299);	//can4 identifier acceptance register 5
__no_init volatile uint8_t CAN4IDAR6 @ (REGISTER_BASE + 0x29a);	//can4 identifier acceptance register 6
__no_init volatile uint8_t CAN4IDAR7 @ (REGISTER_BASE + 0x29b);	//can4 identifier acceptance register 7
__no_init volatile uint8_t CAN4IDMR4 @ (REGISTER_BASE + 0x29c);	//can4 identifier mask register 4
__no_init volatile uint8_t CAN4IDMR5 @ (REGISTER_BASE + 0x29d);	//can4 identifier mask register 5
__no_init volatile uint8_t CAN4IDMR6 @ (REGISTER_BASE + 0x29e);	//can4 identifier mask register 6
__no_init volatile uint8_t CAN4IDMR7 @ (REGISTER_BASE + 0x29f);	//can4 identifier mask register 7
__no_init volatile uint8_t CAN4RXFG @ (REGISTER_BASE + 0x2a0);	//can4 rx foreground buffer thru +$2af
__no_init volatile uint8_t CAN4TXFG @ (REGISTER_BASE + 0x2b0);	//can4 tx foreground buffer thru +$2bf

#endif
	
#endif
