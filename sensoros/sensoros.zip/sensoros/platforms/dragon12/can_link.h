/**
 * CAN Link Class Definition File
 *
 * Defines the CanLink class.
 *
 * Note: This class only supports node_address_t as uint8_t
 *
 * @author Robert Moore <rob@mooredesign.com.au>
 * @version 1.1.0
 * @date 2009-07-17
 */

#ifndef _CAN_LINK_H
#define _CAN_LINK_H

class CanLink: implements DataLinkLayer {

	public:
		CanLink(link_id_t linkId, uint8_t canId);
		error_t downFromNetwork(node_address_t destination, message_t* msg,
								data_length_t length, priority_t priority);
		error_t cancel(message_t* msg);
		void upFromPhysical();
		void sendDone();
		inline link_id_t getLinkId();
		inline data_length_t maxPayloadLength();
		inline data_length_t getPayloadLength(message_t* msg);
		inline timestamp_t getTimestamp(message_t* msg);
		inline node_address_t getSource(message_t* msg);
		inline node_address_t getDestination(message_t* msg);
	private:
		link_id_t linkId;
		uint8_t canId;
		message_t initialRecvBuffer;
		message_t* recvBufferPtr;
		message_t* sendPointer[3];
		
		inline uint8_t getBuffer(message_t* msg);
		inline void init();
};

#ifdef MSCAN0
	extern CanLink can0Link;
#endif
#ifdef MSCAN1
	extern CanLink can1Link;
#endif
#ifdef MSCAN2
	extern CanLink can2Link;
#endif
#ifdef MSCAN3
	extern CanLink can3Link;
#endif
#ifdef MSCAN4
	extern CanLink can4Link;
#endif

#endif
