/**
 * Null Application Network Information Header File
 *
 * @author Robert Moore <rob@mooredesign.com.au>
 * @version 1.0.0
 * @date 2009-07-21
 */

#ifndef _APPLICATION_NETWORK_INFO_H
#define _APPLICATION_NETWORK_INFO_H

typedef uint8_t node_address_t;

// If the node address hasn't already been defined
#ifndef NODE_ADDRESS
	#define NODE_ADDRESS 1
#endif

#endif
