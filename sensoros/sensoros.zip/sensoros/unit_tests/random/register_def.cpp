__no_init volatile unsigned char test @ (0x00);

int main() {

	test = 0xFF;

	return 0;
}
