#include <iostream>

int main() {

	int var = 1;

	{

		int var = 2;

		std::cout << var << std::endl;

	}

	{

		int var = 3;

		std::cout << var << std::endl;

	}

	std::cout << var << std::endl;

}
