#include <stdio.h>

uint8_t* binary(uint8_t v) {

	static uint8_t binstr[9];
	uint8_t i;

	binstr[8] = '\0';

	for (i=0; i<8; i++) {
		binstr[7-i] = v & 1 ? '1' : '0';
		v = v / 2;
	}

	return binstr;
}

int main() {

	uint8_t used;
	for (used = 1; used != 0; ++used) {

		uint8_t lowestBit = used&(-used);
		uint8_t lowestUnused = lowestBit;
		uint8_t lowestFreeBuffer = 0;
		// If there are any unused buffers
		if (used > 0) {
			// Find log2 of lowestUnused to get the buffer number
			while (lowestUnused > 0x4) {
				lowestFreeBuffer += 0x3;
				lowestUnused >>= 3;
			}
			lowestFreeBuffer += lowestUnused >> 1;
		}
		printf("%d (%s)", used, binary(used));
		printf(" %d (%s) %d\n", lowestBit, binary(lowestBit), lowestFreeBuffer);
	}
	return 0;
}

