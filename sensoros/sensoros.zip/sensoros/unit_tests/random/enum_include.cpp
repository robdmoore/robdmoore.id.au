#include <iostream>

int main() {

	typedef enum {
		ZERO=0,
		#include "enum.h"
		TWO
	} test;

	std::cout << ZERO << ONE << TWO << std::endl;

	return 0;
}
