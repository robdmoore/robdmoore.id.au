#include <iostream>

using namespace std;

int main() {

	enum signal_t {
		SIG_SOFTWARE_INIT=0,
		SIG_SYSTEM_BOOTED,
		SIG_TEST
	};

	cout << sizeof(signal_t) << endl;

	return 0;
}
