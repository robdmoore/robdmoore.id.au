/**
 * Based on code inside:
 * 	"Embedded Systems Design and Applications with the 68HC12 and HCS12"
 */

#include <main.h>

void init(void);
void originalInit(void);

typedef struct {
	uint8_t id3;
	uint8_t id2;
	uint8_t id1;
	uint8_t id0;
	uint8_t data[8];
	uint8_t length;
	uint8_t priority;
	uint16_t timestamp;
} mscan_buffer_t;

int main(void) {

	Debug::init();
	
	init();
	
	CAN0TBSEL = 0x01;
	
	mscan_buffer_t* buffer = (mscan_buffer_t*)&CAN0TXFG;
	
	buffer->id3 = 0xFF;
	buffer->id2 = 0xFF;
	buffer->id1 = 0xFF;
	buffer->id0 = 0xFE;
	buffer->data[0] = 0x01;
	buffer->data[1] = 0x02;
	buffer->data[2] = 0x03;
	buffer->data[3] = 0x04;
	buffer->data[4] = 0x05;
	buffer->data[5] = 0x06;
	buffer->data[6] = 0x07;
	buffer->data[7] = 0x08;
	buffer->length = 0x08;
	buffer->priority = 0x00;
	CAN0TFLG = 0x01;
	
	while ((CAN0TFLG & 0x01) == 0);
	Debug::leds(TRUE, 0x1);
	
	
}


void init(void) {

	// Enter init mode
	while ((CAN0CTL1 & INITAK) == 0)
		CAN0CTL0 = INITRQ;

	// Enable CAN module
	CAN0CTL1 |= CANE;

	// Turn off listen mode
	CAN0CTL1 &= ~LISTEN;

	// Turn on loop-back mode if LOOP_BACK is true
	#if LOOP_BACK
		CAN0CTL1 |= LOOPB;
	#endif

	CAN0BTR0 = 0xC1;
	CAN0BTR1 = 0xF7;

	// Leave init mode (set INITRQ to 0)
	CAN0CTL0 = 0x0;

	// Wait for sync
	while ((CAN0CTL0 & SYNCH) == 0) {}
};

void originalInit(void) {
	COPCTL = 0x00;
	while ((CAN0CTL1 | 0x01) == 0) {
		CAN0CTL0 = CAN0CTL0 | 0x01;
	}
	CAN0CTL1 = CAN0CTL1 | 0x80;
	CAN0CTL1 = CAN0CTL1 & 0xEF;
	CAN0CTL1 = CAN0CTL1 | 0x20;
	CAN0BTR0 = 0xC1;
	CAN0BTR1 = 0xF7;
	CAN0CTL0 = CAN0CTL0 & 0xFE;
	while ((CAN0CTL0 & 0x10) == 0) {};
}
