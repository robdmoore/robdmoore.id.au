/**
 * SensorOS Signal Router Class Unit Test
 *
 * Expected Result:
 *
 *	()()()()()()()(.)
 *	"test2"
 *	"test3"
 *	()()()()()()(.)()
 *	"test2"
 *	"test3"
 *	()()()()()()(.)(.)
 *	"test2"
 *	"test3"
 * Then: leds will increment and wrap approx. every second
 *  at the same time as they wrap around "ovf" should appear on the COM port
 *
 * Successfully ran the test 2009-07-06 17:59PM GMT +8
 */

#include <platform.h>

#define OC0_OFFSET (0x00FF)

void test(void) {
	static uint8_t ledValue = 0;
	// Increment leds
	Debug::leds(++ledValue);
}
static const VoidStaticFunctor testFunctor(&test);

void test2(void) {
	Debug::print("test2\r\n");
}
static const VoidStaticFunctor test2Functor(&test2);

void test3(void) {
	Debug::print("test3\r\n");
}
static const VoidStaticFunctor test3Functor(&test3);

void test4(void) {
	Debug::print("ovf\r\n");
}
static const VoidStaticFunctor test4Functor(&test4);

#ifdef __IAR__
	#pragma vector=TIMERCH0_VECTOR
#endif
interrupt_t ch0ISR(void) {
	// Set next increment
	TC0 += OC0_OFFSET;
	// Signal an Channel 0 OC event
	SignalRouter::getInstance()->signal(SIG_TIME_CH0);
	// Clear interrupt flag
	TFLG1 &= BIT0;
}
SET_ISR(TIMERCH0_VECTOR, ch0ISR)

#ifdef __IAR__
	#pragma vector=TIMEROVF_VECTOR
#endif
interrupt_t tofISR(void) {
	SignalRouter::getInstance()->signal(SIG_TIME_OVF);
	TFLG2 = TOF;
}
SET_ISR(TIMEROVF_VECTOR, tofISR)

int main(void) {

	// Initialise Debug class
	Debug::init();

	// Initialise the scheduler
	SignalRouter* signalRouter = SignalRouter::getInstance();
	
	// Set the signal handlers
	signalRouter->registerHandler(SIG_SOFTWARE_INIT, &testFunctor);
	signalRouter->registerHandler(SIG_SYSTEM_BOOTED, &test2Functor);
	signalRouter->registerHandler(SIG_CAN0_RECV, &test3Functor);
	signalRouter->registerHandler(SIG_TIME_CH0, &testFunctor);
	signalRouter->registerHandler(SIG_TIME_OVF, &test4Functor);

	// Do this three times
	for (uint8_t i = 0; i<3; i++) {

		// Post some events
		signalRouter->signal(SIG_SOFTWARE_INIT);
		signalRouter->signal(SIG_SYSTEM_BOOTED);
		signalRouter->signal(SIG_CAN0_RECV);
	}
	
	// Set up timer subsystem

	// Enable timer overflow vector and prescale by 128
	TSCR2 = TOI | BIT2 | BIT1 | BIT0;

	// Enable channel0 interrupt
	TIE |= BIT0;

	// Enable channel0 as OC mode
	TIOS |= BIT0;

	// Clear any interrupts already occuring
	TFLG1 |= BIT0;

	// Set the compare value
	TC0 = OC0_OFFSET;

	// Enable timer and stop it in freeze mode
	TSCR1 |= (TEN | TSFRZ);

	// Enable interrupts
	__enable_interrupts();

	// Loop
	for(;;);

	return 0;
}
