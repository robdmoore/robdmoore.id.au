/**
 * SensorOS Schduler Class Unit Test Case
 *
 * Expected Result:
 *
 *	()()()()()()()(.)
 *	"test2"
 *	"test3"
 *	()()()()()()(.)()
 *	"test2"
 *	"test3"
 *	()()()()()()(.)(.)
 *	"test2"
 *	"test3"
 * Then: leds will increment and wrap approx. every second
 *
 * Successfully ran the test 2009-07-05 18:52PM GMT +8
 */

#include <platform.h>

#define OC0_OFFSET (0x00FF)

void Platform::sleep(void) {
	return;
}

void nothing(void) {
	return;
}
static const VoidStaticFunctor nothingFunctor(&nothing);

void test(void) {
	static uint8_t ledValue = 0;
	// Increment leds
	Debug::leds(++ledValue);
}
static const VoidStaticFunctor testFunctor(&test);

void test2(void) {
	Debug::print("test2\r\n");
}
static const VoidStaticFunctor test2Functor(&test2);

void test3(void) {
	Debug::print("test3\r\n");
}
static const VoidStaticFunctor test3Functor(&test3);

#ifdef __IAR__
	#pragma vector=TIMERCH0_VECTOR
#endif
interrupt_t ch0ISR(void) {
	// Set next increment
	TC0 += OC0_OFFSET;
	// Post a task
	Scheduler* scheduler = Scheduler::getInstance();
	if (scheduler->pushTask(&testFunctor) == QUEUE_FULL) {
		Debug::print("Queue Full Error");
	}
	// Clear interrupt flag
	TFLG1 &= BIT0;
}
SET_ISR(TIMERCH0_VECTOR, ch0ISR)

#ifdef __IAR__
	#pragma vector=TIMEROVF_VECTOR
#endif
interrupt_t tofISR(void) {
	Debug::leds(0x0F);
	TFLG2 = TOF;
}
SET_ISR(TIMEROVF_VECTOR, tofISR)

int main(void) {

	// Initialise Debug class
	Debug::init();

	// Initialise the scheduler
	Scheduler* scheduler = Scheduler::getInstance();

	// Do this three times
	for (uint8_t i = 0; i<3; i++) {

		// Post some tasks
		scheduler->pushTask(&testFunctor);
		scheduler->pushTask(&test2Functor);
		scheduler->pushTask(&test3Functor);

		// Run all tasks
		while (scheduler->runNextTask());
	}
	
	// Set up timer subsystem

	// Enable timer overflow vector and prescale by 128
	TSCR2 = TOI | BIT2 | BIT1 | BIT0;

	// Enable channel0 interrupt
	TIE |= BIT0;

	// Enable channel0 as OC mode
	TIOS |= BIT0;

	// Clear any interrupts already occuring
	TFLG1 |= BIT0;

	// Set the compare value
	TC0 = OC0_OFFSET;

	// Enable timer and stop it in freeze mode
	TSCR1 |= (TEN | TSFRZ);

	// Enable interrupts
	__enable_interrupts();

	// Loop on scheduler
	scheduler->taskLoop();

	return 0;
}
