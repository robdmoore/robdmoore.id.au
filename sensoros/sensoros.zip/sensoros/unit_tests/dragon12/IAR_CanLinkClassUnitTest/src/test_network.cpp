/**
 * CanLink Unit Test Network Layer Implementation File
 *
 * @author Robert Moore <rob@mooredesign.com.au>
 * @version 1.0.0
 * @date 2009-07-21
 */

#include <main.h>

TestNetwork TestNetwork::instance;

TestNetwork* TestNetwork::getInstance() {
	return &instance;
}

// This method shouldn't do such slow processing without pushing a task
// onto the scheduler, but in this case I'll use this to space out the flow
// of messages
message_t* TestNetwork::upFromDataLink(DataLinkLayer* linkLayer, message_t* msg,
					data_length_t length)
{
	Debug::toggleLed(0x2);
	Debug::printf("Received message (%u) from link (%u).\r\n", messageId,
				  linkLayer->getLinkId());
	Debug::printf(" Max Length: %u\r\n", linkLayer->maxPayloadLength());
	Debug::printf(" Length: %u/%u\r\n", length,
				  linkLayer->getPayloadLength(msg));
	Debug::printf(" Time: %hu\r\n", linkLayer->getTimestamp(msg));
	Debug::printf(" Source: %u\r\n", linkLayer->getSource(msg));
	Debug::printf(" Dest: %u\r\n", linkLayer->getDestination(msg));
	Debug::print(" Data: {");
	for (uint8_t i = 0; i < length; ++i) {
		if (i != 0)
			Debug::print(",");
		Debug::printf("%u", msg->data[i]);
	}
	Debug::print("}\r\n\r\n");
	++messageId;
	// Send a new message
	send();
	return msg;
};

error_t TestNetwork::send() {
	Debug::toggleLed(0x0);
	error_t status = EFULL;
	// Secure a message buffer
	message_t* msg = getFreeBuffer();
	if (msg != NULL) {
		// Populate the message
		for (uint8_t i = 0; i < length; ++i) {
			msg->data[i] = i+1;
		}
		// Send the message
		status = Network::getInstance()->getLink(0)->downFromNetwork(NULL,
														msg, length, NULL);
		// Round robin length
		if (status == SUCCESS) {
			++length;
			if (length > 8) length = 1;
		} else {
			Debug::toggleLed(0x7);
		}
	} else {
		Debug::toggleLed(0x6);
	}
	
	return status;
}

void TestNetwork::sendDone(message_t* msg, error_t status) {
	Debug::toggleLed(0x1);
	// Free the buffer used by msg
	ptrdiff_t bufferId = (ptrdiff_t)(buffers - msg);
	if (bufferId >=0 && bufferId <= 7) {
		Atomic
			if (bufferId == 0) {
				used |= 0x1;
			} else {
				used |= 0x1 << bufferId;
			}
		EndAtomic;
	}
};

TestNetwork::TestNetwork() {
	// Set all buffers as unused
	used = 0xFF;
	// Start length at 8 bytes
	length = 8;
	// Set initial message id to 0
	messageId = 0;
};

message_t* TestNetwork::getFreeBuffer() {
	message_t* buffer = NULL;
	uint8_t lowestFreeBuffer = 0;
	// Extract lowest set bit
	// http://realtimecollisiondetection.net/blog/?p=78
	uint8_t lowestSetBit = used&-used;
	uint8_t bit = lowestSetBit;
	Atomic
		// If there are any unused buffers
		if (used > 0) {
			// Find log2 of lowestUnused to get the buffer number
			// Takes advantage of the fact that if only one
			// 	bit is set in the integer, if the integer is 4 or less
			// 	the log2 of it is itself shifted right one
			// For an 8-bit number, this loop will enter a maximum of
			//	 two times
			while (bit > 0x4) {
				lowestFreeBuffer += 0x3;
				bit >>= 3;
			}
			lowestFreeBuffer += bit >> 1;
			// After extracting the lowest free buffer, claim it
			// 	and set buffer appropriately
			used &= ~lowestSetBit;
			buffer = &buffers[lowestFreeBuffer];
		}
	EndAtomic;
	return buffer;
};

