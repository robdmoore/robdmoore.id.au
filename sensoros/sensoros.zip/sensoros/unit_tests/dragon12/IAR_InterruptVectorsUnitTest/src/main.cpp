/**
 * SensorOS Interrupt Vectors Unit Test Case
 *
 * Expected Result:
 *
 * Leds count up, wrapping around in around 1s
 * Just after they wrap around the upper half will flash on
 *	briefly (when the timer overflows)
 *
 * Initial successful run 2009-05-15 12:46AM GMT +8
 * Modified and successfully run 2009-06-20 16:51PM GMT +8
 */

#include <platform.h>

// This is how ISR's will be defined for HCS12 in SensorOS to keep
// compatibility with GNUC
#ifdef __IAR__
	#pragma vector=TIMERCH0_VECTOR
#endif
interrupt_t ch0ISR(void) {
	static uint8_t ledValue = 0;
	// Set next increment
	TC0 += 0xFC;
	// Increment leds
	Debug::leds(++ledValue);
	// Clear interrupt flag
	TFLG1 &= BIT0;
}
SET_ISR(TIMERCH0_VECTOR, ch1ISR)
// End definition

#ifdef __IAR__
	#pragma vector=TIMEROVF_VECTOR
#endif
interrupt_t tofISR(void) {
	// Set all leds
	Debug::leds(0xF0);
	TFLG2 = TOF;
}
SET_ISR(TIMEROVF_VECTOR, tofISR)

int main(void) {
	
	__disable_interrupts();

	// Initialise Debug class
	Debug::init();

	// Set up timer subsystem

	// Enable timer overflow vector and prescale by 128
	TSCR2 = TOI | BIT2 | BIT1 | BIT0;
	
	// Enable channel0 interrupt
	TIE |= BIT0;
	
	// Enable channel0 as OC mode
	TIOS |= BIT0;
	
	// Clear any interrupts already occuring
	TFLG1 |= BIT0;

	// Set the compare value
	TC0 = 0xFC;

	// Enable timer and stop it in freeze mode
	TSCR1 |= (TEN | TSFRZ);
	
	__enable_interrupts();
	
	// Loop forever
	while (1) {}
}
