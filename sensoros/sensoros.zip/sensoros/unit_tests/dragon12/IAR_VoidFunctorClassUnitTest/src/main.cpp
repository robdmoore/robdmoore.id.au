/**
 * SensorOS VoidFunctor Class Unit Test Case
 *
 * Expected Result (on COM port):
 *
 * 	Test::testStatic()
 * 	Test::testStatic()
 * 	Test::test(): 10
 * 	Test::test(): 10
 *
 * Successfully ran the test 2009-05-10 10:52PM GMT +8
* Edited and successfully re-run 2009-07-05 19:01PM GMT +8
 */

#include <main.h>

class Test {
	public:
		Test(uint8_t value) {
			this->value = value;
		}
		void test() {
			Debug::printf("Test::test(): %d\r\n", value);
		}
		static void testStatic() {
			Debug::print("Test::testStatic()\r\n");
		}
	private:
		uint8_t value;
};

void testPolymorphism(VoidFunctor * v) {
	(*v)();
}

int main(void) {
	
	// Initialise Debug class
	Debug::init();

	// Create static functor
	VoidStaticFunctor* v1 = new VoidStaticFunctor(Test::testStatic);
	(*v1)();
	testPolymorphism(v1);
	
	VoidInstanceFunctor<Test>* v2 = new VoidInstanceFunctor<Test>(new Test(10), Test::test);
	(*v2)();
	testPolymorphism(v2);
}
