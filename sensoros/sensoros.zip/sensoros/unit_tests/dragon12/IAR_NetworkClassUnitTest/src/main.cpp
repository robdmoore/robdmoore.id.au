/**
 * SensorOS Network Class Unit Test Case
 *
 * Expected Result (on COM port):
 *
 * 	Node Address: 1
 * 	Initialising link 0
 * 	Network Currently has 1 links.
 * 	Initialising link 1
 * 	Network Currently has 2 links.
 * 	Initialising link 2
 * 	Network Currently has 3 links.
 * 	Initialising link 1
 * 	Network Currently has 3 links.
 * 	Initialising link 7
 * 	Network Currently has 3 links.
 * 	Down From Network: link 2: packet data: 100
 * 	Up From Data Link: link 2: packet data: 100
 *
 * Successfully ran the test 2009-05-10 9:56PM GMT +8
* Edited and succeessfully re-run 2009-07-05 19:03PM GMT +8
 */

#include <main.h>
class TestDataLink: implements DataLinkLayer {
	public:
		TestDataLink(uint8_t linkId) {
			this->linkId = linkId;
			Debug::printf("Initialising link %d\r\n", linkId);
			Debug::leds(1, linkId);
		};
		void downFromNetwork(packet_t* packet) {
			Debug::printf("Down From Network: link %d: packet data: %d\r\n",
				linkId,
				packet->data);		
		};
		link_id_t getLinkId() {
			return linkId;	
		};
	private:
		link_id_t linkId;
};

class TestNetworkLayer: implements NetworkLayer {
	public:
		void upFromDataLink(link_id_t linkId, packet_t* packet) {
			Debug::printf("Up From Data Link: link %d: packet data: %d\r\n",
				linkId,
				packet->data);	
		};
};

int main(void) {

	// Test packet
	packet_t packet;
	packet.data = 100;
	
	// Initialise Debug class and set leds
	Debug::init();	
	Debug::leds(0xF8);

	// Get singleton instance of network layer
	Network network = Network::getInstance();
	
	// Print out node address
	Debug::printf("Node Address: %d\r\n", network.getNodeAddress());
	
	// Assign three fresh data links in-order
	network.assignLink(new TestDataLink(0));
	Debug::printf("Network Currently has %d links.\r\n", network.getNumLinks());
	
	network.assignLink(new TestDataLink(1));
	Debug::printf("Network Currently has %d links.\r\n", network.getNumLinks());
	
	network.assignLink(new TestDataLink(2));
	Debug::printf("Network Currently has %d links.\r\n", network.getNumLinks());
	
	// Assign data link out-of-order (should be ignored)
	network.assignLink(new TestDataLink(1));
	Debug::printf("Network Currently has %d links.\r\n", network.getNumLinks());
	
	// Assign data link greater than NUM_DATA_LINKS (should be ignored)
	network.assignLink(new TestDataLink(7));
	Debug::printf("Network Currently has %d links.\r\n", network.getNumLinks());
	
	// Get link 2 and print out it's link id to check
	DataLinkLayer* dataLink = network.getLink(2);
	dataLink->downFromNetwork(&packet);
	
	// Assign a network layer
	network.assignNetworkLayer(new TestNetworkLayer());
	
	// Test getNetworkLayer()
	NetworkLayer* networkLayer = network.getNetworkLayer();
	networkLayer->upFromDataLink(2, &packet);
}
