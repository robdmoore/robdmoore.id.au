/**
 * SensorOS Scheduler Class Description
 *
 * @author Robert Moore <rob@mooredesign.com.au>
 * @date 2009-04-13
 * @version 1.0.0
 */

#ifndef _SCHEDULER_H_
#define _SCHEDULER_H_

#define NO_TASK (0)
#ifndef NUM_TASKS
	// 255 is the maximum possible due to the type
	//	of queueHead, queueTail (below) and n in the
	//	constructor
	#define NUM_TASKS (255)
#endif

typedef VoidFunctor const * task_t;

class Scheduler {

	public:
		static Scheduler* getInstance();
		~Scheduler();
		error_t pushTask(task_t task);
		bool runNextTask();
		void taskLoop();

	private:
		Scheduler();
		task_t popTask();

		static Scheduler instance;

		uint8_t queueHead;
		uint8_t queueTail;
		task_t taskQueue[NUM_TASKS];
};

#endif
