/**
 * SensorOS Network Class Implementation
 *
 * @author Robert Moore <rob@mooredesign.com.au>
 * @date 2009-04-16
 * @version 1.1.0
 */

#include <main.h>

Network Network::instance;

/**
 * Returns the singleton instance of the Network class
 * @return The instance
 */
Network* Network::getInstance() {

	return &instance;
}

/**
 * Registers a data link layer with the network
 * Will only add the data link layer if it is added
 * 	in order (e.g. link id 1 first, then 2 etc.) and the link id
 *	is less than the NUM_DATA_LINKS platform defined constant
 * @param link A reference to the data link layer to register
 */
void Network::assignLink(DataLinkLayer* link) {

	if (link->getLinkId() == nLinks && nLinks < NUM_DATA_LINKS) {
		dataLinks[nLinks] = link;
		nLinks++;
	}
}

/**
 * Returns a reference to the data link with the given id
 * @param linkId The id of the data link to return
 * @return A reference to the data link layer
 */
DataLinkLayer* Network::getLink(link_id_t linkId) {

	return dataLinks[linkId];
}

/**
 * Registers the network layer with the network
 * @param A reference to the network layer to register
 */
void Network::assignNetworkLayer(NetworkLayer* networkLayer) {
	this->networkLayer = networkLayer;
}

/**
 * Returns a reference to the network layer
 * @return A reference to the network layer
 */
NetworkLayer* Network::getNetworkLayer() {
	return networkLayer;
}

/**
 * Returns the number of data links registered with the network
 * @return The number of data links
 */
link_id_t Network::getNumLinks() {
	return nLinks;
}

/**
 * Returns the network address of the current node
 * @return The node's network address
 */
node_address_t Network::getNodeAddress() {
	return nodeAddress;
}

/**
 * Destructor Method
 */
Network::~Network() {}

/**
 * Constructor Method
 */
Network::Network() {

	nodeAddress = NODE_ADDRESS;
	nLinks = 0;
}

