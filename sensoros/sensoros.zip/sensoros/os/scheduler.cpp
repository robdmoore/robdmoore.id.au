/**
 * SensorOS Scheduler Class Implementation
 *
 * Based in part on tos/system/SchedulerBasicP.nc
 * 	from TinyOS
 *
 * @author Robert Moore <rob@mooredesign.com.au>
 * @date 2009-04-13
 * @version 1.0.0
 */

#include <main.h>

Scheduler Scheduler::instance;

/**
 * Returns the singleton instance of the Scheduler class
 * @return The instance
 */
Scheduler* Scheduler::getInstance() {

	return &instance;
}

/**
 * Destructor of the Scheduler class
 */
Scheduler::~Scheduler() { }

/**
 * Pushes the given task onto the end of the task queue
 * Contains an atomic section
 * @param task The task to push onto the queue
 * @return The status of the operation (either SUCCESS or EFULL)
 */
error_t Scheduler::pushTask(task_t task) {

	error_t status = FAIL;

	// Atomic section
	Atomic
		// If the queue isn't full
		if (queueHead != ((queueTail+1) % NUM_TASKS)) {
			// Add the task to the tail of the queue and increment the
			// tail pointer
			taskQueue[queueTail] = task;
			queueTail = (queueTail+1) % NUM_TASKS;
			status = SUCCESS;
		} else {
			status = EFULL;
		}
	EndAtomic;

	return status;
}

/**
 * Runs the task at the head of the queue and returns whether or
 * 	not there is a task left on the queue
 * Contains an atomic section
 * 	@return Whether or not there is a task left on the queue
 */
bool Scheduler::runNextTask() {

	task_t nextTask;
	bool tasksLeft = TRUE;

	// Pop the queue
	nextTask = popTask();

	// Was there a task to run?
	if (nextTask != NO_TASK) {
		// Run the popped task
		(*nextTask)();
	}
	
	// Check if there are any tasks left in the queue
	Atomic
		tasksLeft = taskQueue[queueHead] != NO_TASK;
	EndAtomic;

	return tasksLeft;
}

/**
 * Enters an infinite loop that runs the next task on the queue and
 * 	sends the processor into sleep mode when the queue is exhausted
 * Calls Platform::sleep()
 */
void Scheduler::taskLoop() {

	// Infinite Loop
	for (;;) {

		// Run all the tasks in the queue until the queue is empty
		while (runNextTask()) {};

		// No tasks left, put the platform to sleep
		Platform::sleep();

	}
}

/**
 * The constructor of the Scheduler class
 */
Scheduler::Scheduler() {
	// Atomic section
	Atomic
		// Set all NUM_TASKS slots to NO_TASK
		// Following 4 lines copied from memset()
		uint8_t n = NUM_TASKS;
		uint8_t* t = (uint8_t*)taskQueue;
		for (; 0 < n; ++t, --n)
	        *t = NO_TASK;
		// Set head to slot 0
		queueHead = 0;
		// Set tail to slot 0
		queueTail = 0;
	EndAtomic;
}

/**
 * Returns the task at the head of the queue, or NO_TASK if the queue is empty
 * @return The task at the head of the queue or NO_TASK if the queue is empty
 */
task_t Scheduler::popTask() {

	task_t task;
	
	// Atomic section
	Atomic

		// If there is a task on the queue
		if (taskQueue[queueHead] != NO_TASK) {
			// Grab the task at the head of the queue and increment the head pointer
			task = taskQueue[queueHead];
			taskQueue[queueHead] = NO_TASK;
			queueHead = (queueHead+1) % NUM_TASKS;
		} else {
			task = NO_TASK;
		}

	EndAtomic;
	
	return task;
}

