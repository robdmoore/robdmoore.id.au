/**
 * SensorOS Signal Router Class Description
 *
 * @author Robert Moore <rob@mooredesign.com.au>
 * @date 2009-04-16
 * @version 1.1.0
 */

#ifndef _SIGNAL_ROUTER_H_
#define _SIGNAL_ROUTER_H_

#include <list.h>

typedef List<const VoidFunctor> HandlerList;

class SignalRouter {

	public:
		static SignalRouter* getInstance();
		~SignalRouter();
		void signal(signal_t signal);
		void registerHandler(signal_t signal, VoidFunctor const* handler);

	private:
		SignalRouter();

		HandlerList* handlers[NUM_SIGNALS];

		static SignalRouter instance;
};


#endif
