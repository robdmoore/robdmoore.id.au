/**
 * SensorOS DataLinkLayer Interface
 *
 * @author Robert Moore <rob@mooredesign.com.au>
 * @date 2009-07-18
 * @version 1.1.0
 */

#ifndef _DATA_LINK_LAYER_H
#define _DATA_LINK_LAYER_H

Interface(DataLinkLayer)
	/**
	 * Gives a packet to send across the link
	 *
	 * @param destination The destination to send to, NULL if not applicable
	 * 	or if broadcasting
	 * @param msg A pointer to a message buffer containing the packet in the
	 * 	data field
	 * @param length The length of the packet to be sent
	 * @param priority The local priority of the message, smaller is greater
	 * 	set to NULL if not applicable
	 *
	 * @return The success of the sending operation
	 * 	SUCCESS If queuing the message for sending was successful
	 *	ESIZE If length is greater than the value returned from
	 * 		maxPayloadLength()
	 * 	EFULL If the send queue is full
	 * 	EINVAL If length is 0
	 * 	FAIL If there was some other error sending
	 */
	virtual error_t downFromNetwork(node_address_t destination, message_t* msg,
								data_length_t length, priority_t priority) = 0;

	/**
	 * Requests that the message pending sending in the given
	 * 	message buffer not be sent
	 *
	 * @param msg Pointer to the message buffer with the message to cancel
	 * 	the sending of
	 *
	 * @returns The status of the cancel attempt:
	 * 	SUCCESS if the message was still pending
	 * 	FAIL if the message had already been sent
	 * 	EINVAL if the message buffer wasn't recognised
	 */
	virtual error_t cancel(message_t* msg) = 0;

	/**
	 * Returns the link id of this data link (which then allows it to be
	 * 	referenced from the Network class via the getLink method)
	 *
	 * @return The id of this data link
	 */
	virtual link_id_t getLinkId() = 0;

	/**
	 * Returns the maximum length of the payload field
	 * 	i.e. MTU - header - footer
	 *
	 * @return The maximum payload field length
	 */
	virtual data_length_t maxPayloadLength() = 0;

	/**
	 * Returns the length of the payload field in the given message buffer
	 *
	 * @return The length of the payload field in the given message buffer
	 */
	virtual data_length_t getPayloadLength(message_t* msg) = 0;

	/**
	 * Returns the timestamp in the given message buffer
	 *
	 * @return The timestamp in the given message buffer
	 */
	virtual timestamp_t getTimestamp(message_t* msg) = 0;

	/**
	 * Returns the source address in the given message buffer
	 *
	 * @return The source address in the given message buffer
	 */
	virtual node_address_t getSource(message_t* msg) = 0;

	/**
	 * Returns the destination address in the given message buffer
	 *
	 * @return The destination address in the given message buffer
	 */
	virtual node_address_t getDestination(message_t* msg) = 0;
EndInterface;

#endif
