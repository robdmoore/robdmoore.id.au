/**
 * SensorOS List Definition File
 *
 * Defines a singly-linked list optimised for embedded systems,
 *	based on the STL list interface / functionality
 *
 * @author Robert Moore <rob@mooredesign.com.au>
 * @date 2009-06-01
 * @version 1.0.0
 */

#ifndef _LIST_H
#define _LIST_H

#ifndef NULL
	#define NULL 0
#endif

#if DEBUG
	#include <iostream>
#endif

template <class TClass> class List;
template <class TClass> class ListIterator;

template <class TClass> class ListLink {

	friend class ListIterator<TClass>;
	friend class List<TClass>;

	public:
		ListLink(TClass* data);
		inline void setNext(ListLink<TClass>* next);
		#if DEBUG
			template <class T> friend std::ostream &operator<<(std::ostream &o, const ListLink<T> &l);
		#endif

	private:
		ListLink<TClass>* next;
		TClass* data;
};

template <class TClass> class ListIterator {

	friend class List<TClass>;

	public:
		ListIterator();
		ListIterator(ListLink<TClass>* link);
		inline void operator=(ListLink<TClass>* link);
		ListIterator<TClass>& operator++();
		inline TClass& operator*();
		inline bool operator==(ListIterator<TClass>& iter);
		inline bool operator!=(ListIterator<TClass>& iter);
		inline bool operator==(ListLink<TClass>* link);
		inline bool operator!=(ListLink<TClass>* link);
		#if DEBUG
			template <class T> friend std::ostream &operator<<(std::ostream &o, const ListIterator<T> &l);
		#endif

	private:
		ListLink<TClass>* link;
};

template <class TClass> class List {

	public:
		typedef ListIterator<TClass> iterator;

		List();
		~List();
		void push_back(TClass* obj);
		void push_front(TClass* obj);
		void insert(iterator& iter, TClass* obj);
		inline ListLink<TClass>* begin() const;
		inline ListLink<TClass>* end() const;
		#if DEBUG
			template <class T> friend std::ostream &operator<<(std::ostream &o, const List<T> &l);
		#endif

	private:
		ListLink<TClass>* head;
		ListLink<TClass>* tail;
};

/**
 * ListLink
 */

/**
 * ListLink Constructor
 */
template <class TClass> ListLink<TClass>::ListLink(TClass* data) : next(NULL), data(data) {}

/**
 * Setter for the next item pointer
 *
 * @param next The next item to go after the current
 * 	one in the list
 */
template <class TClass> void ListLink<TClass>::setNext(ListLink<TClass>* next) {
	this->next = next;
}

#if DEBUG

/**
 * Allows a list link to be outputted to an ostream object
 */
template <class TClass> std::ostream &operator<<(std::ostream &o, const ListLink<TClass> &l) {
	o << "(" << l.next << "," << l.data << ")";
	return o;
}
#endif

/**
 * ListIterator
 */

/**
 * Empty ListIterator Constructor
 *
 * Sets the item pointer to NULL
 */
template <class TClass> ListIterator<TClass>::ListIterator() : link(NULL) {}

/**
 * ListIterator Constructor
 *
 * @param link The list item to point the iterator at when
 * 	creating the iterator
 */
template <class TClass> ListIterator<TClass>::ListIterator(ListLink<TClass>* link) : link(link) {}

/**
 * Assignment operator with ListLink
 *
 * Allows assignment to a list link (e.g. begin and end methods on List)
 *
 * @param link The link to point the iterator to
 */
template <class TClass> void ListIterator<TClass>::operator=(ListLink<TClass>* link) {
	this->link = link;
}

/**
 * Pre-increment operator
 *
 * Points the iterator at the link after the current one
 *
 * @return A reference to the current class
 */
template <class TClass> ListIterator<TClass>& ListIterator<TClass>::operator++() {
	if (link != NULL)
		link = link->next;
	return *this;
}

/**
 * Dereference operator
 *
 * Returns a reference to the object pointed to by the
 * 	list item this iterator is currently pointing to
 */
template <class TClass> TClass& ListIterator<TClass>::operator*() {
	return *(link->data);
}

/**
 * Equality operator with Iterator
 *
 * Returns true or false if the iterator being compared to is pointing
 * 	to the same list item.
 */
template <class TClass> bool ListIterator<TClass>::operator==(ListIterator<TClass>& iter) {
	return link == iter.link;
}

/**
 * Inqquality operator with Iterator
 *
 * Returns true or false if the iterator being compared to is pointing
 * 	to a different list item.
 */
template <class TClass> bool ListIterator<TClass>::operator!=(ListIterator<TClass>& iter) {
	return link != iter.link;
}

/**
 * Equality operator with ListLink
 *
 * Returns true or false if the item being compared to is
 * 	the same one being pointed to by this iterator
 */
template <class TClass> bool ListIterator<TClass>::operator==(ListLink<TClass>* link) {
	return this->link == link;
}

/**
 * Inequality operator with ListLink
 *
 * Returns true or false if the item being compared to is
 * 	a different one to the one being pointed to by this iterator
 */
template <class TClass> bool ListIterator<TClass>::operator!=(ListLink<TClass>* link) {
	return this->link != link;
}

#if DEBUG

/**
 * Allows a list iterator to be outputted to an ostream object
 */
template <class TClass> std::ostream &operator<<(std::ostream &o, const ListIterator<TClass> &l) {
	o << *(l.link);
	return o;
}
#endif

/**
 * List
 */

/**
 * List constructor
 */
template<class TClass> List<TClass>::List() : head(NULL), tail(NULL) {}

/**
 * List destructor
 *
 * Deletes all the link objects allocated in this class
 */
template<class TClass> List<TClass>::~List() {
	ListIterator<TClass> iter(head);
	ListIterator<TClass> iter2(head);
	while (iter2 != end()) {
		#if DEBUG
			std::cout << "Deleting " << iter << std::endl;
		#endif
		iter2.link=iter.link->next;
		delete iter.link;
		iter = iter2;
	}
}

/**
 * Adds the given item to the end of the list
 *
 * @param obj A reference to a TClass object to
 * 	be added to the list
 */
template<class TClass> void List<TClass>::push_back(TClass* obj) {
	ListLink<TClass>* link = tail;
	ListLink<TClass>* newLink = new ListLink<TClass>(obj);
	if (head == NULL) {
		head = newLink;
	} else {
		link->setNext(newLink);

	}
	tail = newLink;
}

/**
 * Adds the given item to the start of the list
 *
 * @param obj A reference to a TClass object to
 * 	be added to the list
 */
template<class TClass> void List<TClass>::push_front(TClass* obj) {
	ListLink<TClass>* link = head;
	ListLink<TClass>* newLink = new ListLink<TClass>(obj);
	if (head == NULL) {
		tail = newLink;
	} else {
		newLink->setNext(link);
	}
	head = newLink;
}

/**
 * Inserts the given item to the list after the item
 * 	pointed to by the given iterator
 *
 * @param iter An iterator pointing to an item in the list
 * @param obj A reference to a TClass object to
 * 	be added to the list
 */
template<class TClass> void List<TClass>::insert(List<TClass>::iterator& iter, TClass* obj) {

	if (iter == end()) {
		push_back(obj);
	} else {
		ListLink<TClass>* newLink = new ListLink<TClass>(obj);
		newLink->setNext(iter.link->next);
		iter.link->setNext(newLink);
	}
}

/**
 * Returns the first item in the list
 *
 * @return The first item in the list
 */
template<class TClass> ListLink<TClass>* List<TClass>::begin() const {
	return head;
}

/**
 * Returns the last item in the list
 *
 * @return The last item in the list
 */
template<class TClass> ListLink<TClass>* List<TClass>::end() const {
	return NULL;
}

#if DEBUG

/**
 * Allows a list to be outputted to an ostream object
 */
template <class TClass> std::ostream &operator<<(std::ostream &o, const List<TClass> &l) {

	ListIterator<TClass> i;

	o << "List: " << l.head << " " << l.tail << "; ";

	o << "{";

	for (i = l.begin(); i != l.end(); ++i) {
		o << i << " ";
	}

	o << "}" << std::endl;

	return o;
}
#endif

#endif
